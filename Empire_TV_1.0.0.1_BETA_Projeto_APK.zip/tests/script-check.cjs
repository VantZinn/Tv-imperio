
(()=>{'use strict';
const VERSION=1;
const genres=['Drama','Comédia','Suspense','Ficção científica','Ação','Romance','Terror','Policial','Documentário','Reality','Fantasia','Animação'];
const networks=[{id:'aurora',name:'Rede Aurora',type:'Aberta',reach:1.24,fee:25000,focus:['Drama','Comédia','Reality']},{id:'atlas',name:'Atlas Max',type:'Cabo',reach:.94,fee:36000,focus:['Suspense','Ação','Policial']},{id:'nova',name:'Nova+ Streaming',type:'Streaming',reach:1.12,fee:48000,focus:['Ficção científica','Terror','Fantasia']},{id:'luz',name:'Canal Horizonte',type:'Aberta',reach:.89,fee:22000,focus:['Documentário','Romance','Animação']}];
const talents=[
['Marina Valença','Showrunner','Drama',77,7800],['Theo Ribeiro','Showrunner','Comédia',68,6200],['Nina Vasconcelos','Showrunner','Suspense',82,10200],['Léo Ferreira','Showrunner','Ficção científica',73,7900],
['Camila Nogueira','Roteirista','Drama',76,4800],['Bruno Cardoso','Roteirista','Comédia',69,3800],['Aisha Santos','Roteirista','Terror',81,6400],
['Júlia Martins','Direção','Drama',79,6700],['Gustavo Lima','Direção','Ação',72,5900],['Renata Duarte','Direção','Documentário',83,7100],
['Sophia Costa','Atuação','Romance',75,5700],['Davi Barreto','Atuação','Policial',78,6000],['Bia Reis','Atuação','Comédia',81,7500],['Enzo Luz','Atuação','Ação',67,3600],
['Alice Montenegro','Marketing','Reality',77,4600],['Rafael Pires','Marketing','Drama',70,3100]
].map((t,i)=>({id:'t'+i,name:t[0],role:t[1],genre:t[2],skill:t[3],salary:t[4]}));
const objectiveDefs=[{id:'create',title:'Crie seu primeiro programa',desc:'Desenvolva uma série original',goal:1,xp:80,boost:'inspiracao'},{id:'hire',title:'Monte sua equipe',desc:'Contrate ao menos um profissional',goal:1,xp:65,boost:'desconto'},{id:'pitch',title:'Feche um contrato',desc:'Venda sua série para uma emissora',goal:1,xp:90,boost:'audiencia'},{id:'produce',title:'Luzes, câmera, ação!',desc:'Produza um episódio',goal:1,xp:85,boost:'inspiracao'},{id:'air',title:'Estreia nacional',desc:'Tenha um episódio exibido',goal:1,xp:95,boost:'audiencia'},{id:'series3',title:'Catálogo original',desc:'Crie três séries diferentes',goal:3,xp:130,boost:'desconto'},{id:'episodes5',title:'Maratona',desc:'Produza cinco episódios',goal:5,xp:150,boost:'inspiracao'},{id:'reviews4',title:'Favorito do público',desc:'Consiga nota 70+ do público em quatro episódios',goal:4,xp:160,boost:'audiencia'},{id:'network',title:'Sua própria emissora',desc:'Abra sua primeira emissora',goal:1,xp:200,boost:'desconto'},{id:'revenue',title:'Bilheteria televisiva',desc:'Fature R$ 500 mil em exibições',goal:500000,xp:175,boost:'audiencia'},{id:'level',title:'Império em expansão',desc:'Chegue ao nível 4',goal:4,xp:170,boost:'inspiracao'}];
const styles=['Sóbrio','Equilibrado','Intenso'],pacing=['Lento','Regular','Ágil'],humor=['Sério','Moderado','Cômico'],looks=['Natural','Cinematográfico','Estilizado'];
const elements=['Tom','Humor','Realismo','Ritmo','Atuação','Trilha sonora','Visual','Locações','Cenários','Estrutura','Densidade','Diálogos'];
const genrePref={Drama:[0,0,2,0,1,1,0,1,1,2,2,2],Comédia:[1,2,1,2,1,1,1,1,1,1,0,2],Suspense:[2,0,1,1,1,2,2,1,2,2,2,1],'Ficção científica':[2,1,0,2,2,2,2,2,2,2,2,1],Ação:[2,1,1,2,2,2,2,2,2,1,0,0],Romance:[1,1,2,0,2,1,1,0,1,1,1,2],Terror:[2,0,1,0,1,2,2,2,1,2,1,0],Policial:[0,0,2,1,1,1,0,1,1,2,2,2],Documentário:[0,0,2,0,0,0,0,0,0,2,2,1],Reality:[1,2,1,2,0,2,1,0,0,0,0,2],Fantasia:[2,1,0,2,2,2,2,2,2,2,1,1],Animação:[2,2,0,2,2,2,2,2,2,1,1,2]};
const $=s=>document.querySelector(s);const root=$('#root');let tab='home';let currentEnd=null;let activeModal='';let formDefaults={};
let toastTimer;
function notice(txt,error=false){let el=$('#toast');el.textContent=txt;el.className='toast show'+(error?' error':'');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.className='toast',3300)}
function money(n){return 'R$ '+Math.round(n||0).toLocaleString('pt-BR')};function compact(n){if(Math.abs(n)>=1e6)return (n/1e6).toFixed(2).replace('.',',')+' mi';if(Math.abs(n)>=1000)return (n/1000).toFixed(1).replace('.',',')+' mil';return Math.round(n).toLocaleString('pt-BR')};function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function clamp(n,min,max){return Math.min(max,Math.max(min,n))};function rand(min,max){return min+Math.random()*(max-min)};function dice(n){return Math.floor(Math.random()*n)};
function fresh(name){return{version:VERSION,name:name||'Meu Estúdio',week:1,cash:850000,reputation:25,fans:0,level:1,xp:0,boosts:{inspiracao:1,audiencia:0,desconto:0},shows:[],hired:[],networks:[],upgrades:{roteiro:0,filmagem:0,edicao:0,marketing:0},history:[],ledger:[],feed:[{week:1,text:'Seu novo estúdio está aberto. Hora de criar a primeira grande série!'}],counts:{create:0,hire:0,pitch:0,produce:0,air:0,episodes5:0,reviews4:0,network:0,revenue:0},claimed:[],lastId:0,trend:genres[dice(genres.length)],difficulty:'normal'}}
/* ACCOUNT ENGINE V2 — independent local encrypted profiles + optional hosted auth */
const LEGACY_KEY='imperio_da_tv_save_v1';
const ACCOUNT_INDEX='imperio_tv_profiles_v2';
const STORAGE_PREFIX='imperio_tv_player_v2_';
/* Configure com a URL HTTPS e a chave pública anon/publishable do seu projeto Supabase. NUNCA use service_role/secret. */
const CLOUD_CONFIG={url:'',anonKey:''};
try{Object.assign(CLOUD_CONFIG,JSON.parse(localStorage.getItem('imperio_tv_cloud_public_config')||'{}'))}catch{}
let CLOUD_ENABLED=/^https:\/\/[^/]+/.test(CLOUD_CONFIG.url)&&CLOUD_CONFIG.anonKey.length>25;
let cloudSetupOpen=false;
function updateCloudConfig(fd){let url=String(fd.get('url')||'').trim().replace(/\/$/,'');let anonKey=String(fd.get('anonKey')||'').trim();if(!/^https:\/\/[a-zA-Z0-9.-]+\.supabase\.co$/.test(url))throw Error('Use a URL HTTPS do seu projeto Supabase (ex.: https://abc.supabase.co).');if(anonKey.length<25)throw Error('Informe a chave pública anon/publishable válida.');CLOUD_CONFIG.url=url;CLOUD_CONFIG.anonKey=anonKey;CLOUD_ENABLED=true;localStorage.setItem('imperio_tv_cloud_public_config',JSON.stringify({url,anonKey}));cloudSetupOpen=false;authMode='cloud';authView='login';notice('Serviço online configurado neste dispositivo.');render()}

let account=null,accountKey=null,cloudCacheKey=null,cloudSession=null,authView='login',authMode='local',syncStatus='local',saveChain=Promise.resolve(),s=null;
let loginBusy=false;
function storageGet(k){try{return localStorage.getItem(k)}catch(e){return null}}
function storageSet(k,v){localStorage.setItem(k,v)}
function profileList(){try{let list=JSON.parse(storageGet(ACCOUNT_INDEX)||'[]');return Array.isArray(list)?list:[]}catch{return []}}
function profileSave(list){storageSet(ACCOUNT_INDEX,JSON.stringify(list))}
function safeState(v){return !!v&&v.version===VERSION&&Array.isArray(v.shows)&&Array.isArray(v.networks)&&Array.isArray(v.hired)&&v.counts&&Number.isFinite(v.cash)}
function bytesToB64(bytes){let str='';for(let v of bytes)str+=String.fromCharCode(v);return btoa(str)}
function b64ToBytes(str){return Uint8Array.from(atob(str),ch=>ch.charCodeAt(0))}
function randB64(n=16){return bytesToB64(crypto.getRandomValues(new Uint8Array(n)))}
async function passwordKey(pass,salt){if(!crypto?.subtle)throw Error('Criptografia indisponível. Abra o jogo em HTTPS ou pelo aplicativo Android.');let base=await crypto.subtle.importKey('raw',new TextEncoder().encode(pass),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',salt:b64ToBytes(salt),iterations:210000,hash:'SHA-256'},base,{name:'AES-GCM',length:256},false,['encrypt','decrypt'])}
async function encryptString(msg,key){const iv=crypto.getRandomValues(new Uint8Array(12));const ct=await crypto.subtle.encrypt({name:'AES-GCM',iv},key,new TextEncoder().encode(msg));return bytesToB64(iv)+'.'+bytesToB64(new Uint8Array(ct))}
async function decryptString(data,key){const [iv,payload]=String(data||'').split('.');if(!iv||!payload)throw Error('Senha incorreta ou dados inválidos');const out=await crypto.subtle.decrypt({name:'AES-GCM',iv:b64ToBytes(iv)},key,b64ToBytes(payload));return new TextDecoder().decode(out)}
function accountMark(){if(!account)return'';return `${account.type==='cloud'?'☁️ Online':'🔐 Neste dispositivo'} · ${esc(account.username)}`}
function getOldSave(){try{let v=JSON.parse(storageGet(LEGACY_KEY)||'null');return safeState(v)?v:null}catch{return null}}
function uiError(e){const raw=String(e?.message||e||'Erro inesperado');return raw.slice(0,210)}
function validUsername(v){return /^[a-zA-Z0-9_.-]{3,22}$/.test(v)}
async function accountSubmit(fd,mode){if(loginBusy)return;loginBusy=true;let btn=document.querySelector('form[data-action="auth"] button[type="submit"]');if(btn){btn.disabled=true;btn.textContent='Aguarde...'}
  try{
    const username=String(fd.get('username')||'').trim(),password=String(fd.get('password')||''),email=String(fd.get('email')||'').trim().toLowerCase();
    const register=mode==='register',provider=String(fd.get('provider')||'local');
    if(password.length<(register?8:1))throw Error(register?'Use uma senha de pelo menos 8 caracteres.':'Informe sua senha.');
    if(provider==='cloud'){
      if(!CLOUD_ENABLED)throw Error('O serviço de nuvem ainda não foi configurado neste projeto.');
      if(register){if(!validUsername(username))throw Error('Usuário: 3 a 22 letras, números, ponto, hífen ou _.');if(!/^\S+@\S+\.\S+$/.test(email))throw Error('Digite um e-mail válido.');await cloudRegister(username,email,password)}
      else {if(!/^\S+@\S+\.\S+$/.test(email))throw Error('Informe o e-mail da sua conta.');await cloudLogin(email,password)}
    } else if(register)await localRegister(username,password);else await localLogin(username,password);
  }catch(e){notice(uiError(e),true)}finally{loginBusy=false;render()}
}
async function localRegister(username,password){if(!validUsername(username))throw Error('Usuário: 3 a 22 letras, números, ponto, hífen ou _.');let list=profileList();if(list.some(x=>x.username.toLowerCase()===username.toLowerCase()))throw Error('Esse nome de usuário já está cadastrado neste dispositivo.');let salt=randB64(),key=await passwordKey(password,salt),check=await encryptString('IMP-TV-PROFILE-2',key);let p={id:crypto.randomUUID(),username,salt,check,createdAt:Date.now()};list.push(p);profileSave(list);account={id:p.id,username:p.username,type:'local'};accountKey=key;cloudCacheKey=null;cloudSession=null;syncStatus='local';s=null;tab='home';notice('Conta criada! Seu progresso será protegido pela senha.');}
async function localLogin(username,password){let p=profileList().find(x=>x.username.toLowerCase()===username.toLowerCase());if(!p)throw Error('Usuário ou senha incorretos.');let key=await passwordKey(password,p.salt);try{if(await decryptString(p.check,key)!=='IMP-TV-PROFILE-2')throw Error('Credenciais inválidas')}catch{throw Error('Usuário ou senha incorretos.')}let raw=await readPlayerBlob(STORAGE_PREFIX+p.id),loaded=null;if(raw){try{loaded=JSON.parse(await decryptString(raw,key));if(!safeState(loaded))throw Error('Save inválido')}catch{throw Error('Não foi possível abrir o progresso desta conta.')}}account={id:p.id,username:p.username,type:'local'};accountKey=key;cloudCacheKey=null;cloudSession=null;s=loaded;tab='home';syncStatus='local';notice('Bem-vindo de volta, '+username+'!')}
async function cloudFetch(path,method='GET',data,allowRetry=true){const headers={'apikey':CLOUD_CONFIG.anonKey,'Content-Type':'application/json'};if(cloudSession?.access_token)headers.Authorization='Bearer '+cloudSession.access_token;else if(CLOUD_CONFIG.anonKey.startsWith('eyJ'))headers.Authorization='Bearer '+CLOUD_CONFIG.anonKey;
 if(path.startsWith('/rest/v1/')&&method==='POST')headers.Prefer='resolution=merge-duplicates,return=minimal';
 let resp;try{resp=await fetch(CLOUD_CONFIG.url.replace(/\/$/,'')+path,{method,headers,body:data===undefined?undefined:JSON.stringify(data)})}catch{throw Error('Sem conexão com o servidor de contas. Verifique sua internet.')}let text=await resp.text(),json={};try{json=text?JSON.parse(text):{}}catch{json={message:text.slice(0,160)}}
 if(resp.status===401&&allowRetry&&cloudSession?.refresh_token&&path.startsWith('/rest/')){await cloudRefresh();return cloudFetch(path,method,data,false)}
 if(!resp.ok)throw Error(json.msg||json.error_description||json.message||json.error||'Erro de conexão ('+resp.status+')');return json
}
async function cloudRefresh(){let next=await cloudFetch('/auth/v1/token?grant_type=refresh_token','POST',{refresh_token:cloudSession.refresh_token},false);if(!next.access_token)throw Error('Sessão expirada. Faça login novamente.');cloudSession=next}
async function cloudRegister(username,email,password){let r=await cloudFetch('/auth/v1/signup','POST',{email,password,data:{display_name:username}});if(r.access_token&&r.user){await cloudFinish(r,email,password,username);notice('Conta online criada!');}else{authView='login';notice('Conta solicitada! Confirme o e-mail e depois entre.')}}
async function cloudLogin(email,password){let r=await cloudFetch('/auth/v1/token?grant_type=password','POST',{email,password});if(!r.access_token||!r.user?.id)throw Error('Não foi possível autenticar. Verifique o e-mail e a senha.');await cloudFinish(r,email,password)}
async function cloudFinish(r,email,password,username){cloudSession=r;let id=r.user.id;let nick=String(username||r.user.user_metadata?.display_name||email.split('@')[0]).slice(0,22);let ck=await passwordKey(password,bytesToB64(new TextEncoder().encode(id.slice(0,16))));let localCache=null;try{let raw=await readPlayerBlob(STORAGE_PREFIX+'cloud_'+id);if(raw){localCache=JSON.parse(await decryptString(raw,ck));if(!safeState(localCache))localCache=null}}catch{}
 let fetched=null;try{const rows=await cloudFetch('/rest/v1/game_saves?user_id=eq.'+encodeURIComponent(id)+'&select=save_data,updated_at');let candidate=Array.isArray(rows)&&rows[0]?.save_data;if(safeState(candidate))fetched=candidate;}catch(e){if(!localCache)throw e;notice('Sem conexão: progresso local recuperado. Sincronize depois.',true)}
 account={id,username:nick,type:'cloud',email};accountKey=null;cloudCacheKey=ck;s=fetched&&localCache?(Number(fetched.savedAt||0)>=Number(localCache.savedAt||0)?fetched:localCache):(fetched||localCache);syncStatus=fetched?'cloud':'pending';tab='home';if(s&&localCache&&(!fetched||Number(localCache.savedAt||0)>Number(fetched.savedAt||0)))save();notice('Conta online conectada!')
}
function save(){if(!account||!s)return;s.savedAt=Date.now();const snapshot=JSON.stringify(s),acc={...account},key=accountKey,cacheKey=cloudCacheKey,token=cloudSession;
 saveChain=saveChain.catch(()=>{}).then(async()=>{
  if(acc.type==='local'){
   if(!key)return;await writePlayerBlob(STORAGE_PREFIX+acc.id,await encryptString(snapshot,key));syncStatus='local'
  } else {
   if(cacheKey)await writePlayerBlob(STORAGE_PREFIX+'cloud_'+acc.id,await encryptString(snapshot,cacheKey));syncStatus='pending';
   if(token)try{await cloudFetch('/rest/v1/game_saves?on_conflict=user_id','POST',{user_id:acc.id,save_data:JSON.parse(snapshot),updated_at:new Date().toISOString()});syncStatus='cloud'}catch(e){syncStatus='offline';console.warn('Falha ao sincronizar: ',e.message);notice('Sem sincronização: salvo neste dispositivo. Confira sua internet.',true)}
  }
 }).catch(e=>{syncStatus='offline';console.error('Falha ao salvar o jogo:',e);notice('Falha ao salvar. Faça um backup em Configurações.',true)});
}
async function signOut(){await saveChain.catch(()=>{});account=null;accountKey=null;cloudCacheKey=null;cloudSession=null;s=null;currentEnd=null;tab='home';authView='login';render();notice('Você saiu da conta.')}
async function importLegacy(){if(!account)return;let old=getOldSave();if(!old)return notice('Nenhum progresso antigo encontrado.',true);if(!confirm('Importar o progresso antigo para '+account.username+'?'))return;s=old;tab='home';save();render();notice('Progresso antigo importado para esta conta.');}

function id(){return ++s.lastId}function log(text){s.feed.unshift({week:s.week,text});s.feed=s.feed.slice(0,50)}
function changeCash(amount,label){s.cash+=Math.round(amount);s.ledger.unshift({week:s.week,amount:Math.round(amount),label});s.ledger=s.ledger.slice(0,100)}
function levelThreshold(){return 160+80*(s.level-1)}
function addXP(n){s.xp+=n;let levels=0;while(s.xp>=levelThreshold()){s.xp-=levelThreshold();s.level++;levels++;s.boosts.inspiracao++;s.reputation=clamp(s.reputation+1,0,100)}if(levels)log('Você subiu para o nível '+s.level+'! Capacidade e gêneros ampliados. +'+levels+' impulso(s) criativo(s).')}
function goalValue(o){return ({create:s.counts.create,hire:s.counts.hire,pitch:s.counts.pitch,produce:s.counts.produce,air:s.counts.air,series3:s.counts.create,episodes5:s.counts.produce,reviews4:s.counts.reviews4,network:s.counts.network,revenue:s.counts.revenue,level:s.level})[o.id]||0}
function checkGoals(){for(let o of objectiveDefs){if(!s.claimed.includes(o.id)&&goalValue(o)>=o.goal){s.claimed.push(o.id);s.boosts[o.boost]++;addXP(o.xp);log('OBJETIVO CONCLUÍDO: '+o.title+' (+'+o.xp+' XP e um impulso).')}}}
function update(){checkGoals();save();render()}
function showBy(id){return s.shows.find(x=>x.id===+id)}function networkBy(id){return networks.find(n=>n.id===id)||s.networks.find(n=>n.id===id)}
function showStatus(show){return ({development:'Desenvolvimento',active:'Em exibição',between:'Entre temporadas',cancelled:'Cancelada',ended:'Encerrada'})[show.status]||show.status}
function genreUnlocked(g){return genres.indexOf(g)<3+s.level*2}
function capacity(){return Math.min(20,2+Math.floor(s.level/2)*2)}
function activeCount(){return s.shows.filter(x=>['active','between'].includes(x.status)).length}
function hired(role){return talents.filter(t=>s.hired.includes(t.id)&&(!role||t.role===role))}
function avgSkill(role,genre){let people=hired(role);return people.length?Math.max(...people.map(t=>t.skill+(t.genre===genre?12:0))):38}
function hiredCost(){return hired().reduce((p,t)=>p+t.salary,0)}
function overhead(){return 1600+Object.values(s.upgrades).reduce((a,v)=>a+v*700,0)+s.networks.filter(n=>!n.paused).length*9500}
function seasonAired(show){return show.episodes.filter(ep=>ep.season===show.season&&ep.status==='aired').length}
function seasonProduced(show){return show.episodes.filter(ep=>ep.season===show.season&&ep.status==='produced').length}
function seasonCompleted(show){return seasonAired(show)>=show.episodesPerSeason}
function fmtScore(n){return Number.isFinite(n)?Math.round(n)+'/100':'—'}
function startGame(name){s=fresh(name.trim().slice(0,45));tab='home';update();notice('Seu império começou!')}
function createShow(fd){let name=String(fd.get('name')||'').trim().slice(0,65);let genre=String(fd.get('genre')||'Drama');let concept=String(fd.get('concept')||'').trim().slice(0,260);let duration=+fd.get('duration')||45;if(name.length<3)return notice('Dê um nome com pelo menos 3 letras.',true);if(s.shows.some(x=>x.name.toLowerCase()===name.toLowerCase()))return notice('Já existe uma série com esse nome.',true);if(!genreUnlocked(genre))return notice('Este gênero ainda não foi desbloqueado.',true);if(s.cash<12000)return notice('Você precisa de R$ 12 mil para desenvolver.',true);changeCash(-12000,'Desenvolvimento: '+name);s.shows.push({id:id(),name,genre,concept:concept||'Uma produção original do seu estúdio.',duration,season:1,episodesPerSeason:6,status:'development',networkId:null,fee:0,appeal:rand(40,65),hype:0,episodes:[],totalViewers:0,avgAudience:0,avgCritics:0,fanBase:0,slot:'20:00',day:'Quarta',showrunner:null,finalSeason:false,createdWeek:s.week});s.counts.create++;addXP(18);log('Novo projeto criado: '+name+' ('+genre+').');tab='shows';update();notice('Projeto criado! Agora apresente a uma emissora.')}
function pitch(showId,netId){let show=showBy(showId),net=networkBy(netId);if(!show||show.status!=='development'||!net)return; if(activeCount()>=capacity())return notice('Você atingiu o limite de séries ativas. Evolua de nível.',true);const own=s.networks.some(n=>n.id===netId);if(own){show.status='active';show.networkId=netId;show.fee=0;show.hype=8;show.showrunner=hired('Showrunner')[0]?.id||null;s.counts.pitch++;addXP(40);log(show.name+' estreará na '+net.name+'!');update();return notice('Você aprovou a série para sua emissora!')}
let experience=avgSkill('Showrunner',show.genre);let chance=clamp(43+experience*.25+(net.focus.includes(show.genre)?16:-6)+(show.appeal-50)*.25+s.reputation*.12,35,93);if(rand(0,100)>chance){changeCash(-2600,'Apresentação rejeitada: '+show.name);log(net.name+' recusou o piloto de '+show.name+'. Revise o projeto e tente novamente.');update();return notice('A emissora recusou o projeto. Tente outra!',true)}show.status='active';show.networkId=netId;show.fee=Math.round(net.fee*(.85+show.appeal/240));show.hype=12;show.showrunner=hired('Showrunner')[0]?.id||null;s.counts.pitch++;addXP(40);log(net.name+' aprovou '+show.name+'! Contrato de '+money(show.fee)+'/episódio.');update();notice('Contrato assinado com '+net.name+'!')}
function produce(fd){let show=showBy(fd.get('showId'));if(!show||show.status!=='active')return notice('Este programa não pode produzir episódios.',true);if(seasonAired(show)+seasonProduced(show)>=show.episodesPerSeason)return notice('Todos os episódios dessa temporada já estão prontos.',true);
if(show.episodes.some(e=>e.status==='produced'&&e.season===show.season))return notice('Já existe um episódio aguardando exibição nesta série.',true);
let spend=clamp(+fd.get('budget')||45000,15000,170000);let promo=clamp(+fd.get('promo')||0,0,20000);let discount=fd.get('boost')==='desconto'&&s.boosts.desconto>0;let boost=fd.get('boost')==='inspiracao'&&s.boosts.inspiracao>0;let attention=fd.get('boost')==='audiencia'&&s.boosts.audiencia>0;let cost=Math.round((spend+promo)*(discount?.72:1));if(s.cash<cost)return notice('Saldo insuficiente para produzir este episódio.',true);
if(discount)s.boosts.desconto--;if(boost)s.boosts.inspiracao--;if(attention)s.boosts.audiencia--;changeCash(-cost,'Produção: '+show.name);
let direction=elements.map((_,i)=>clamp(+fd.get('dir'+i)||0,0,2));let pref=genrePref[show.genre]||genrePref.Drama;let fit=direction.reduce((a,v,i)=>a+(2-Math.abs(v-pref[i])),0)/24;
let crew=(avgSkill('Showrunner',show.genre)+avgSkill('Roteirista',show.genre)+avgSkill('Direção',show.genre)+avgSkill('Atuação',show.genre))/4;let dept=(s.upgrades.roteiro+s.upgrades.filmagem+s.upgrades.edicao)*1.7;let quality=clamp(18+crew*.38+fit*18+Math.log2(spend/15000)*6+dept+rand(-12,9)+(boost?15:0),8,99);
let epNum=show.episodes.filter(x=>x.season===show.season).length+1;let ep={id:id(),number:epNum,season:show.season,title:String(fd.get('epTitle')||'').trim().slice(0,75)||'Episódio '+epNum,status:'produced',producedWeek:s.week,airWeek:s.week+1,budget:cost,quality:Math.round(quality),fit:fit,direction,promo,boostAudience:attention,critics:null,viewers:null,viewership:null,reviewCritic:'',reviewFan:'',controversial:false};show.episodes.push(ep);s.counts.produce++;addXP(24);log('Episódio '+epNum+' de '+show.name+' finalizado. Exibição na semana '+ep.airWeek+'.');update();notice('Episódio produzido! Avance uma semana para a estreia.')}

function airEpisode(show,ep){let net=networkBy(show.networkId);let studioNetwork=s.networks.some(n=>n.id===show.networkId);let trend=show.genre===s.trend?1.2:1;let reputation=1+s.reputation/220;let reach=net?.reach||.75;let viewer=clamp(ep.quality+rand(-21,17)+((show.genre==='Reality'||show.genre==='Comédia')?6:0)+(ep.fit-.5)*12,6,100);let critics=clamp(ep.quality+rand(-15,20)+(ep.fit-.5)*20+((show.genre==='Documentário'||show.genre==='Drama')?5:0),6,100);
let viral=Math.abs(viewer-critics)>=27;let audience=Math.round((120000+show.appeal*5100+show.hype*3600+ep.promo*(30+s.upgrades.marketing*4)+ep.quality*7200)*(reach*reputation*trend*(studioNetwork?(show.slot==='20:00'?1.18:show.slot==='18:00'?1.05:show.slot==='00:00'?.64:.92)*(['Sábado','Domingo'].includes(show.day)?1.05:1):1))*(ep.boostAudience?1.4:1)*(viral?1.17:1)*rand(.82,1.24));let revenue=studioNetwork?Math.round(audience*.042+ep.quality*95):Math.round(show.fee+(viewer>=75?show.fee*.16:0));let profit=studioNetwork?'Publicidade: '+show.name:'Contrato de exibição: '+show.name;
changeCash(revenue,profit);ep.status='aired';ep.airWeek=s.week;ep.viewers=Math.round(viewer);ep.critics=Math.round(critics);ep.viewership=audience;ep.controversial=viral;ep.reviewCritic=reviewLine(critics,false);ep.reviewFan=reviewLine(viewer,true);show.totalViewers+=audience;let aired=show.episodes.filter(e=>e.status==='aired');show.avgAudience=Math.round(show.totalViewers/aired.length);show.avgCritics=Math.round(aired.reduce((a,e)=>a+e.critics,0)/aired.length);show.hype=clamp(show.hype+(viewer-50)/16+(viral?5:0),0,75);show.fanBase+=Math.round(audience*(viewer/100)*.03);s.fans+=Math.round(audience*(viewer/100)*.025);s.reputation=clamp(s.reputation+(critics>=80?2:critics<40?-2:0),0,100);s.counts.air++;s.counts.revenue+=revenue;if(viewer>=70)s.counts.reviews4++;
log('NO AR: '+show.name+' T'+ep.season+'E'+ep.number+' — '+compact(audience)+' espectadores; público '+ep.viewers+'/100; críticos '+ep.critics+'/100.');return{show:show.name,episode:ep.number,season:ep.season,viewers:ep.viewers,critics:ep.critics,audience,revenue,controversial:viral}}
function nextWeek(){let reports=[];s.week++;let expense=hiredCost()+overhead();changeCash(-expense,'Folha de pagamento e manutenção');for(let show of s.shows){for(let ep of show.episodes){if(ep.status==='produced'&&ep.airWeek<=s.week&&!s.networks.some(n=>n.id===show.networkId&&n.paused)){reports.push(airEpisode(show,ep))}}
if(show.status==='active'&&seasonCompleted(show)){show.status='between';log(show.name+' concluiu a temporada '+show.season+'. Decida renovar, encerrar ou cancelar.')}}
if(s.week%4===0){s.trend=genres[dice(Math.min(genres.length,3+s.level*2))];log('Nova tendência de audiência: '+s.trend+'.')}
if(s.week%5===0){for(let show of s.shows){if(show.status==='active')show.hype=clamp(show.hype-4,0,75)}}
if(s.cash<0){s.reputation=clamp(s.reputation-3,0,100);log('Atenção: seu império está operando no vermelho!')}
addXP(reports.length*8+2);s.history.push({week:s.week,cash:s.cash,fans:s.fans,viewers:reports.reduce((a,r)=>a+r.audience,0),aired:reports.length});s.history=s.history.slice(-60);currentEnd={week:s.week,expense,reports,net:reports.reduce((a,r)=>a+r.revenue,0)-expense};checkGoals();save();tab='end';render()}
function renew(id){let show=showBy(id);if(!show||show.status!=='between')return;let episodes=show.episodes.filter(e=>e.season===show.season&&e.status==='aired');let avg=episodes.reduce((a,e)=>a+e.viewers,0)/Math.max(1,episodes.length);let own=s.networks.some(n=>n.id===show.networkId);let chance=clamp(30+(avg-40)*1.1+s.reputation*.25,18,96);if(!own&&rand(0,100)>chance){show.status='cancelled';log(networkBy(show.networkId)?.name+' cancelou '+show.name+' após a temporada '+show.season+'.');update();return notice('A emissora recusou a renovação.',true)}show.season++;show.status='active';show.hype=clamp(show.hype+5,5,60);show.episodesPerSeason=6;show.finalSeason=false;show.fee=Math.round(show.fee*1.06);addXP(30);log(show.name+' foi renovada para a temporada '+show.season+'!');update();notice('Renovada para mais uma temporada!')}
function endShow(id){let show=showBy(id);if(!show||!['active','between'].includes(show.status))return;show.status='ended';log(show.name+' chegou ao fim após '+show.season+' temporada(s).');update();notice('Série encerrada.')}
function hireTalent(id){let t=talents.find(t=>t.id===id);if(!t||s.hired.includes(id))return;let onboarding=t.salary*2;if(s.cash<onboarding)return notice('Você precisa de '+money(onboarding)+' para a contratação.',true);changeCash(-onboarding,'Contratação: '+t.name);s.hired.push(id);s.counts.hire++;addXP(12);log(t.name+' entrou para sua equipe ('+t.role+').');update();notice(t.name+' foi contratado(a)!')}
function upgrade(key){const names={roteiro:'Sala de roteiros',filmagem:'Estúdios de filmagem',edicao:'Pós-produção',marketing:'Centro de marketing'};if(!(key in s.upgrades))return;let v=s.upgrades[key];if(v>=5)return notice('Melhoria já atingiu o nível máximo.',true);let cost=Math.round(45000*Math.pow(1.72,v));if(s.cash<cost)return notice('Saldo insuficiente para melhorar a estrutura.',true);changeCash(-cost,'Reforma: '+names[key]);s.upgrades[key]++;addXP(23);log(names[key]+' melhorada para o nível '+s.upgrades[key]+'.');update();notice('Instalação melhorada!')}
function openNetwork(type){if(s.networks.length>=Math.min(4,1+Math.floor(s.level/3)))return notice('Você precisa subir de nível para abrir outra emissora.',true);let def=type==='Streaming'?{name:'Stream Prime',reach:1.15,cost:350000}:{name:'Rede Prime',reach:1.04,cost:220000};if(s.cash<def.cost)return notice('Saldo insuficiente para abrir essa emissora.',true);changeCash(-def.cost,'Abertura de emissora');let n={id:'own'+id(),name:s.name+' '+(type==='Streaming'?'Play':'TV'),type,reach:def.reach+.03*s.level,fee:0,focus:genres.slice(0,3),paused:false};s.networks.push(n);s.counts.network++;addXP(48);log('Você inaugurou '+n.name+'! Agora pode exibir seus próprios programas.');tab='networks';update();notice('Sua emissora foi inaugurada!')}
function toggleNetwork(id){let n=s.networks.find(n=>n.id===id);if(!n)return;n.paused=!n.paused;log(n.name+(n.paused?' entrou em pausa.':' retomou suas operações.'));update()}
function scheduleShow(fd){let show=showBy(fd.get('showId'));if(!show||!s.networks.some(n=>n.id===show.networkId))return;show.day=fd.get('day')||'Quarta';show.slot=fd.get('slot')||'20:00';update();notice('Grade de programação atualizada!')}
function assignBoost(fd){let show=showBy(fd.get('showId'));if(!show)return;let boost=fd.get('boost');if(!s.boosts[boost])return;show.hype=clamp(show.hype+(boost==='audiencia'?30:boost==='inspiracao'?15:10),0,75);s.boosts[boost]--;log('Impulso aplicado a '+show.name+'.');update();notice('Impulso aplicado!')}
function tabButton(id,icon,label){return`<button class="${tab===id?'active':''}" data-tab="${id}"><b>${icon}</b>${label}</button>`}
function authPage(){let register=authView==='register',cloud=authMode==='cloud'&&CLOUD_ENABLED;return`<main class="auth-shell"><section class="auth-left"><div class="brand"><div class="tvicon">◈</div><div><h1>EMPIRE TV</h1><p>V&D DIGITAL · ${'v2.0'}</p></div></div><span class="auth-kicker">✦ SEU IMPÉRIO COMEÇA AQUI</span><h1>Crie histórias.<br><span>Domine a audiência.</span></h1><p>Construa um estúdio lendário. Produza séries, negocie com emissoras e transforme cada temporada em um fenômeno.</p><div class="auth-viz"><div class="viz-main"><small>◉ ACOMPANHAMENTO DE AUDIÊNCIA</small><h3>O próximo sucesso é seu</h3><span class="value">+ 2,4M</span><div class="chart-bars" style="height:64px"><span style="--h:42%"></span><span style="--h:59%"></span><span style="--h:48%"></span><span style="--h:77%"></span><span style="--h:91%"></span><span style="--h:74%"></span></div></div><div class="viz-alt"><small>✦ SUA PRODUTORA</small><h3>VOCÊ NO CONTROLE</h3><p>Crie, produza e distribua.</p><span class="pill green">● No ar</span></div></div></section><section class="auth-right"><div class="auth-card"><span class="auth-eyebrow">${register?'CRIAR CONTA':'ACESSO AO ESTÚDIO'}</span><h2>${register?'Comece seu legado.':'Que bom ter você de volta.'}</h2><p>${register?'Crie seu perfil para manter suas produções separadas.':'Entre na sua conta e continue exatamente de onde parou.'}</p><div class="auth-tabs"><button class="${!register?'active':''}" data-auth-view="login" type="button">Entrar</button><button class="${register?'active':''}" data-auth-view="register" type="button">Criar conta</button></div>${CLOUD_ENABLED?`<div class="provider-tabs"><button class="${!cloud?'active':''}" data-provider="local" type="button">🔐 Dispositivo</button><button class="${cloud?'active':''}" data-provider="cloud" type="button">☁️ Nuvem</button></div>`:''}<form data-action="auth"><input type="hidden" name="provider" value="${cloud?'cloud':'local'}"><label class="label" for="auth-user">${cloud?'E-mail':'Nome de usuário'}</label>${cloud?`<input name="email" id="auth-user" type="email" autocomplete="email" required placeholder="voce@email.com" maxlength="254">`:`<input name="username" id="auth-user" autocapitalize="off" spellcheck="false" autocomplete="username" required minlength="3" maxlength="22" placeholder="Seu nome de usuário">`}${cloud&&register?`<label class="label" for="auth-nick">Nome de exibição</label><input id="auth-nick" name="username" required minlength="3" maxlength="22" autocapitalize="off" placeholder="Como quer ser chamado?">`:''}<label class="label" for="auth-pass">Senha</label><div class="input-password"><input id="auth-pass" name="password" type="password" required ${register?'minlength="8"':''} autocomplete="${register?'new-password':'current-password'}" placeholder="${register?'Mínimo de 8 caracteres':'Digite sua senha'}"><button data-visibility type="button">Mostrar</button></div><button class="primary" type="submit">${register?'✦ Criar minha conta':'◈ Entrar no estúdio'} →</button></form><div class="auth-help">${cloud?`<strong>☁ Conta na nuvem:</strong> sincroniza o progresso entre dispositivos quando há internet. ${register?'Talvez seja necessário confirmar seu e-mail antes de entrar.':''}`:`<strong>🔐 Conta local protegida:</strong> senha e jogo salvo criptografados no dispositivo. Cada usuário mantém sua própria carreira. Não sincroniza com outros celulares.`}</div><div class="auth-footer">${cloudSetupOpen?`<form data-action="cloudConfig" style="text-align:left;margin-top:16px;padding:16px;border:1px solid #3a4f70;border-radius:14px;background:#182135"><b>☁ Configuração do serviço online</b><p>Use somente sua URL e chave pública publishable/anon do Supabase. Nunca informe secret/service_role.</p><label class="label">URL do Supabase</label><input name="url" type="url" value="${esc(CLOUD_CONFIG.url)}" placeholder="https://seuprojeto.supabase.co" required><label class="label">Chave pública anon / publishable</label><input name="anonKey" type="text" value="${esc(CLOUD_CONFIG.anonKey)}" placeholder="sb_publishable_... ou chave anon" required><button type="submit" class="primary">Salvar e ativar nuvem</button></form>`:`<button type="button" data-cloud-setup class="mutedbutton" style="font-size:12px;margin:8px auto">${CLOUD_ENABLED?'⚙ Alterar servidor de contas':'☁ Configurar contas online (opcional)'}</button>`}<div>Jogo independente · Sem anúncios · Desenvolvido para Android</div></div></div></section></main>`}
function stats(){const variants=[['◈','Patrimônio',compact(s.cash),'Caixa atual'],['▦','Temporada',String(s.week),'Semana em andamento'],['♧','Comunidade',compact(s.fans),'Fãs conquistados'],['✦','Prestígio','Nv. '+s.level,'Reputação '+s.reputation+'/100']];return `<section class="stats" aria-label="Indicadores principais">${variants.map((a,i)=>`<div class="stat"><span>${a[0]} ${a[1]}</span><strong class="${i===0&&s.cash<0?'bad':''}">${a[2]}</strong><div class="muted tiny">${a[3]}</div></div>`).join('')}</section>`}
function basic(){return`<header><div class="brand"><span class="tvicon">◈</span><div><h1>EMPIRE TV <span class="pill cyan" style="font-size:9px;vertical-align:middle">2.0</span></h1><p>${esc(s.name)} <span class="muted">/ STUDIO DASHBOARD</span></p></div></div><div class="header-actions"><span class="syncpill">${account?.type==='cloud'?(syncStatus==='cloud'?'☁ Sincronizado':syncStatus==='offline'?'⚠ Offline':'↗ Salvando'):'🔐 Local'}</span><span class="avatar" aria-label="Perfil">${esc(account?.username?.[0]?.toUpperCase()||'P')}</span><button class="small-btn" data-tab="settings" aria-label="Configurações">⚙</button></div></header>${stats()}`}
function genreColors(genre){const v={'Drama':['#49315f','#914f80'],'Comédia':['#b55853','#764aa5'],'Suspense':['#1b465e','#452954'],'Terror':['#4d2037','#18192e'],'Ficção científica':['#236079','#3e327b'],'Ação':['#8b493d','#39365c'],'Reality':['#7c4e8b','#3b4a7b'],'Romance':['#b44e77','#5b406b'],'Fantasia':['#65418c','#27707e'],'Policial':['#25485f','#29364a'],'Animação':['#5178a0','#9550a0'],'Documentário':['#3b5e6d','#395d48']};return v[genre]||['#523884','#24446a']}
function home(){const active=s.shows.filter(x=>x.status==='active');const todo=s.shows.filter(x=>x.status==='development');const goals=objectiveDefs.filter(o=>!s.claimed.includes(o.id)).slice(0,3);const fin=s.history.slice(-8),max=Math.max(1,...fin.map(x=>Math.max(1,x.cash)));const recent=[...s.shows].reverse().slice(0,3);return`<div class="hero-layout"><div class="banner"><div class="eyebrow">✦ SUA CARREIRA ESTÁ NO AR</div><h2>${s.week===1?'Luzes. Câmeras. Seu império.':'O próximo fenômeno da TV começa aqui.'}</h2><p>${s.shows.length?`Você já tem ${s.shows.length} produção(ões) no catálogo. Planeje o próximo sucesso e faça a audiência crescer.`:'Desenvolva a ideia, encontre uma emissora, produza o primeiro episódio. O mundo está pronto para conhecer seu estúdio.'}</p><div class="btnrow"><button class="primary" data-tab="shows">＋ ${s.shows.length?'Criar nova série':'Criar primeira série'}</button><button class="ghost" data-tab="production">▶ Produzir</button></div></div><div class="hero-mini"><div><span class="eyebrow">◉ STATUS DO ESTÚDIO</span><h3>Seu negócio em tempo real</h3></div><div><div class="metric-large">${active.length.toString().padStart(2,'0')} <span class="small">no ar</span></div><p>${s.hired.length} profissionais contratados · ${s.networks.length} redes próprias</p><span class="pill green">● Semana ${s.week} ativa</span></div></div></div>
<section class="section"><div class="head"><h2>◈ Visão geral</h2><span class="pill cyan">Estúdio nível ${s.level}</span></div><div class="grid"><div class="card"><div class="between"><h3>✦ Evolução do estúdio</h3><span class="tag">${s.xp} / ${levelThreshold()} XP</span></div><p>Reputação: ${s.reputation}/100 · Capacidade: ${activeCount()}/${capacity()} séries</p><div class="progress"><span style="width:${Math.min(100,Math.round(s.xp/levelThreshold()*100))}%"></span></div><div class="line"></div><div class="mini-grid"><div>✦ Profissionais<strong>${s.hired.length}</strong></div><div>◉ Séries produzidas<strong>${s.shows.length}</strong></div></div></div><div class="card"><div class="between"><h3>▤ Saúde financeira</h3><span class="tag">ÚLTIMAS SEMANAS</span></div><p>Caixa: ${money(s.cash)} · custo fixo/semana: ${money(hiredCost()+overhead())}</p>${fin.length?`<div class="chart-bars">${fin.map(h=>`<span title="Semana ${h.week}: ${money(h.cash)}" style="--h:${Math.max(4,Math.min(100,Math.max(0,h.cash)/max*100))}%"></span>`).join('')}</div>`:'<div class="empty" style="padding:20px">Seu gráfico aparecerá após a primeira semana.</div>'}</div></div></section>
<section class="section"><div class="head"><h2>▣ Em destaque</h2><button class="mutedbutton" data-tab="shows">Catálogo completo →</button></div><div class="dashboard-catalog">${recent.length?recent.map(sh=>{const colors=genreColors(sh.genre);return`<div class="poster-tile" style="--p1:${colors[0]};--p2:${colors[1]}"><div><span class="pill">${esc(sh.genre)}</span><h3>${esc(sh.name)}</h3><p>${showStatus(sh)} · Temporada ${sh.season}</p></div></div>`}).join(''):'<div class="card" style="grid-column:1/-1"><div class="empty"><b>O grande sucesso ainda vai estrear.</b> Crie seu primeiro programa para preencher seu catálogo.</div><div class="btnrow"><button class="primary" data-tab="shows">＋ Desenvolver projeto</button></div></div>'}</div></section>
<section class="section"><div class="head"><h2>⚡ Centro de decisões</h2><span class="pill orange">Ações da semana</span></div><div class="rows">${todo.length?`<div class="card between"><div><b>✉ ${todo.length} projeto(s) aguardando contrato</b><p>Apresente sua criação para uma emissora.</p></div><button class="secondary" data-tab="shows">Negociar</button></div>`:''}${active.some(sh=>!sh.episodes.some(e=>e.status==='produced'&&e.season===sh.season)&&seasonAired(sh)+seasonProduced(sh)<sh.episodesPerSeason)?`<div class="card between"><div><b>▶ Produção aguardando</b><p>Prepare o próximo episódio e decida o estilo da gravação.</p></div><button class="secondary" data-tab="production">Produzir</button></div>`:''}<div class="card between"><div><b>⏭ Fechamento da semana</b><p>Exiba episódios, receba receitas e confira os resultados.</p></div><button class="primary" data-next-week>Avançar →</button></div></div></section>
<section class="section"><div class="grid"><div class="card"><div class="head"><h2>🏆 Próximos objetivos</h2><button class="mutedbutton" data-tab="goals">Ver todos →</button></div><div class="rows">${goals.map(o=>`<div><div class="between"><b class="small">${esc(o.title)}</b><span class="pill orange">+${o.xp} XP</span></div><div class="bar" style="margin:9px 0 5px"><i style="width:${Math.min(100,goalValue(o)/o.goal*100)}%"></i></div><small class="muted">${o.id==='revenue'?money(goalValue(o)):goalValue(o)} / ${o.id==='revenue'?money(o.goal):o.goal}</small></div>`).join('')||'Todos os objetivos foram concluídos! ✦'}</div></div><div class="card"><h2>📡 Notícias do estúdio</h2><div class="feed" style="margin-top:12px">${s.feed.slice(0,4).map(x=>`<div><small>SEMANA ${x.week}</small><div>${esc(x.text)}</div></div>`).join('')}</div></div></div></section>`}
function newShowForm(){let available=genres.filter(genreUnlocked);return`<div class="card"><h3>＋ Desenvolver nova série</h3><p>Crie um conceito, escolha o público e apresente o projeto a uma emissora. Custo inicial: <strong>${money(12000)}</strong>.</p><form data-action="createShow"><label class="label">Nome da série</label><input name="name" maxlength="65" required minlength="3" placeholder="Ex.: A Última Frequência"><div class="formgrid"><div><label class="label">Gênero</label><select name="genre">${available.map(g=>`<option>${esc(g)}</option>`).join('')}</select></div><div><label class="label">Duração</label><select name="duration"><option value="30">30 minutos</option><option value="45" selected>45 minutos</option><option value="60">60 minutos</option></select></div></div><label class="label">Sinopse / conceito</label><textarea name="concept" maxlength="260" placeholder="Sobre o que é sua série?"></textarea><button class="primary" type="submit">Criar projeto · ${money(12000)}</button></form></div>`}
function showTile(sh){let net=networkBy(sh.networkId);let aired=sh.episodes.filter(e=>e.status==='aired');let produced=seasonProduced(sh);let seasonTotal=seasonAired(sh);return`<div class="card"><div class="itemhead"><span class="reel">${({'Drama':'🎭','Comédia':'😄','Suspense':'🕵️','Ação':'💥','Terror':'👻','Policial':'🔎','Ficção científica':'🚀','Reality':'⭐','Romance':'❤️','Documentário':'🎥','Animação':'🎨','Fantasia':'🐉'})[sh.genre]||'📺'}</span><div style="min-width:0"><h3>${esc(sh.name)}</h3><div class="gap"><span class="pill ${sh.status==='active'?'green':sh.status==='development'?'orange':sh.status==='cancelled'?'red':'cyan'}">${showStatus(sh)}</span><span class="muted tiny">${esc(sh.genre)}</span></div></div></div><p>${esc(sh.concept)}</p><div class="mini-grid"><div>Temporada<strong>${sh.season} · ${seasonTotal}/${sh.episodesPerSeason}</strong></div><div>Audiência média<strong>${compact(sh.avgAudience)}</strong></div><div>Crítica média<strong>${sh.avgCritics?fmtScore(sh.avgCritics):'—'}</strong></div><div>Emissora<strong style="font-size:12px">${net?esc(net.name):'Não definida'}</strong></div></div>${sh.status==='active'?`<div class="bar" style="margin-top:12px"><i style="width:${((seasonTotal+produced)/sh.episodesPerSeason)*100}%"></i></div><div class="muted tiny" style="margin-top:6px">${produced?'📅 Episódio aguardando exibição':'🎞️ '+Math.max(0,sh.episodesPerSeason-seasonTotal)+' episódios restantes'}</div>`:''}
${sh.status==='development'?`<details><summary>📨 Apresentar projeto às emissoras</summary><p>Uma emissora pode aprovar ou rejeitar seu projeto conforme gênero, reputação e equipe.</p><div class="rows">${[...networks,...s.networks.filter(n=>!n.paused)].map(n=>`<div class="between"><div><b>${esc(n.name)}</b><div class="tiny muted">${esc(n.type)} · ${n.fee?money(n.fee)+' / episódio':'Sua emissora'}</div></div><button class="secondary" data-pitch="${sh.id}" data-network="${n.id}">Apresentar</button></div>`).join('')}</div></details>`:''}
<div class="btnrow">${sh.status==='active'?`<button class="secondary" data-produce-tab="${sh.id}">🎥 Produzir episódio</button>`:''}${sh.status==='between'?`<button class="primary" data-renew="${sh.id}">🔄 Tentar renovar</button>`:''}${['active','between'].includes(sh.status)?`<button class="ghost" data-end="${sh.id}">Encerrar série</button>`:''}${aired.length?`<button class="ghost" data-history="${sh.id}">Ver episódios (${aired.length})</button>`:''}</div>${formDefaults.history===sh.id?episodeHistory(sh):''}</div>`}
function episodeHistory(sh){let es=[...sh.episodes].reverse();return`<div class="line"></div><b class="small">Histórico de episódios</b><div class="rows" style="margin-top:10px">${es.map(e=>`<div style="padding:10px;background:#203044;border-radius:10px"><div class="between"><b>${esc(e.title)} <span class="tiny muted">T${e.season}E${e.number}</span></b><span class="pill ${e.status==='aired'?'green':'orange'}">${e.status==='aired'?'Exibido':'Aguardando'}</span></div>${e.status==='aired'?`<div class="gap tiny" style="margin:8px 0"><span>👥 ${compact(e.viewership)}</span><span>🍿 Público ${e.viewers}</span><span>🎞️ Críticos ${e.critics}</span>${e.controversial?'<span class="pill red">Polêmico</span>':''}</div><div class="muted small">Crítica: “${esc(e.reviewCritic)}”</div><div class="muted small">Público: “${esc(e.reviewFan)}”</div>`:`<p>Estreia prevista na semana ${e.airWeek} · Qualidade de produção: ${e.quality}/100</p>`}</div>`).join('')}</div>`}
function shows(){return`<section class="section"><div class="head"><h2>📺 Seu catálogo</h2><span class="pill">${activeCount()} / ${capacity()} séries ativas</span></div><p class="subhead">Desenvolva séries, negocie a distribuição e acompanhe cada temporada.</p><div class="grid"><div>${newShowForm()}</div><div class="rows">${s.shows.length?s.shows.slice().reverse().map(showTile).join(''):'<div class="empty">O catálogo ainda está vazio. Seu primeiro grande sucesso pode nascer hoje.</div>'}</div></div></section>`}
function productionForm(sh){let pending=sh.episodes.some(x=>x.status==='produced'&&x.season===sh.season);let done=seasonAired(sh)+seasonProduced(sh);if(sh.status!=='active')return'';if(pending||done>=sh.episodesPerSeason)return`<div class="info">${pending?'📅 Episódio pronto. Encerre a semana para exibi-lo.':'✅ A temporada já está completa. Aguarde o encerramento.'}</div>`;let choices=['Equilibrado','Criativo','Arriscado'];return`<form data-action="produce"><input type="hidden" name="showId" value="${sh.id}"><div class="formgrid"><div><label class="label">Título do episódio</label><input name="epTitle" maxlength="75" placeholder="Episódio ${done+1}"></div><div><label class="label">Investimento</label><select name="budget"><option value="15000">Econômico · R$ 15 mil</option><option value="30000">Modesto · R$ 30 mil</option><option value="45000" selected>Padrão · R$ 45 mil</option><option value="65000">Alto · R$ 65 mil</option><option value="95000">Premium · R$ 95 mil</option><option value="170000">Superprodução · R$ 170 mil</option></select></div></div><div class="formgrid"><div><label class="label">Campanha de divulgação</label><select name="promo"><option value="0">Sem campanha</option><option value="5000">Local · R$ 5 mil</option><option value="10000">Nacional · R$ 10 mil</option><option value="20000">Impacto · R$ 20 mil</option></select></div><div><label class="label">Impulso opcional</label><select name="boost"><option value="">Nenhum</option>${s.boosts.inspiracao?'<option value="inspiracao">✨ Qualidade +15 ('+s.boosts.inspiracao+')</option>':''}${s.boosts.audiencia?'<option value="audiencia">📢 Audiência +40% ('+s.boosts.audiencia+')</option>':''}${s.boosts.desconto?'<option value="desconto">💸 Custo -28% ('+s.boosts.desconto+')</option>':''}</select></div></div><details><summary>🎬 Direção criativa avançada — 12 decisões</summary><p>Personalize o episódio. Cada gênero reage de forma diferente às suas escolhas.</p><div class="formgrid">${elements.map((name,i)=>`<div><label class="label">${name}</label><select name="dir${i}"><option value="0">${i===0?'Sóbrio':i===1?'Sério':i===3?'Contido':'Tradicional'}</option><option value="1" selected>${i===0?'Equilibrado':i===1?'Moderado':i===3?'Regular':'Equilibrado'}</option><option value="2">${i===0?'Intenso':i===1?'Bem-humorado':i===3?'Ágil':'Experimental'}</option></select></div>`).join('')}</div></details><button class="primary" type="submit">🎥 Produzir T${sh.season}E${done+1}</button></form>`}
function production(){let active=s.shows.filter(x=>x.status==='active');return`<section class="section"><div class="head"><h2>🎬 Sala de produção</h2><span class="pill cyan">Tendência: ${esc(s.trend)}</span></div><p class="subhead">Produza episódios de forma estratégica, escolhendo orçamentos e o estilo criativo. Episódios estreiam na semana seguinte.</p><div class="rows">${active.length?active.map(sh=>`<div class="card" id="production-${sh.id}"><div class="between"><div><span class="tag">TEMPORADA ${sh.season}</span><h3>${esc(sh.name)}</h3><p>${esc(sh.genre)} · ${esc(networkBy(sh.networkId)?.name||'Independente')}</p></div><span class="pill orange">${seasonAired(sh)+seasonProduced(sh)}/${sh.episodesPerSeason}</span></div><div class="line"></div>${productionForm(sh)}</div>`).join(''):'<div class="empty"><span style="font-size:28px">🎞️</span><b>Nenhuma série aprovada</b>Comece na aba Séries, desenvolva um projeto e apresente a uma emissora.<div style="margin-top:15px"><button class="primary" data-tab="shows">Ir para séries</button></div></div>'}</div><div class="info">💡 Contratar profissionais e aprimorar o prédio aumenta a qualidade das produções. A afinidade criativa com o gênero também conta.</div></section>`}
function team(){let total=hiredCost();return`<section class="section"><div class="head"><h2>👩‍💼 Agência de talentos</h2><span class="pill orange">${money(total)}/semana</span></div><p class="subhead">Contratar custa duas semanas de salário antecipadas. Profissionais experientes e especializados ajudam suas produções.</p><div class="grid">${talents.map(t=>{let yes=s.hired.includes(t.id);return`<div class="card"><div class="between"><div><span class="tag">${esc(t.role)}</span><h3>${esc(t.name)}</h3></div><span class="pill ${yes?'green':''}">${yes?'✓ Contratado':t.skill+' técnica'}</span></div><p>Especialidade: ${esc(t.genre)}<br>Salário: <b style="color:var(--txt)">${money(t.salary)}/semana</b></p><div class="bar"><i style="width:${t.skill}%"></i></div><div class="btnrow"><button class="${yes?'ghost':'secondary'}" ${yes?'disabled':''} data-hire="${t.id}">${yes?'Na equipe':'Contratar · '+money(t.salary*2)}</button></div></div>`}).join('')}</div></section>`}
function networkCard(n){let own=s.networks.some(x=>x.id===n.id);let shows=s.shows.filter(sh=>sh.networkId===n.id&&['active','between'].includes(sh.status));return`<div class="card"><div class="between"><div><span class="tag">${esc(n.type)} ${own?'· SUA REDE':''}</span><h3>${esc(n.name)}</h3></div><span class="pill ${own?'green':'cyan'}">${own?(n.paused?'Pausada':'Ativa'):'Parceira'}</span></div><p>${own?'Você administra a programação e a publicidade desta emissora.':'Parceiro comercial. Você recebe pelo licenciamento dos episódios aprovados.'}</p><div class="mini-grid"><div>Alcance<strong>${Math.round(n.reach*100)}%</strong></div><div>Séries<strong>${shows.length}</strong></div></div>${own?`<div class="btnrow"><button class="ghost" data-pause-network="${n.id}">${n.paused?'▶ Retomar':'⏸ Pausar'}</button></div>`:''}${shows.map(sh=>`<div class="line"></div><div class="between"><div><b>${esc(sh.name)}</b><div class="muted tiny">${own?sh.day+' às '+sh.slot:'Temporada '+sh.season}</div></div><span class="pill">${showStatus(sh)}</span></div>${own?`<form data-action="schedule"><input type="hidden" name="showId" value="${sh.id}"><div class="formgrid"><div><label class="label">Dia</label><select name="day">${['Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'].map(d=>`<option ${sh.day===d?'selected':''}>${d}</option>`).join('')}</select></div><div><label class="label">Horário</label><select name="slot">${['16:00','18:00','20:00','22:00','00:00'].map(h=>`<option ${sh.slot===h?'selected':''}>${h}</option>`).join('')}</select></div></div><button type="submit" class="secondary">Atualizar grade</button></form>`:''}`).join('')}</div>`}
function networksPage(){let limit=Math.min(4,1+Math.floor(s.level/3));return`<section class="section"><div class="head"><h2>📡 Emissoras e distribuição</h2><span class="pill">${s.networks.length}/${limit} próprias</span></div><p class="subhead">Venda seus programas para outras redes ou abra sua própria emissora para controlar a grade de programação.</p><div class="grid"><div class="card"><h3>🏗️ Expandir seu império</h3><p>Redes próprias geram publicidade conforme a audiência, mas têm custo semanal de manutenção.</p><div class="btnrow"><button class="primary" data-open-network="TV">Abrir TV · R$ 220 mil</button><button class="secondary" data-open-network="Streaming">Abrir streaming · R$ 350 mil</button></div><p class="small">Capacidade de redes liberada com o nível do império.</p></div><div class="card"><h3>🗞️ Mercado desta semana</h3><p>O gênero em alta muda a cada quatro semanas, influenciando o número de espectadores.</p><div class="banner" style="margin:6px 0;padding:13px"><span class="eyebrow">GÊNERO EM ALTA</span><h2 style="font-size:20px">${esc(s.trend)}</h2><p>+20% de alcance estimado para estreias no gênero.</p></div></div></div><div class="section grid">${[...s.networks,...networks].map(networkCard).join('')}</div></section>`}
function goalsPage(){return`<section class="section"><div class="head"><h2>🏆 Objetivos e recompensas</h2><span class="pill green">${s.claimed.length}/${objectiveDefs.length}</span></div><p class="subhead">Conclua desafios, ganhe experiência e impulsos. A progressão aumenta sua capacidade de produção.</p><div class="grid">${objectiveDefs.map(o=>{let done=s.claimed.includes(o.id);return`<div class="card"><div class="between"><h3>${done?'✅':'🎯'} ${esc(o.title)}</h3><span class="pill ${done?'green':'orange'}">${done?'Concluído':'+'+o.xp+' XP'}</span></div><p>${esc(o.desc)}</p><div class="bar"><i style="width:${done?100:Math.min(100,goalValue(o)/o.goal*100)}%"></i></div><div class="between"><span class="muted tiny">${o.id==='revenue'?money(goalValue(o)):goalValue(o)} de ${o.id==='revenue'?money(o.goal):o.goal}</span><span class="tiny muted">+ 1 impulso</span></div></div>`}).join('')}</div></section>`}
function company(){let vals=[{id:'roteiro',name:'Sala de roteiros',desc:'Dá suporte às escolhas narrativas e aumenta o potencial criativo.',symbol:'✍️'},{id:'filmagem',name:'Estúdios de filmagem',desc:'Melhora a qualidade técnica dos episódios.',symbol:'🎥'},{id:'edicao',name:'Pós-produção',desc:'Aprimora montagem, efeitos e acabamento.',symbol:'🎞️'},{id:'marketing',name:'Centro de marketing',desc:'Prepara campanhas e representa a estrutura da empresa.',symbol:'📢'}];let revenues=s.ledger.filter(x=>x.amount>0).reduce((a,x)=>a+x.amount,0);let expenses=s.ledger.filter(x=>x.amount<0).reduce((a,x)=>a-x.amount,0);return`<section class="section"><div class="head"><h2>🏢 Sua empresa</h2><span class="pill orange">Reputação ${s.reputation}/100</span></div><div class="grid"><div class="card"><h3>📊 Visão financeira</h3><div class="mini-grid"><div>Receitas registradas<strong class="good">${money(revenues)}</strong></div><div>Despesas registradas<strong>${money(expenses)}</strong></div><div>Equipe por semana<strong>${money(hiredCost())}</strong></div><div>Manutenção por semana<strong>${money(overhead())}</strong></div></div><div class="line"></div><h3>Fluxo de caixa</h3><p>Últimos ${Math.min(8,s.history.length)} fechamentos</p>${s.history.length?`<div style="display:flex;align-items:end;gap:6px;height:100px">${s.history.slice(-8).map(h=>`<div title="Semana ${h.week}: ${money(h.cash)}" style="flex:1;min-width:0;background:linear-gradient(#72dccc,#3b8c84);height:${Math.max(5,Math.min(100,h.cash/Math.max(...s.history.slice(-8).map(x=>Math.max(1,x.cash)))*100))}%;border-radius:5px 5px 0 0"></div>`).join('')}</div>`:'<p class="muted">Encerre sua primeira semana para acompanhar a evolução.</p>'}</div><div class="card"><h3>🧱 Melhorias do estúdio</h3><p>Uma boa infraestrutura diferencia suas produções.</p><div class="rows">${vals.map(v=>{let level=s.upgrades[v.id];let cost=Math.round(45000*Math.pow(1.72,level));return`<div class="between"><div><b>${v.symbol} ${v.name}</b><div class="muted tiny">Nível ${level}/5 · ${esc(v.desc)}</div></div><button class="secondary" data-upgrade="${v.id}" ${level>=5?'disabled':''}>${level>=5?'Máximo':money(cost)}</button></div>`}).join('')}</div></div></div><div class="card" style="margin-top:12px"><h3>📜 Registro financeiro</h3><div class="scroll"><table class="table"><thead><tr><th>Semana</th><th>Movimento</th><th>Valor</th></tr></thead><tbody>${s.ledger.slice(0,35).map(x=>`<tr><td>${x.week}</td><td>${esc(x.label)}</td><td class="${x.amount>=0?'good':'bad'}">${x.amount>=0?'+':'−'}${money(Math.abs(x.amount))}</td></tr>`).join('')||'<tr><td colspan="3">Sem movimentações</td></tr>'}</tbody></table></div></div></section>`}
function endPage(){let e=currentEnd;return`<section class="section"><div class="endsummary"><span class="eyebrow">RESUMO SEMANAL</span><h2>Semana ${s.week} concluída</h2><div class="mini-grid"><div>Episódios exibidos<strong>${e?e.reports.length:0}</strong></div><div>Despesas<strong>${e?money(e.expense):'—'}</strong></div><div>Saldo semanal<strong>${e?money(e.net):'—'}</strong></div><div>Caixa disponível<strong>${money(s.cash)}</strong></div></div></div>${e&&e.reports.length?`<h3>📺 Episódios que foram ao ar</h3><div class="rows">${e.reports.map(r=>`<div class="card"><div class="between"><h3>${esc(r.show)} <span class="muted small">T${r.season}E${r.episode}</span></h3>${r.controversial?'<span class="pill orange">Polêmico!</span>':'<span class="pill green">Exibido</span>'}</div><div class="mini-grid"><div>Público<strong>${r.viewers}/100</strong></div><div>Crítica<strong>${r.critics}/100</strong></div><div>Espectadores<strong>${compact(r.audience)}</strong></div><div>Receita<strong>${money(r.revenue)}</strong></div></div></div>`).join('')}</div>`:'<div class="card"><p>Nenhum episódio estreou nesta semana. Produza para movimentar a programação!</p></div>'}<div class="btnrow"><button class="primary" data-tab="home">Voltar ao estúdio</button><button class="secondary" data-tab="production">Planejar novas produções</button></div></section>`}
function intro(){return`<div class="intro"><div class="brand"><span class="tvicon">◈</span><div><h1>EMPIRE TV</h1><p>Bem-vindo, ${esc(account?.username)} · Seu universo criativo</p></div></div><span class="auth-kicker" style="margin-top:30px">✦ INÍCIO DE CARREIRA</span><h1>A maior emissora do país começa com uma ideia.</h1><p>Escolha um nome para seu estúdio. Sua carreira será salva exclusivamente no perfil <b>${esc(account?.username)}</b>.</p><div class="card"><span class="pill cyan">◈ Conta ${account?.type==='cloud'?'online':'local'} ativa</span><h3 style="margin-top:17px">Fundar produtora</h3><form data-action="start"><label class="label">Nome do estúdio</label><input name="name" minlength="2" maxlength="45" required value="Estúdio Prime" placeholder="Ex.: Aurora Pictures"><button class="primary" style="width:100%;margin-top:16px" type="submit">✦ Criar meu estúdio →</button></form></div>${getOldSave()?`<div class="info"><b>Encontramos seu progresso da versão anterior.</b><p>Você pode transferi-lo para a conta atual, sem apagar o original.</p><button class="secondary" data-legacy>Importar progresso antigo</button></div>`:''}<div class="btnrow"><button class="ghost" data-logout>← Trocar de conta</button></div><div class="dev">© 2026 V&D Digital. Todos os direitos reservados.</div></div>`}
function settings(){return`<section class="section"><div class="head"><h2>⚙️ Central de configurações</h2><span class="pill cyan">V2.0 PREMIUM</span></div><p class="subhead">Perfil de usuário, dados e salvamento.</p><div class="rows"><div class="card"><div class="account-detail"><div class="avatar">${esc(account?.username?.[0]?.toUpperCase()||'P')}</div><div><strong>@${esc(account?.username||'')}</strong><small>${account?.type==='cloud'?'☁️ Conta na nuvem · '+'Sincronização '+(syncStatus==='cloud'?'ativa':syncStatus==='offline'?'pendente':'em andamento'):'🔐 Conta local · Dados criptografados com sua senha'}</small></div></div><div class="btnrow">${account?.type==='cloud'?'<button class="secondary" data-sync>↗ Sincronizar progresso</button>':''}<button class="ghost" data-logout>⎋ Sair desta conta</button></div><p class="muted tiny">${account?.type==='cloud'?'Use o mesmo e-mail e senha em outros dispositivos. Você precisa de internet e de um Supabase configurado.':'Seu progresso fica neste dispositivo e neste navegador/app. Para mudar de aparelho, exporte um backup.'}</p></div><div class="card"><h3>💾 Backup e restauração</h3><p>O jogo salva automaticamente nesta conta. Exporte um backup para guardar fora do aplicativo.</p><div class="btnrow"><button class="primary" data-export>⬇ Exportar progresso</button><label class="secondary" style="display:inline-block;cursor:pointer">⬆ Importar backup<input type="file" id="importSave" accept=".json,application/json" style="display:none"></label></div><p class="muted tiny">O arquivo de backup exportado não é criptografado. Guarde-o em local privado. O arquivo importado substituirá o progresso da conta conectada.</p></div>${getOldSave()?`<div class="card"><h3>♻ Progresso da versão anterior</h3><p>Um salvamento antigo foi encontrado neste aparelho. A importação substitui o jogo atual nesta conta; faça backup antes.</p><button class="secondary" data-legacy>Importar progresso antigo</button></div>`:''}<div class="card"><h3>🧭 Novo império</h3><p>Crie um novo estúdio mantendo sua conta. Esta ação substitui o jogo salvo desta conta, mas não afeta os demais usuários.</p><button class="danger" data-reset>Reiniciar somente meu progresso</button></div><div class="card"><h3>ℹ Sobre</h3><p>Empire TV v2.0 é um jogo independente. Produza suas próprias histórias e acompanhe o mercado de televisão e cinema.</p><p>O login local usa criptografia AES-GCM com chave derivada da senha. O modo em nuvem é opcional e requer configuração de um backend; não há sincronização automática entre dispositivos no modo local.</p></div></div></section>`}
function render(){if(!account){root.innerHTML=authPage();return}if(!s){root.innerHTML=intro();return}const sections={home,shows,production,team,networks:networksPage,goals:goalsPage,company,end:endPage,settings};root.innerHTML=`<div class="app">${basic()}${tab==='home'?'':`<div class="topbar"><span class="welcome-line">✦ ${esc(s.name)} · SEMANA ${s.week} · ${accountMark()}</span><button class="small-btn" data-next-week>⏭ Avançar semana</button></div>`}${(sections[tab]||home)()}<p class="dev">Empire TV Beta · Jogo independente · Conta: ${esc(account?.username)}</p></div><nav class="nav" aria-label="Navegação">${tabButton('home','⌂','Início')}${tabButton('shows','▣','Séries')}${tabButton('production','▶','Produção')}${tabButton('team','♟','Equipe')}${tabButton('networks','◉','Emissoras')}${tabButton('goals','✦','Objetivos')}${tabButton('company','▤','Empresa')}</nav>`}
function doExport(){let str=JSON.stringify(s,null,2);if(window.AndroidBridge&&typeof window.AndroidBridge.saveBackup==='function'){let raw=new TextEncoder().encode(str),bin='';for(let i=0;i<raw.length;i+=8192)bin+=String.fromCharCode(...raw.subarray(i,i+8192));window.AndroidBridge.saveBackup(btoa(bin),'tv-empire-'+account.username+'-semana-'+s.week+'.json');notice('Escolha onde salvar o arquivo de backup.');return}let blob=new Blob([str],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='tv-empire-semana-'+s.week+'.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);notice('Backup exportado. Guarde em local seguro.')}
function importBackup(file){if(!file)return;let reader=new FileReader();reader.onload=()=>{try{let v=JSON.parse(reader.result);if(!v||v.version!==VERSION||!Array.isArray(v.shows)||!Array.isArray(v.networks)||!Array.isArray(v.hired)||!v.counts||typeof v.cash!=='number')throw new Error('Formato inválido');if(!confirm('Substituir o progresso atual pelo backup importado?'))return;s=v;tab='home';currentEnd=null;save();render();notice('Backup importado com sucesso!')}catch(e){notice('Este arquivo não é um backup válido do jogo.',true)}};reader.readAsText(file)}
/* Empire TV 3.0: local campaign and production simulation. */
const DIFFICULTIES = {
 easy:{name:'Fácil',cash:1000000,boosts:5,cost:.72,leniency:16,detail:1,artificial:true,desc:'Um laboratório sem pressão. Avaliações artificiais e custos 28% menores.'},
 medium:{name:'Médio',cash:800000,boosts:2,cost:1,leniency:5,detail:3,desc:'Para aprender. Críticas explicam alguns detalhes com uma cobrança moderada.'},
 hard:{name:'Difícil',cash:500000,boosts:0,cost:1.08,leniency:0,detail:7,desc:'Para quem já conhece a produção. Um impulso aleatório e análises exigentes.'},
 director:{name:'Real diretor',cash:0,boosts:0,cost:1.12,leniency:-5,detail:20,desc:'Comece sem dinheiro. Apresente um mini roteiro, negocie financiamento e acompanhe debates sem impulsos.'}
};
const POWERUPS=['inspiracao','audiencia','desconto'];
objectiveDefs.forEach(o=>{o.desc=o.desc.replace('uma série original','uma série ou filme original').replace('sua série','sua obra').replace('três séries diferentes','três obras diferentes').replace(/episódios/g,'produções').replace(/episódio/g,'produção');});
const DIR_OPTIONS=[['Sóbrio','Equilibrado','Intenso'],['Sério','Leve','Cômico'],['Fantástico','Verossímil','Realista'],['Contido','Regular','Ágil'],['Naturalista','Expressivo','Teatral'],['Discreta','Presente','Protagonista'],['Natural','Cinematográfico','Estilizado'],['Uma locação','Várias locações','Muitas locações'],['Minimalista','Detalhado','Grandioso'],['Linear','Alternada','Fragmentada'],['Simples','Moderada','Densa'],['Enxuto','Equilibrado','Extenso']];
const DIR_HELP=[
 'Um tom intenso amplia a tensão. Contrastes com humor precisam de uma justificativa.',
 'Humor cria aproximação; excesso pode interromper terror ou drama sério.',
 'Realismo combina com documental e policial; fantasia ganha espaço para regras próprias.',
 'Ritmo ágil favorece ação, mas uma história densa precisa de tempo para ser compreendida.',
 'A interpretação deve combinar com o tom e com a experiência do protagonista.',
 'Uma trilha protagonista aumenta a emoção; som muito presente pode competir com diálogos extensos.',
 'Estilização precisa de direção de fotografia e orçamento para manter consistência.',
 'Cada locação aumenta a complexidade e dilui a verba por cena.',
 'Cenários grandiosos exigem recursos; poucos ambientes facilitam uma produção econômica.',
 'Uma estrutura fragmentada exige pistas e um conflito claro para não confundir.',
 'Muitas ideias podem aprofundar a obra, mas uma duração curta limita seu desenvolvimento.',
 'Diálogos extensos precisam de motivação e espaço; ação costuma pedir falas mais enxutas.'
];
let campaignSetup=false;
let playerDatabase=null;
function openPlayerDatabase(){
 if(!window.indexedDB)return Promise.resolve(null);
 if(!playerDatabase)playerDatabase=new Promise((resolve,reject)=>{
  const request=window.indexedDB.open('imperio_tv_campaigns_v3',1);
  request.onupgradeneeded=()=>{if(!request.result.objectStoreNames.contains('saves'))request.result.createObjectStore('saves');};
  request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);request.onblocked=()=>reject(Error('Banco de campanhas ocupado. Feche outras abas.'));
 }).catch(()=>null);
 return playerDatabase;
}
async function readPlayerBlob(key){const db=await openPlayerDatabase();if(!db)return storageGet(key);const value=await new Promise((resolve,reject)=>{const request=db.transaction('saves','readonly').objectStore('saves').get(key);request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});return value??storageGet(key);}
async function writePlayerBlob(key,value){const db=await openPlayerDatabase();if(!db){storageSet(key,value);return;}await new Promise((resolve,reject)=>{const tx=db.transaction('saves','readwrite');tx.objectStore('saves').put(value,key);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('Salvamento cancelado.'));});try{localStorage.removeItem(key);}catch{}}
const originalGoalsPage=goalsPage;goalsPage=function(){let html=originalGoalsPage();if(s.difficulty==='director')html=html.replace(/\+ 1 impulso/g,'Sem impulsos neste modo').replace('ganhe experiência e impulsos','ganhe experiência');return html;};
const originalFresh=fresh,originalRender=render,originalHome=home,originalSettings=settings,originalTile=showTile;
const humorousNames=['Shou Ranner','Téo da Risada','Nina Plot Twist','Léo Fim do Mundo','Cami La Roteiro','Bruno de Corte','Aisha do Susto','Júlia Sem Câmera','Gustavo Take','Renata Docu','Wiu Ismiti','Dêni Vito','Bia Gaga','Enzo dos Diesel','Alice do Hype','Rafa da Publí'];
talents.forEach((t,i)=>{t.name=humorousNames[i];t.chance=t.role==='Atuação'?[22,55,35,75][i-10]:100;});
[
 ['Lião Di Cápio','Drama',94,19000,4],['Tómi Cruzi','Ação',91,17000,8],['Morgão Frimã','Policial',90,14500,10],['Scarleta Johã','Ficção científica',87,13000,12],
 ['Keanu Rives','Ação',88,13500,14],['Zendéia da Feira','Romance',85,11000,18],['Jack Black Friday','Comédia',83,9500,25],['Belinha Take Dois','Drama',58,2200,85]
].forEach((a,i)=>talents.push({id:'t'+(i+16),name:a[0],role:'Atuação',genre:a[1],skill:a[2],salary:a[3],chance:a[4]}));
const STUDIOS=[
 {id:'quintal',name:'Quintal Filmes',focus:['Drama','Comédia','Romance','Documentário'],base:95000,weight:1.15},
 {id:'vertigo',name:'Vertigem Studios',focus:['Suspense','Terror','Policial','Ação'],base:130000,weight:1.3},
 {id:'orbit',name:'Órbita Produções',focus:['Ficção científica','Fantasia','Animação'],base:160000,weight:1.45}
];
function hashText(value){let h=2166136261;for(const c of String(value)){h=Math.imul(h^c.charCodeAt(0),16777619);}return h>>>0;}
function seeded(value){let a=hashText(value);return()=>{a+=0x6D2B79F5;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};}
function policy(){return DIFFICULTIES[s?.difficulty]||DIFFICULTIES.medium;}
function isFilm(sh){return sh.kind==='film';}
function unitLabel(sh,ep){return isFilm(sh)?'Filme':`T${ep?.season||sh.season}E${ep?.number||1}`;}
function shortText(v,n=85){return String(v||'').trim().slice(0,n).replace(/\s+/g,' ');}
function norm(v){return String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();}
function words(v){return norm(v).match(/[a-z0-9]+/g)||[];}
function factor(key,label,score,evidence,advice,weight=1){return{key,label,score:Math.round(clamp(score,0,100)),evidence,advice,weight};}
fresh=function(name,difficulty='medium'){
 const state=originalFresh(name),d=DIFFICULTIES[difficulty]||DIFFICULTIES.medium;
 state.difficulty=DIFFICULTIES[difficulty]?difficulty:'medium';state.cash=d.cash;state.schema=3;state.campaignId=crypto.randomUUID();state.campaignArchive=[];state.grantTaken=false;
 state.boosts=Object.fromEntries(POWERUPS.map(k=>[k,d.boosts]));if(state.difficulty==='hard')state.boosts[POWERUPS[dice(3)]]=1;
 state.feed=[{week:1,text:`Campanha ${d.name}. Verba inicial: ${money(d.cash)}.${difficulty==='director'?' Desenvolva um conceito gratuito e apresente um mini roteiro a um estúdio.':''}`}];return state;
};
function migrateV3(state){
 if(!state)return state;
 if((!state.schema||state.schema<3)){state.schema=3;state.difficulty=DIFFICULTIES[state.difficulty]?state.difficulty:'medium';state.campaignId=state.campaignId||crypto.randomUUID();state.grantTaken=state.grantTaken||false;state.campaignArchive=state.campaignArchive||[];state.feed.unshift({week:state.week,text:'Atualização 3.0: seu patrimônio foi preservado. Obras antigas mantêm seus resultados; novos relatórios detalhados valem para novas produções.'});}
 state.campaignArchive=state.campaignArchive||[];
 state.shows.forEach(sh=>{sh.kind=sh.kind||'series';sh.story=sh.story||{motivation:'',conflict:'',payoff:''};sh.slot=sh.slot||'20:00';sh.day=sh.day||'Quarta';sh.funding=sh.funding||{offers:[],accepted:null};});return state;
}
startGame=function(name,difficulty='medium'){
 if(!DIFFICULTIES[difficulty])return notice('Escolha a dificuldade da campanha.',true);
 let archive=s?.campaignArchive||[];
 if(campaignSetup&&s){const snapshot=JSON.parse(JSON.stringify(s));delete snapshot.campaignArchive;archive=[snapshot,...archive].slice(0,8);}
 s=fresh(name.trim().slice(0,45),difficulty);s.campaignArchive=archive;campaignSetup=false;tab='home';currentEnd=null;formDefaults={};update();notice('Campanha '+policy().name+' iniciada.');
};
addXP=function(n){s.xp+=n;let levels=0;while(s.xp>=levelThreshold()){s.xp-=levelThreshold();s.level++;levels++;if(s.difficulty!=='director')s.boosts.inspiracao++;s.reputation=clamp(s.reputation+1,0,100);}if(levels)log('Nível '+s.level+' alcançado! Capacidade e gêneros ampliados.'+(s.difficulty==='director'?'':` +${levels} impulso(s).`));};
checkGoals=function(){for(let o of objectiveDefs){if(!s.claimed.includes(o.id)&&goalValue(o)>=o.goal){s.claimed.push(o.id);if(s.difficulty!=='director')s.boosts[o.boost]++;addXP(o.xp);log('Objetivo: '+o.title+' (+'+o.xp+' XP'+(s.difficulty==='director'?'':', +1 impulso')+').');}}};
overhead=function(){return s.difficulty==='director'&&!s.grantTaken&&s.hired.length===0&&s.networks.length===0?0:Math.round((1600+Object.values(s.upgrades).reduce((a,v)=>a+v*700,0)+s.networks.filter(n=>!n.paused).length*9500)*policy().cost);};
function plotFactors(sh,script=''){
 const st=sh.story||{},combined=[sh.concept,st.motivation,st.conflict,st.payoff,script].join(' '),w=words(combined),unique=new Set(w).size;
 const clarity=clamp(words(sh.concept).length*2.4+Math.min(20,unique*.35),0,100);
 const motivation=clamp(words(st.motivation).length*6,0,100),conflict=clamp(words(st.conflict).length*6,0,100),payoff=clamp(words(st.payoff).length*6,0,100);
 const consequence=/(porque|por isso|portanto|consequencia|para salvar|se nao|perde|arrisc|decid|escolh)/.test(norm(combined));
 return[
 factor('premise','Premissa',clarity,`A premissa tem ${words(sh.concept).length} palavras: “${shortText(sh.concept)}”.`,'Defina protagonista, objetivo e obstáculo na premissa.',1.2),
 factor('motivation','Motivação',motivation,st.motivation?`Motivo apresentado: “${shortText(st.motivation)}”.`:'Não foi definida uma motivação para o protagonista.','Explique por que o personagem precisa agir e o que ele perde se falhar.',1.3),
 factor('conflict','Conflito',conflict,st.conflict?`Obstáculo: “${shortText(st.conflict)}”.`:'O roteiro ainda não apresenta um conflito explícito.','Dê ao objetivo uma oposição concreta e um risco.',1.3),
 factor('payoff','Desfecho',payoff,st.payoff?`Resolução planejada: “${shortText(st.payoff)}”.`:'O desfecho ainda não tem uma proposta escrita.','Indique a escolha final e a consequência; em séries, resolva algo antes do gancho.',1.1),
 factor('causality','Causa e consequência',consequence?83:32,consequence?'O texto contém sinais de causa, decisão ou risco.':'Não foram encontrados sinais textuais explícitos de causa ou consequência.','Ligue o obstáculo à decisão do personagem com uma consequência explícita.',.8),
 factor('development','Desenvolvimento',clamp(words(script||combined).length*1.35,0,100),`O mini roteiro / argumento contém ${words(script||combined).length} palavras.`,'Descreva a abertura, uma virada e o resultado da ação em vez de apenas anunciar o gênero.',.8)
 ];
}
function weighted(fs){return fs.reduce((a,f)=>a+f.score*f.weight,0)/Math.max(.001,fs.reduce((a,f)=>a+f.weight,0));}
function distribution(sh){const n=networkBy(sh.networkId),type=n?.type||'Aberta';let fit=1,why='Distribuição neutra.';
 if(type==='Aberta'||type==='TV'){fit=isFilm(sh)?1.1:.9;why=isFilm(sh)?'Filme com história completa facilita a entrada do público casual na TV aberta (+10% de alcance).':'Série exige retorno semanal; na TV aberta há perda de 10% de alcance inicial.';}
 if(type==='Streaming'){fit=isFilm(sh)?1.04:1.12;why=isFilm(sh)?'Filme sob demanda: +4% de alcance.':'Série sob demanda: +12% de alcance por hábito de acompanhamento.';}
 if(type==='Cabo'){fit=isFilm(sh)?1.02:1.06;why='Público especializado do cabo: '+(isFilm(sh)?'+2%':'+6%')+' de alcance.';}
 const slot=sh.slot==='20:00'?1.18:sh.slot==='18:00'?1.05:sh.slot==='00:00'?.64:.92;
 if((type==='Aberta'||type==='TV')&&sh.duration>100){fit*=.85;why+=' Duração acima de 100 min reduz alcance em 15%.';}
 return{type,fit,slot,weekend:['Sábado','Domingo'].includes(sh.day)?1.05:1,why};
}
function costPreview(sh,budget,promo,boost){const durationFactor=isFilm(sh)?sh.duration/45:sh.duration/45;return Math.round((budget*durationFactor+promo)*policy().cost*(boost==='desconto'?.72:1));}
createShow=function(fd){
 const name=String(fd.get('name')||'').trim().slice(0,65),genre=String(fd.get('genre')||'Drama'),kind=fd.get('kind')==='film'?'film':'series';
 const duration=clamp(Number(fd.get('duration'))||(kind==='film'?90:45),kind==='film'?60:20,kind==='film'?150:60),cost=s.difficulty==='director'?0:Math.round(12000*policy().cost);
 if(name.length<3)return notice('Use um título com pelo menos 3 caracteres.',true);if(s.shows.some(x=>x.name.toLowerCase()===name.toLowerCase()))return notice('Esse título já está no catálogo.',true);
 if(!genreUnlocked(genre))return notice('Gênero ainda não desbloqueado.',true);if(s.cash<cost)return notice('Faltam recursos para desenvolver o projeto.',true);
 if(cost)changeCash(-cost,'Desenvolvimento: '+name);
 const sh={id:id(),name,genre,kind,duration,concept:String(fd.get('concept')||'').trim().slice(0,2500),story:{motivation:String(fd.get('motivation')||'').trim().slice(0,600),conflict:String(fd.get('conflict')||'').trim().slice(0,600),payoff:String(fd.get('payoff')||'').trim().slice(0,600)},season:1,episodesPerSeason:kind==='film'?1:6,status:'development',networkId:null,fee:0,appeal:50,hype:0,episodes:[],totalViewers:0,avgAudience:0,avgCritics:0,fanBase:0,slot:'20:00',day:'Quarta',showrunner:null,finalSeason:false,createdWeek:s.week,funding:{offers:[],accepted:null}};
 sh.appeal=Math.round(30+weighted(plotFactors(sh))*.5);s.shows.push(sh);s.counts.create++;addXP(18);log(`${kind==='film'?'Filme':'Série'} desenvolvido: ${name}. ${money(cost)} em desenvolvimento.`);update();notice('Projeto criado. '+(s.difficulty==='director'&&!s.grantTaken?'Apresente o mini roteiro para obter verba.':'Escolha a distribuição.'));
};
function editStory(fd){const sh=showBy(fd.get('showId'));if(!sh)return;
 if(sh.episodes.some(e=>e.status==='produced'))return notice('Espere a exibição do material pronto antes de alterar o argumento.',true);
 sh.concept=String(fd.get('concept')||'').trim().slice(0,2500);sh.story={motivation:String(fd.get('motivation')||'').trim().slice(0,600),conflict:String(fd.get('conflict')||'').trim().slice(0,600),payoff:String(fd.get('payoff')||'').trim().slice(0,600)};sh.appeal=Math.round(30+weighted(plotFactors(sh))*.5);sh.funding.offers=[];update();notice('Argumento revisado. Os próximos episódios usarão essa versão.');}
function evaluateFunding(fd){const sh=showBy(fd.get('showId')),studio=STUDIOS.find(x=>x.id===fd.get('studio'));if(!sh||!studio||s.difficulty!=='director'||s.grantTaken)return;
 const script=String(fd.get('script')||'').trim().slice(0,3500);if(words(script).length<20)return notice('Escreva pelo menos 20 palavras no mini roteiro.',true);
 const fs=plotFactors(sh,script),score=weighted(fs),match=studio.focus.includes(sh.genre),rng=seeded([script,sh.concept,sh.story.motivation,sh.story.conflict,sh.story.payoff,studio.id].join('|'));
 const feasible=sh.duration<=100?1:.82;const accepted=score>=48;
 const amount=accepted?Math.round((studio.base*(.38+score/100)*feasible*(match?studio.weight:.82)+rng()*1200)/100)*100:0;
 const offer={studioId:studio.id,studio:studio.name,score:Math.round(score),amount,accepted,script,feedback:fs,match,durationFactor:feasible};
 sh.funding.offers=sh.funding.offers.filter(x=>x.studioId!==studio.id);sh.funding.offers.push(offer);update();notice(accepted?`${studio.name} oferece ${money(amount)}.`:'O estúdio pediu revisão: veja a análise do argumento.',!accepted);
}
function acceptFunding(showId,studioId){const sh=showBy(showId),o=sh?.funding?.offers.find(x=>x.studioId===studioId);if(!o?.accepted||s.grantTaken||s.difficulty!=='director')return;
 s.grantTaken=true;sh.funding.accepted={...o};changeCash(o.amount,'Financiamento inicial: '+o.studio);log(`${o.studio} investiu ${money(o.amount)} em ${sh.name}. O financiamento inicial é único por campanha; receitas sustentam os próximos projetos.`);update();notice('Financiamento recebido. Escolha uma emissora para a obra.');}
pitch=function(showId,netId){const sh=showBy(showId),net=networkBy(netId);if(!sh||sh.status!=='development'||!net)return;if(s.difficulty==='director'&&!s.grantTaken)return notice('Antes do contrato, aceite uma oferta de financiamento de um estúdio.',true);
 if(activeCount()>=capacity())return notice('Capacidade de projetos ativos atingida.',true);
 const own=s.networks.some(n=>n.id===netId),fit=net.focus?.includes(sh.genre),story=weighted(plotFactors(sh)),chance=clamp(40+story*.28+avgSkill('Showrunner',sh.genre)*.12+s.reputation*.13+(fit?12:-5)+policy().leniency,20,98);
 if(!own&&rand(0,100)>chance){const cost=Math.min(Math.max(0,s.cash),Math.round(2600*policy().cost));if(cost)changeCash(-cost,'Apresentação rejeitada: '+sh.name);log(net.name+' recusou '+sh.name+': '+(!fit?'gênero fora da especialidade; ':'')+'argumento '+Math.round(story)+'/100. Revise motivação, conflito e desfecho.');update();return notice('Proposta recusada. Veja o motivo nas notícias do estúdio.',true);}
 sh.status='active';sh.networkId=netId;sh.fee=own?0:Math.round(net.fee*(.85+sh.appeal/240)*(isFilm(sh)?3.8:1));sh.hype=12;sh.showrunner=hired('Showrunner')[0]?.id||null;s.counts.pitch++;addXP(40);log(`${net.name} aprovou ${sh.name}. ${own?'Publicidade própria':money(sh.fee)+(isFilm(sh)?' pela exibição do filme':' por episódio')}.`);update();notice('Contrato de distribuição assinado.');
};
function buildAnalysis(sh,ep){
 const dir=ep.direction||elements.map(()=>1),pref=genrePref[sh.genre]||genrePref.Drama,fs=[];
 elements.forEach((label,i)=>{const diff=Math.abs(dir[i]-pref[i]);const consistent=(i===0&&dir[1]===2&&dir[0]===2)||(i===5&&dir[11]===2&&dir[5]===2);const score=clamp(94-diff*24-(consistent?18:0),8,100);
 fs.push(factor('dir'+i,label,score,`${label}: ${DIR_OPTIONS[i][dir[i]]}. Para ${sh.genre}, a referência de afinidade é ${DIR_OPTIONS[i][pref[i]]}.${consistent?' Há competição com outra escolha criativa.':''}`,`Experimente ${DIR_OPTIONS[i][pref[i]]} em ${label.toLowerCase()}. ${DIR_HELP[i]}`,i===3||i===9||i===11?1.2:1));});
 const storyline=plotFactors({...sh,concept:ep.storySnapshot?.concept??sh.concept,story:ep.storySnapshot?.story??sh.story},ep.script);fs.push(...storyline);
 const perMinute=ep.baseBudget/(sh.duration/45),complexity=1+dir[7]*.16+dir[8]*.18+dir[6]*.12;
 fs.push(factor('budget','Recursos técnicos',clamp(35+Math.log2(Math.max(1,perMinute/15000))*20-(complexity-1)*35+ep.dept*3,5,100),`${money(ep.baseBudget)} para ${sh.duration} min; complexidade ${complexity.toFixed(2)}×. O gasto total, com divulgação, foi ${money(ep.budget)}.`,'Se a verba é pequena, reduza locações, grandiosidade dos cenários e estilização antes de aumentar o investimento.',1.4));
 fs.push(factor('crew','Equipe',clamp(ep.crew,8,100),`Equipe no momento da gravação: ${Math.round(ep.crew)}/100. Protagonista: ${ep.actorName||'elenco de apoio'}${ep.actorGenre===sh.genre?' (especialista no gênero)':''}.`,'Contrate profissionais com técnica alta e afinidade com o gênero. A equipe da gravação fica registrada e não muda depois.',1.2));
 if(dir[10]===2&&(dir[3]===2||sh.duration<=30))fs.push(factor('density','Tempo de compreensão',35,`História densa com ritmo ${DIR_OPTIONS[3][dir[3]]} em ${sh.duration} min.`,'Reduza a densidade ou desacelere a montagem para deixar as ideias respirarem.',1.5));
 else fs.push(factor('density','Tempo de compreensão',84,`Densidade ${DIR_OPTIONS[10][dir[10]].toLowerCase()} com ${sh.duration} min e ritmo ${DIR_OPTIONS[3][dir[3]].toLowerCase()}.`,'Mantenha espaço para o público compreender as viradas.',1));
 const previous=sh.episodes.filter(e=>e.status==='aired').at(-1);
 if(!isFilm(sh)&&previous){const drift=dir.reduce((a,v,i)=>a+Math.abs(v-(previous.direction?.[i]??v)),0);fs.push(factor('continuity','Continuidade criativa',clamp(95-drift*3,10,100),`${drift} pontos de mudança de estilo em relação ao episódio anterior.`,'Grandes mudanças de tom e estrutura precisam de transição. Preserve elementos que conquistaram seus fãs.',1));}
 return fs;
}
produce=function(fd){const sh=showBy(fd.get('showId'));if(!sh||sh.status!=='active')return notice('Projeto ainda não aprovado.',true);
 if(seasonAired(sh)+seasonProduced(sh)>=sh.episodesPerSeason||sh.episodes.some(e=>e.status==='produced'&&e.season===sh.season))return notice('Já há uma produção pronta, ou a obra está completa.',true);
 const budget=clamp(Number(fd.get('budget'))||30000,15000,170000),promo=clamp(Number(fd.get('promo'))||0,0,20000),requested=String(fd.get('boost')||''),boost=POWERUPS.includes(requested)&&s.boosts[requested]>0&&s.difficulty!=='director'?requested:'';
 const total=costPreview(sh,budget,promo,boost);if(s.cash<total)return notice('Faltam '+money(total-s.cash)+' para a produção. Ajuste verba, duração ou divulgação.',true);
 const actor=hired('Atuação').find(t=>t.id===fd.get('actor'))||hired('Atuação').sort((a,b)=>b.skill-a.skill)[0],direction=elements.map((_,i)=>clamp(Number(fd.get('dir'+i))||0,0,2));
 const crew=(avgSkill('Showrunner',sh.genre)+avgSkill('Roteirista',sh.genre)+avgSkill('Direção',sh.genre)+(actor?actor.skill+(actor.genre===sh.genre?12:0):38))/4;
 const ep={id:id(),number:sh.episodes.filter(e=>e.season===sh.season).length+1,season:sh.season,title:String(fd.get('epTitle')||'').trim().slice(0,75)||(isFilm(sh)?sh.name:'Episódio '+(sh.episodes.length+1)),status:'produced',producedWeek:s.week,airWeek:s.week+1,budget:total,baseBudget:budget*(sh.duration/45),promo,direction,crew,actorId:actor?.id||null,actorName:actor?.name||'',actorGenre:actor?.genre||'',dept:s.upgrades.roteiro+s.upgrades.filmagem+s.upgrades.edicao,script:String(fd.get('script')||'').trim().slice(0,3500),storySnapshot:{concept:sh.concept,story:{...sh.story}},boostAudience:boost==='audiencia',qualityBoost:boost==='inspiracao'?15:0,critics:null,viewers:null,viewership:null,reviewCritic:'',reviewFan:'',controversial:false};
 ep.analysis=buildAnalysis(sh,ep);ep.fit=direction.reduce((a,v,i)=>a+2-Math.abs(v-(genrePref[sh.genre]||genrePref.Drama)[i]),0)/24;ep.quality=Math.round(clamp(weighted(ep.analysis)+ep.qualityBoost,5,99));
 if(boost)s.boosts[boost]--;changeCash(-total,'Produção '+unitLabel(sh,ep)+': '+sh.name);sh.episodes.push(ep);s.counts.produce++;addXP(24);log(`${unitLabel(sh,ep)} de ${sh.name} produzido. ${money(total)} gastos; qualidade prevista ${ep.quality}/100. Estreia na semana ${ep.airWeek}.`);update();notice('Produção finalizada. Avance a semana para exibir e receber o relatório.');
};
function commentThread(sh,ep,fs,rng){
 sh={...sh,concept:ep.storySnapshot?.concept??sh.concept,story:ep.storySnapshot?.story??sh.story};
 const list=[...fs].sort((a,b)=>a.score-b.score),n=s.difficulty==='director'?list.length:policy().detail,selected=list.slice(0,n),comments=[],personas=['CineLupa','FãDoSofá','PlanoSequência','PipocaSincera','TiaDoControle','CorteSeco','TelaAberta','RoteiroNaVeia'];
 const context=`${sh.name} / ${unitLabel(sh,ep)} “${ep.title}”`;
 selected.forEach((f,i)=>{const user=personas[(i*2)%personas.length]+'_'+(1+Math.floor(rng()*90)),severity=s.difficulty==='medium'?'Pode funcionar melhor':'É uma escolha que pesa no resultado';
 const text=f.score<65?`${context}: ${f.evidence} ${severity}: ${f.advice}`:`${context}: ${f.evidence} Essa escolha funcionou neste perfil de avaliação (${f.score}/100). ${f.advice}`;
 comments.push({id:'c'+comments.length,user,role:i%2?'Fã':'Crítico',text,likes:Math.floor(rng()*Math.max(5,ep.viewership*.00006)),factor:f.key,parent:null});
 if(s.difficulty==='director'){const p=comments.at(-1),respond=personas[(i*2+1)%personas.length]+'_'+(1+Math.floor(rng()*90));const disagree=f.score<65;
 const argument=disagree?`@${p.user}, discordo do peso que você deu a ${f.label.toLowerCase()}. ${ep.actorName?'A presença de '+ep.actorName+' me prendeu à cena.':'A proposta '+sh.genre.toLowerCase()+' ainda me manteve interessado.'} ${shortText(ep.script||sh.concept,70)?'Minha leitura foi: “'+shortText(ep.script||sh.concept,70)+'”.':''}`:`@${p.user}, para mim ${f.label.toLowerCase()} não resolve tudo: ${list[0].evidence} Quero ver uma revisão em ${list[0].label.toLowerCase()}.`;
 comments.push({id:'c'+comments.length,user:respond,role:'Fã',text:argument,likes:Math.floor(rng()*Math.max(5,ep.viewership*.00004)),factor:f.key,parent:p.id});
 comments.push({id:'c'+comments.length,user:p.user,role:'Crítico',text:`@${respond}, entendo a preferência. Meu ponto é o efeito de ${f.label.toLowerCase()} junto de ${list[0].label.toLowerCase()}: ${list[0].advice} A direção pode testar isso na próxima obra e comparar os números.`,likes:Math.floor(rng()*20),factor:f.key,parent:p.id});}
 });
 if(s.difficulty==='easy')comments.push({id:'cArtificial',user:'Simulador',role:'Teste',text:`Avaliação artificial da campanha Fácil: ${ep.viewers}/100 para ${context}. Use o relatório de decisões para experimentar sem pressão.`,likes:0,parent:null});
 return comments;
}
airEpisode=function(sh,ep){
 ep.qualityBoost=ep.qualityBoost||0;ep.promo=ep.promo||0;
 const net=networkBy(sh.networkId),own=s.networks.some(n=>n.id===sh.networkId),rng=seeded(s.campaignId+'|'+ep.id+'|'+s.week),dist=distribution(sh);
 const fs=ep.analysis||buildAnalysis(sh,{...ep,baseBudget:ep.baseBudget||ep.budget,promo:ep.promo||0,crew:ep.crew||38,dept:ep.dept||0});ep.analysis=fs;
 const story=weighted(fs.filter(f=>['premise','motivation','conflict','payoff','causality','development','dir9','dir11'].includes(f.key))),technical=weighted(fs.filter(f=>['budget','crew','dir4','dir5','dir6','dir7','dir8'].includes(f.key)));
 const artificial=s.difficulty==='easy';const critics=clamp((artificial?68+ep.quality*.23:story*.48+technical*.25+ep.quality*.27)+policy().leniency+ep.qualityBoost*.2,5,100),fansScore=clamp((artificial?72+ep.quality*.2:ep.quality*.55+technical*.2+story*.25)+policy().leniency+(sh.genre==='Comédia'?3:0),5,100);
 const debate=Math.abs(fansScore-critics)>=9,quality=ep.quality/100;
 const base=120000+sh.appeal*5100+sh.hype*3600+ep.promo*(30+s.upgrades.marketing*4)+ep.quality*7200;
 const multiplier=(net?.reach||.75)*(1+s.reputation/220)*(sh.genre===s.trend?1.2:1)*dist.fit*(dist.type==='Streaming'?1:dist.slot*dist.weekend)*(ep.boostAudience?1.4:1)*(debate?1.08:1)*(.92+rng()*.16);
 const audience=Math.max(1,Math.round(base*multiplier)),revenue=own?Math.round(audience*.042+ep.quality*95):Math.round(sh.fee*(fansScore>=75?1.16:1));
 const previous=sh.episodes.filter(e=>e.status==='aired').at(-1),likes=Math.round(audience*clamp(fansScore/100*.52,0,.65)),favorites=Math.round(likes*clamp((story/100)*.19+(isFilm(sh)?.01:.04),.01,.3));
 ep.status='aired';ep.airWeek=s.week;ep.viewers=Math.round(fansScore);ep.critics=Math.round(critics);ep.viewership=audience;ep.likes=likes;ep.favorites=favorites;ep.reviewCount=Math.round(audience*(.015+critics/100*.025));ep.negativeReviews=Math.round(ep.reviewCount*(1-critics/100));ep.controversial=debate;ep.revenue=revenue;ep.netProduction=revenue-ep.budget;ep.artificial=artificial;
 ep.distribution={...dist,reach:net?.reach||.75,trend:sh.genre===s.trend,hype:sh.hype,reputation:s.reputation,marketing:s.upgrades.marketing};
 ep.comparison=previous?{id:previous.id,title:previous.title,views:audience-previous.viewership,public:ep.viewers-previous.viewers,critics:ep.critics-previous.critics}:null;
 ep.comments=commentThread(sh,ep,fs,rng);ep.reviewCritic=ep.comments.find(c=>c.role==='Crítico')?.text||ep.comments[0]?.text||'';ep.reviewFan=ep.comments.find(c=>c.role==='Fã')?.text||ep.comments.at(-1)?.text||'';
 changeCash(revenue,'Exibição '+unitLabel(sh,ep)+': '+sh.name);sh.totalViewers+=audience;const aired=sh.episodes.filter(e=>e.status==='aired');sh.avgAudience=Math.round(sh.totalViewers/aired.length);sh.avgCritics=Math.round(aired.reduce((a,e)=>a+e.critics,0)/aired.length);sh.hype=clamp(sh.hype+(fansScore-50)/16+(debate?3:0),0,75);
 const newFans=Math.round(audience*fansScore/100*.025);sh.fanBase+=newFans;s.fans+=newFans;ep.newFans=newFans;s.reputation=clamp(s.reputation+(critics>=80?2:critics<40?-2:0),0,100);s.counts.air++;s.counts.revenue+=revenue;if(fansScore>=70)s.counts.reviews4++;
 log(`${sh.name} ${unitLabel(sh,ep)}: ${compact(audience)} visualizações, ${compact(likes)} gostei, ${compact(favorites)} favoritos. Crítica ${ep.critics}/100; resultado de produção ${money(ep.netProduction)}.`);
 return{show:sh.name,showId:sh.id,episodeId:ep.id,episode:ep.number,season:ep.season,kind:sh.kind,viewers:ep.viewers,critics:ep.critics,audience,revenue,controversial:debate};
};
nextWeek=function(){if(s.difficulty==='director'&&!s.grantTaken)return notice('Apresente um mini roteiro e aceite financiamento antes de avançar a campanha.',true);
 let reports=[];s.week++;const expense=hiredCost()+overhead();changeCash(-expense,'Folha de pagamento e manutenção');
 for(const sh of s.shows){for(const ep of sh.episodes){if(ep.status==='produced'&&ep.airWeek<=s.week&&!s.networks.some(n=>n.id===sh.networkId&&n.paused))reports.push(airEpisode(sh,ep));}
 if(sh.status==='active'&&seasonCompleted(sh)){sh.status=isFilm(sh)?'ended':'between';log(isFilm(sh)?`${sh.name} concluiu sua exibição. Filme finalizado, sem renovação de temporada.`:`${sh.name} concluiu a temporada ${sh.season}.`);}}
 if(s.week%4===0){s.trend=genres[dice(Math.min(genres.length,3+s.level*2))];log('Gênero em alta: '+s.trend+'.');}if(s.week%5===0)s.shows.filter(x=>x.status==='active').forEach(sh=>sh.hype=clamp(sh.hype-4,0,75));
 if(s.cash<0){s.reputation=clamp(s.reputation-3,0,100);log('Caixa negativo: compare salários, manutenção e resultado por produção antes de investir.');}
 addXP(reports.length*8+2);s.history.push({week:s.week,cash:s.cash,fans:s.fans,viewers:reports.reduce((a,r)=>a+r.audience,0),aired:reports.length});s.history=s.history.slice(-60);currentEnd={week:s.week,expense,reports,net:reports.reduce((a,r)=>a+r.revenue,0)-expense};checkGoals();save();tab='end';render();
};
const originalRenew=renew;renew=function(showId){if(isFilm(showBy(showId)||{}))return notice('Filmes têm uma exibição completa e não renovam temporadas.',true);originalRenew(showId);};
function marketEpoch(now=Date.now()){return Math.floor(now/300000);}
function availableTalent(t,epoch=marketEpoch()){return t.role!=='Atuação'||seeded(s.campaignId+'|'+epoch+'|'+t.id)()<t.chance/100;}
hireTalent=function(talentId){const t=talents.find(t=>t.id===talentId);if(!t||s.hired.includes(talentId))return;if(!availableTalent(t))return notice('A agência mudou. Esse ator não está mais disponível neste ciclo.',true);
 const upfront=t.salary*2;if(s.cash<upfront)return notice('Contratação exige '+money(upfront)+', mais '+money(t.salary)+'/semana depois.',true);changeCash(-upfront,'Contratação: '+t.name);s.hired.push(t.id);s.counts.hire++;addXP(12);log(t.name+' contratado. '+money(upfront)+' pagos agora; '+money(t.salary)+' por semana.');update();notice('Talento contratado. A disponibilidade não afeta quem já está na equipe.');};
function fireTalent(talentId){const t=talents.find(t=>t.id===talentId);if(!t||!s.hired.includes(talentId))return;if(!confirm('Dispensar '+t.name+'? O salário deixa de ser cobrado; produções já gravadas mantêm o elenco registrado.'))return;s.hired=s.hired.filter(x=>x!==talentId);log(t.name+' dispensado: redução de '+money(t.salary)+'/semana.');update();}

function difficultyCards(){return `<div class="difficulty-grid">${Object.entries(DIFFICULTIES).map(([key,d])=>`<label class="difficulty-card"><input type="radio" name="difficulty" value="${key}" required><span><b>${d.name}</b><strong>${money(d.cash)}</strong><small>${key==='hard'?'1 impulso aleatório':key==='director'?'Sem impulsos':d.boosts+' de cada impulso'}</small><p>${d.desc}</p></span></label>`).join('')}</div>`;}
intro=function(){return `<main class="intro" style="max-width:800px;padding:20px"><div class="brand"><span class="tvicon">◈</span><div><h1>EMPIRE TV</h1><p>Cinema e televisão · Beta</p></div></div><h1>Seu estúdio.<br>Suas consequências.</h1><p>Escolha a dificuldade antes de começar. ${campaignSetup?'A campanha atual será arquivada na sua conta.':'Cada conta guarda sua própria campanha.'}</p><form data-action="start"><label class="label">Nome da produtora</label><input name="name" minlength="2" maxlength="45" required value="Estúdio Prime"><h2 style="margin-top:24px">Como você quer dirigir?</h2>${difficultyCards()}<button class="primary" type="submit" style="width:100%;margin-top:20px">Criar campanha →</button></form>${campaignSetup?'<button class="ghost" data-cancel-campaign style="margin-top:15px">Voltar à campanha atual</button>':`<button class="ghost" data-logout style="margin-top:15px">Trocar conta</button>`}${getOldSave()?'<button class="ghost" data-legacy style="margin:15px">Importar progresso antigo</button>':''}</main>`;};
function storyInputs(sh){const story=sh?.story||{};return `<label class="label">Premissa / sinopse</label><textarea name="concept" maxlength="2500" placeholder="Quem é o protagonista, o que ele quer e o que o impede?">${esc(sh?.concept||'')}</textarea><div class="formgrid"><div><label class="label">Motivação do protagonista</label><textarea name="motivation" maxlength="600" placeholder="Por que essa missão importa? O que ele perde?">${esc(story.motivation||'')}</textarea></div><div><label class="label">Conflito e risco</label><textarea name="conflict" maxlength="600" placeholder="Qual obstáculo força uma decisão?">${esc(story.conflict||'')}</textarea></div></div><label class="label">Desfecho / consequência</label><textarea name="payoff" maxlength="600" placeholder="Qual escolha resolve o conflito? Em série, o que é resolvido e qual gancho fica?">${esc(story.payoff||'')}</textarea>`;}
newShowForm=function(){const available=genres.filter(genreUnlocked),cost=s.difficulty==='director'?0:Math.round(12000*policy().cost);return `<div class="card"><span class="eyebrow">DESENVOLVIMENTO</span><h3 style="margin-top:10px">Série ou filme?</h3><p>O formato muda o custo, o contrato e o comportamento do público em cada plataforma.</p><form data-action="createShow"><label class="label">Título da obra</label><input name="name" minlength="3" maxlength="65" required placeholder="Ex.: A Última Frequência"><div class="formgrid"><div><label class="label">Formato</label><select name="kind" data-kind><option value="series">Série · temporadas de 6 episódios</option><option value="film">Filme · história completa</option></select></div><div><label class="label">Gênero</label><select name="genre">${available.map(g=>`<option>${esc(g)}</option>`).join('')}</select></div></div><label class="label">Duração de cada episódio / filme</label><select name="duration" data-duration><option value="30">30 min</option><option value="45" selected>45 min</option><option value="60">60 min</option></select><p class="small muted" data-format-help>Série: retorno semanal; streaming favorece acompanhamento. A TV aberta tem público mais casual.</p>${storyInputs()}<button class="primary" type="submit">Desenvolver · ${money(cost)}</button></form><p class="tiny muted">${cost===0?'Conceitos são gratuitos. O financiamento inicial é único por campanha.':'O desenvolvimento é descontado agora; filmagem e divulgação são custos separados.'}</p></div>`;};
function fundingPanel(sh){if(s.difficulty!=='director'||s.grantTaken||sh.status!=='development')return'';return `<details open><summary>Apresentar mini roteiro para financiamento</summary><p>Explique abertura, virada, decisão e consequência. Cada estúdio avalia os sinais do argumento e a afinidade com o gênero. Você pode revisar e tentar novamente sem custo.</p><form data-action="funding"><input type="hidden" name="showId" value="${sh.id}"><label class="label">Estúdio</label><select name="studio">${STUDIOS.map(x=>`<option value="${x.id}">${x.name} · ${x.focus.slice(0,3).join(', ')}</option>`).join('')}</select><label class="label">Mini roteiro (mínimo 20 palavras)</label><textarea name="script" maxlength="3500" required placeholder="Cena de abertura... Obstáculo... Por isso, o protagonista decide... A consequência é..."></textarea><button class="primary" type="submit">Enviar proposta</button></form><div class="rows" style="margin-top:12px">${sh.funding.offers.map(o=>`<div class="funding-offer"><div class="between"><b>${esc(o.studio)}</b><span class="pill ${o.accepted?'green':'red'}">${o.accepted?money(o.amount):'Revisão solicitada'}</span></div><p>Argumento: ${o.score}/100 · ${o.match?'Gênero dentro do foco do estúdio':'Gênero fora do foco'}${o.durationFactor<1?' · Duração longa: verba ×0,82':''}</p>${o.feedback.map(f=>`<p class="tiny"><b>${f.label}: ${f.score}/100</b> · ${esc(f.evidence)} ${f.score<65?esc(f.advice):''}</p>`).join('')}${o.accepted?`<button class="secondary" data-accept-funding="${sh.id}" data-studio="${o.studioId}">Aceitar ${money(o.amount)}</button>`:''}</div>`).join('')}</div></details>`;}
showTile=function(sh){let html=originalTile(sh);html=html.replace(/Produzir episódio/g,isFilm(sh)?'Produzir filme':'Produzir episódio').replace(/Encerrar série/g,'Encerrar obra').replace(/Ver episódios/g,isFilm(sh)?'Ver resultado do filme':'Ver episódios');
 if(isFilm(sh)){html=html.replace('Temporada<strong>','Filme · duração<strong>').replace(`${sh.season} · ${seasonAired(sh)}/${sh.episodesPerSeason}</strong>`,`${sh.duration} min</strong>`).replace('Temporada '+sh.season,'Filme').replace('episódios restantes','exibição restante');}
 const extra=`<div class="line"></div><div class="between"><span class="pill cyan">${isFilm(sh)?'FILME':'SÉRIE'} · ${sh.duration} min</span><span class="tiny muted">${sh.funding.accepted?'Financiado por '+esc(sh.funding.accepted.studio):''}</span></div>${fundingPanel(sh)}<details><summary>Argumento e decisões de roteiro</summary><form data-action="editStory"><input type="hidden" name="showId" value="${sh.id}">${storyInputs(sh)}<button class="secondary" type="submit">Salvar revisão para próximas gravações</button></form><p class="tiny">A revisão modifica produções futuras. Os relatórios já exibidos preservam o argumento gravado.</p></details>${sh.status==='active'?`<form data-action="schedule"><input type="hidden" name="showId" value="${sh.id}"><div class="formgrid"><div><label class="label">Dia de exibição</label><select name="day">${['Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'].map(d=>`<option ${sh.day===d?'selected':''}>${d}</option>`).join('')}</select></div><div><label class="label">Horário</label><select name="slot">${['16:00','18:00','20:00','22:00','00:00'].map(h=>`<option ${sh.slot===h?'selected':''}>${h}</option>`).join('')}</select></div></div><p class="tiny">${esc(distribution(sh).why)} Horário nobre 20h: +18%; madrugada: −36%. Streaming não usa o bônus de horário.</p><button class="ghost" type="submit">Atualizar exibição</button></form>`:''}`;
 return html.slice(0,-6)+extra+'</div>';
};
scheduleShow=function(fd){const sh=showBy(fd.get('showId'));if(!sh)return;const day=String(fd.get('day')),slot=String(fd.get('slot'));if(!['Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'].includes(day)||!['16:00','18:00','20:00','22:00','00:00'].includes(slot))return;sh.day=day;sh.slot=slot;log(sh.name+': grade atualizada para '+day+' às '+slot+'.');update();notice('Grade atualizada. A nova faixa afeta a próxima exibição.');};
shows=function(){return `<section class="section"><div class="head"><h2>Seu catálogo de séries e filmes</h2><span class="pill">${activeCount()}/${capacity()} ativos</span></div><p class="subhead">Escolha o formato, escreva o argumento e distribua sua obra. Resultados ficam disponíveis por episódio ou filme.</p><div class="grid"><div>${newShowForm()}</div><div class="rows">${s.shows.length?s.shows.slice().reverse().map(showTile).join(''):'<div class="empty">Seu primeiro projeto começa com uma ideia.</div>'}</div></div></section>`;};
productionForm=function(sh){const done=seasonAired(sh)+seasonProduced(sh);if(sh.episodes.some(e=>e.status==='produced'&&e.season===sh.season)||done>=sh.episodesPerSeason)return '<div class="info">Produção pronta. Avance a semana para conferir os resultados.</div>';
 const actors=hired('Atuação');return `<form data-action="produce" data-preview="${sh.id}"><input type="hidden" name="showId" value="${sh.id}"><label class="label">${isFilm(sh)?'Título do filme':'Título do episódio'}</label><input name="epTitle" maxlength="75" placeholder="${esc(isFilm(sh)?sh.name:'Episódio '+(done+1))}"><label class="label">Mini roteiro desta produção</label><textarea name="script" maxlength="3500" placeholder="O que acontece neste episódio ou filme? Escreva a abertura, a virada e uma consequência."></textarea><div class="formgrid"><div><label class="label">Investimento equivalente a 45 min</label><select name="budget">${[15000,30000,45000,65000,95000,170000].map(n=>`<option value="${n}" ${n===30000?'selected':''}>${money(n)}</option>`).join('')}</select></div><div><label class="label">Divulgação</label><select name="promo">${[0,5000,10000,20000].map(n=>`<option value="${n}">${n?money(n):'Sem campanha'}</option>`).join('')}</select></div><div><label class="label">Protagonista</label><select name="actor">${actors.length?actors.map(t=>`<option value="${t.id}">${esc(t.name)} · ${t.skill} técnica · ${esc(t.genre)}</option>`).join(''):'<option value="">Elenco de apoio · técnica 38</option>'}</select></div><div><label class="label">Impulso</label><select name="boost"><option value="">Nenhum</option>${s.difficulty==='director'?'':POWERUPS.filter(k=>s.boosts[k]>0).map(k=>`<option value="${k}">${({inspiracao:'Qualidade +15',audiencia:'Audiência +40%',desconto:'Custo −28%'})[k]} · ${s.boosts[k]}</option>`).join('')}</select></div></div><div class="info" data-cost-preview>Estimativa: ${money(costPreview(sh,30000,0,''))} · ${sh.duration} min · dificuldade ${policy().name}</div><details><summary>Direção criativa · 12 decisões com consequências</summary><div class="formgrid">${elements.map((label,i)=>`<div><label class="label">${label}</label><select name="dir${i}">${DIR_OPTIONS[i].map((v,j)=>`<option value="${j}" ${j===1?'selected':''}>${v}</option>`).join('')}</select><p class="tiny muted">${DIR_HELP[i]}</p></div>`).join('')}</div></details><p class="tiny muted">O orçamento é proporcional à duração. Divulgação aumenta o alcance, sem melhorar o roteiro. Elenco e infraestrutura entram na qualidade técnica.</p><button class="primary" type="submit">Produzir ${isFilm(sh)?'filme':`T${sh.season}E${done+1}`}</button></form>`;
};
production=function(){const active=s.shows.filter(x=>x.status==='active');return `<section class="section"><div class="head"><h2>Sala de produção</h2><span class="pill cyan">${esc(s.trend)} em alta</span></div><p class="subhead">Veja o custo antes de confirmar. A obra estreia na próxima semana; decisões e equipe ficam registradas na gravação.</p><div class="rows">${active.length?active.map(sh=>`<div class="card" id="production-${sh.id}"><span class="tag">${isFilm(sh)?'FILME':'TEMPORADA '+sh.season} · ${sh.duration} min</span><h3>${esc(sh.name)}</h3><p>${esc(sh.genre)} · ${esc(networkBy(sh.networkId)?.name||'Independente')} · ${isFilm(sh)?'Licença do filme':'Licença por episódio'} ${money(sh.fee)}</p><div class="line"></div>${productionForm(sh)}</div>`).join(''):'<div class="empty"><b>Sem obras aprovadas</b>Desenvolva e distribua um projeto no catálogo.<div class="btnrow"><button class="primary" data-tab="shows">Abrir catálogo</button></div></div>'}</div></section>`;};
function talentCard(t,employed=false){return `<div class="card"><div class="between"><div><span class="tag">${esc(t.role)}</span><h3>${esc(t.name)}</h3></div><span class="pill ${employed?'green':'cyan'}">${t.skill} técnica</span></div><p>Especialidade: ${esc(t.genre)} · +12 técnica em obras desse gênero.</p><div class="mini-grid"><div>Salário semanal<strong>${money(t.salary)}</strong></div><div>Taxa de aparição<strong>${t.role==='Atuação'?t.chance+'%':'Sempre'}</strong></div></div><p class="tiny">${t.role==='Atuação'?'A taxa é a chance de estar disponível em cada ciclo de 5 min.':'Profissional de apoio; disponível em todos os ciclos.'} Quem já foi contratado permanece na equipe.</p><button class="${employed?'danger':'secondary'}" ${employed?`data-fire="${t.id}"`:`data-hire="${t.id}"`} style="margin-top:8px">${employed?'Dispensar':'Contratar · '+money(t.salary*2)}</button></div>`;}
function marketCards(){return talents.filter(t=>!s.hired.includes(t.id)&&availableTalent(t)).map(t=>talentCard(t)).join('')||'<div class="empty">Nenhum talento disponível neste ciclo. Aguarde a renovação.</div>';}
team=function(){return `<section class="section"><div class="head"><h2>Agência de talentos</h2><span class="pill orange">${money(hiredCost())}/semana</span></div><p class="subhead">Duas semanas de salário na contratação. A técnica melhora a produção; afinidade de gênero dá +12. Selecionar o protagonista influencia a gravação.</p><div class="info between wrap"><span>Lista renova a cada 5 minutos reais, inclusive com o jogo fechado.</span><b data-market-timer></b></div><details><summary>Quem pode aparecer? Consulte todas as probabilidades</summary><div class="scroll"><table class="table"><thead><tr><th>Ator</th><th>Chance por ciclo</th><th>Técnica</th><th>Gênero</th></tr></thead><tbody>${talents.filter(t=>t.role==='Atuação').map(t=>`<tr><td>${esc(t.name)}</td><td>${t.chance}%</td><td>${t.skill}</td><td>${esc(t.genre)}</td></tr>`).join('')}</tbody></table></div><p class="tiny">Probabilidade por ator, não porcentagem de exclusividade. Reabrir a tela não sorteia outra lista.</p></details><h3>Disponíveis agora</h3><div class="grid" id="market-list">${marketCards()}</div><h3 style="margin-top:24px">Sua equipe · ${s.hired.length}</h3><div class="grid">${hired().map(t=>talentCard(t,true)).join('')||'<div class="empty">Ainda não há profissionais contratados.</div>'}</div></section>`;};
function signed(n){return(n>0?'+':'')+compact(n);}
function episodeReport(sh,ep){const legacy=!ep.comments;return `<article class="card report" id="report-${ep.id}"><div class="between wrap"><div><span class="tag">${unitLabel(sh,ep)} · SEMANA ${ep.airWeek}</span><h3>${esc(ep.title)}</h3><p>${esc(sh.name)} · ${esc(sh.genre)}</p></div><span class="pill ${ep.artificial?'orange':'cyan'}">${ep.artificial?'AVALIAÇÃO ARTIFICIAL':'RELATÓRIO DA EXIBIÇÃO'}</span></div><div class="report-metrics"><div>Visualizações<strong>${compact(ep.viewership)}</strong></div><div>Críticas enviadas<strong>${legacy?'Não registrado':compact(ep.reviewCount)}</strong></div><div>Gostei<strong>${legacy?'Não registrado':compact(ep.likes)}</strong></div><div>Favoritos<strong>${legacy?'Não registrado':compact(ep.favorites)}</strong></div></div><div class="mini-grid" style="margin-top:10px"><div>Nota dos críticos<strong>${ep.critics}/100</strong></div><div>Nota dos fãs<strong>${ep.viewers}/100</strong></div><div>Receita de exibição<strong>${legacy?'Não registrado':money(ep.revenue)}</strong></div><div>Receita − produção<strong>${legacy?'Não registrado':money(ep.netProduction)}</strong></div></div><p class="tiny muted">${legacy?'Save anterior à versão 3.0: as métricas que não existiam não foram inventadas.':'Críticas enviadas contam as avaliações simuladas; '+compact(ep.negativeReviews)+' delas foram negativas. Gostei e favoritos são contagens. O resultado desconta filmagem e divulgação, mas não salários e manutenção semanais.'}</p>${ep.comparison?`<div class="info">Comparado com “${esc(ep.comparison.title)}”: ${signed(ep.comparison.views)} visualizações · ${signed(ep.comparison.public)} pontos de fãs · ${signed(ep.comparison.critics)} pontos de crítica.</div>`:''}${ep.analysis?`<details><summary>Por que tive esse resultado? · análise de decisões</summary><p class="tiny">Notas simuladas pelo motor local a partir das decisões e dos sinais escritos. Cada detalhe abaixo registra a causa e uma direção de revisão.</p><div class="rows">${ep.analysis.map(f=>`<div class="analysis-row"><div class="between"><b>${f.label}</b><span class="pill ${f.score<60?'red':'green'}">${f.score}/100</span></div><p>${esc(f.evidence)}</p><p class="advice">Próximo teste: ${esc(f.advice)}</p></div>`).join('')}</div></details>`:''}${ep.distribution?`<details><summary>Como distribuição e dinheiro afetaram a obra</summary><p>${esc(ep.distribution.why)}</p><p>Alcance da rede: ×${ep.distribution.reach.toFixed(2)} · formato/plataforma: ×${ep.distribution.fit.toFixed(2)} · ${ep.distribution.trend?'gênero em alta: +20%':'sem bônus de tendência'} · ${ep.boostAudience?'impulso de audiência: +40%':'sem impulso de audiência'}.</p><p>Investimento de filmagem: ${money(ep.baseBudget)} · divulgação: ${money(ep.promo)} · custo total: ${money(ep.budget)}. Fãs conquistados: ${compact(ep.newFans)}.</p><p class="tiny">Receita parceira: licença contratada, com bônus de 16% para nota dos fãs ≥75. Rede própria: publicidade proporcional ao alcance.</p></details>`:''}<details ${s.difficulty==='director'?'open':''}><summary>Comentários da exibição · ${ep.comments?.length||2} destaques</summary><p class="tiny muted">Comunidade fictícia simulada. Os destaques não correspondem ao total de avaliações.</p><div class="comments">${ep.comments?.map(c=>`<div class="comment ${c.parent?'reply':''}"><div class="between"><b>@${esc(c.user)}</b><span class="tag">${c.role}</span></div><p>${esc(c.text)}</p><small>♡ ${compact(c.likes)}</small></div>`).join('')||`<div class="comment"><p>${esc(ep.reviewCritic)}</p></div><div class="comment"><p>${esc(ep.reviewFan)}</p></div>`}</div></details></article>`;}
episodeHistory=function(sh){return `<div class="line"></div><div class="rows">${sh.episodes.slice().reverse().map(ep=>ep.status==='aired'?episodeReport(sh,ep):`<div class="info">${esc(ep.title)} · ${unitLabel(sh,ep)} · estreia na semana ${ep.airWeek}. Qualidade prevista: ${ep.quality}/100.</div>`).join('')}</div>`;};
function reportsPage(){const items=s.shows.flatMap(sh=>sh.episodes.filter(e=>e.status==='aired').map(ep=>({sh,ep}))).sort((a,b)=>b.ep.airWeek-a.ep.airWeek||b.ep.id-a.ep.id);return `<section class="section"><div class="head"><h2>Observatório de audiência</h2><span class="pill">${items.length} exibições</span></div><p class="subhead">Abra o resultado de cada episódio ou filme: alcance, críticas, gostei, favoritos e decisões que explicam a recepção.</p><div class="rows">${items.map(({sh,ep})=>`<details><summary>${esc(sh.name)} · ${unitLabel(sh,ep)} · ${compact(ep.viewership)} visualizações</summary>${episodeReport(sh,ep)}</details>`).join('')||'<div class="empty">Produza e exiba uma obra para ver o primeiro relatório.</div>'}</div></section>`;}
endPage=function(){const e=currentEnd;return `<section class="section"><div class="endsummary"><span class="eyebrow">SEMANA ${s.week} CONCLUÍDA</span><h2>O que mudou no seu estúdio?</h2><div class="mini-grid"><div>Exibições<strong>${e?.reports.length||0}</strong></div><div>Custos fixos<strong>${money(e?.expense||0)}</strong></div><div>Saldo semanal<strong>${money(e?.net||0)}</strong></div><div>Caixa<strong>${money(s.cash)}</strong></div></div><p class="tiny">O saldo semanal inclui receitas de exibição e custos fixos; produção foi paga antes, na gravação.</p></div><div class="rows">${e?.reports.map(r=>episodeReport(showBy(r.showId),showBy(r.showId).episodes.find(x=>x.id===r.episodeId))).join('')||'<div class="empty">Nenhuma estreia. Grave uma obra para movimentar a programação.</div>'}</div><div class="btnrow"><button class="primary" data-tab="home">Voltar ao estúdio</button><button class="secondary" data-tab="reports">Todos os relatórios</button></div></section>`;};
home=function(){let html=originalHome().replace(/Criar primeira série/g,'Criar primeira obra').replace(/Criar nova série/g,'Criar série ou filme').replace(/séries ativas/g,'obras ativas').replace(/Capacidade: ([^<]+) séries/g,'Capacidade: $1 obras').replace(/Séries produzidas/g,'Obras criadas');return `<div class="info between wrap"><div><b>Campanha ${policy().name}</b><div class="tiny">${s.difficulty==='director'&&!s.grantTaken?'Sem verba: desenvolva um conceito gratuito, escreva o mini roteiro e busque financiamento.':policy().desc}</div></div><button class="secondary" data-tab="reports">Resultados por obra</button></div>${html}`;};
settings=function(){const html=originalSettings().replace('V2.0 PREMIUM','V3.0 DIRETOR').replace('Empire TV v2.0','Empire TV v3.0').replace('Esta ação substitui o jogo salvo desta conta, mas não afeta os demais usuários.','A campanha atual é arquivada. Escolha outra dificuldade sem perder sua conta. Até 8 campanhas anteriores ficam disponíveis.').replace('Reiniciar somente meu progresso','Começar nova campanha');return html+`<div class="card"><h3>Campanhas arquivadas</h3><p>Campanha atual: ${esc(s.name)} · ${policy().name}. Retomar uma campanha também arquiva a atual.</p><div class="rows">${s.campaignArchive.map(c=>`<div class="between wrap"><div><b>${esc(c.name)}</b><p>${DIFFICULTIES[c.difficulty]?.name||'Médio'} · semana ${c.week} · ${money(c.cash)}</p></div><button class="secondary" data-resume="${esc(c.campaignId)}">Retomar</button></div>`).join('')||'<p>Nenhuma campanha arquivada.</p>'}</div></div>`;};
function resumeCampaign(cid){const index=s.campaignArchive.findIndex(c=>c.campaignId===cid);if(index<0)return;const list=s.campaignArchive.slice(),next=list.splice(index,1)[0],old=JSON.parse(JSON.stringify(s));delete old.campaignArchive;next.campaignArchive=[old,...list].slice(0,8);s=migrateV3(next);currentEnd=null;tab='home';formDefaults={};update();notice('Campanha retomada.');}
render=function(){migrateV3(s);if(account&&campaignSetup){root.innerHTML=intro();return;}if(account&&s&&tab==='reports'){root.innerHTML=`<div class="app">${basic()}${reportsPage()}</div><nav class="nav">${tabButton('home','⌂','Início')}${tabButton('shows','▣','Catálogo')}${tabButton('reports','◎','Resultados')}${tabButton('settings','⚙','Configurações')}</nav>`;return;}originalRender();if(s&&account){const nav=root.querySelector('.nav');if(nav){nav.innerHTML=nav.innerHTML.replace('Séries</button>','Catálogo</button>')+tabButton('reports','◎','Resultados')+tabButton('settings','⚙','Configurações');}root.querySelectorAll('.brand .pill').forEach(p=>p.textContent='3.0');root.querySelectorAll('.dev').forEach(p=>p.textContent='Empire TV 3.0 · Simulação independente · '+account.username);}};
root.addEventListener('submit',e=>{const form=e.target.closest('form[data-action]');if(!form||!account)return;const action=form.dataset.action;if(!['start','funding','editStory'].includes(action))return;e.preventDefault();e.stopImmediatePropagation();const fd=new FormData(form);if(action==='start')startGame(String(fd.get('name')||''),String(fd.get('difficulty')||''));else if(action==='funding')evaluateFunding(fd);else editStory(fd);},true);
root.addEventListener('click',e=>{const b=e.target.closest('[data-reset],[data-cancel-campaign],[data-resume],[data-accept-funding],[data-fire]');if(!b||!account||!s)return;e.preventDefault();e.stopImmediatePropagation();if(b.hasAttribute('data-reset')){campaignSetup=true;render();window.scrollTo(0,0);}else if(b.hasAttribute('data-cancel-campaign')){campaignSetup=false;render();}else if(b.dataset.resume)resumeCampaign(b.dataset.resume);else if(b.dataset.acceptFunding)acceptFunding(b.dataset.acceptFunding,b.dataset.studio);else if(b.dataset.fire)fireTalent(b.dataset.fire);},true);
root.addEventListener('change',e=>{const form=e.target.closest('form');if(!form)return;if(e.target.matches('[data-kind]')){const film=e.target.value==='film',select=form.querySelector('[data-duration]');select.innerHTML=(film?[60,90,120,150]:[30,45,60]).map(n=>`<option value="${n}" ${n===(film?90:45)?'selected':''}>${n} min</option>`).join('');form.querySelector('[data-format-help]').textContent=film?'Filme: história completa em uma exibição. Duração aumenta o orçamento; TV aberta favorece filmes até 100 min.':'Série: retorno semanal; streaming favorece acompanhamento. TV aberta tem público mais casual.';}
 if(form.dataset.preview){const sh=showBy(form.dataset.preview),fd=new FormData(form),cost=costPreview(sh,Number(fd.get('budget')),Number(fd.get('promo')),String(fd.get('boost')));form.querySelector('[data-cost-preview]').textContent=`Custo total: ${money(cost)} · ${sh.duration} min · caixa após produção: ${money(s.cash-cost)}. ${cost>s.cash?'Saldo insuficiente.':''}`;}
});


/* Empire TV beta — curated references. Game ratings are fictional balancing data. */
const BETA_ROLES=['Showrunner','Roteirista','Direção','Atuação','Marketing','Dublagem'];
const ROLE_LABELS={Showrunner:'Showrunner',Roteirista:'Roteiristas',Direção:'Direção',Atuação:'Atuação',Marketing:'Marketing',Dublagem:'Dublagem'};
const TALENT_REFERENCES=[
// role, humorous name, research reference, specialties, career reference, technique, fame, recruitment weight, source
['Showrunner','Vinci Giligã','Vince Gilligan',['Policial','Drama'],'Breaking Bad / Better Call Saul',97,95,6,'tv:vince-gilligan'],
['Showrunner','Xonda Rimas','Shonda Rhimes',['Drama','Romance'],'Grey’s Anatomy / Scandal',96,96,5,'tv:shonda-rhimes'],
['Showrunner','Davi Chaseiro','David Chase',['Policial','Drama'],'The Sopranos',96,87,8,'tv:david-chase'],
['Showrunner','Davi Simão','David Simon',['Policial','Documentário'],'The Wire',97,85,8,'tv:david-simon'],
['Showrunner','Jessé Braço Forte','Jesse Armstrong',['Drama','Comédia'],'Succession',96,88,9,'tv:jesse-armstrong'],
['Showrunner','Dan Harmonia','Dan Harmon',['Comédia','Ficção científica'],'Community / Rick and Morty',91,87,16,'tv:dan-harmon'],
['Showrunner','Maico Xur','Michael Schur',['Comédia','Fantasia'],'The Good Place / Parks and Recreation',94,84,15,'tv:michael-schur'],
['Showrunner','Chuck Louri','Chuck Lorre',['Comédia','Reality'],'The Big Bang Theory',90,93,12,'tv:chuck-lorre'],
['Showrunner','Raian Múrfi','Ryan Murphy',['Drama','Terror'],'American Horror Story / Glee',92,95,10,'tv:ryan-murphy'],
['Showrunner','Issa Rainha','Issa Rae',['Comédia','Romance'],'Insecure',91,82,23,'tv:issa-rae'],
['Showrunner','Mika Ela Coelha','Michaela Coel',['Drama','Comédia'],'I May Destroy You',95,81,17,'tv:michaela-coel'],
['Showrunner','Lena Dunrã','Lena Dunham',['Comédia','Drama'],'Girls',88,79,25,'tv:lena-dunham'],
['Showrunner','Daimon Linda Lof','Damon Lindelof',['Ficção científica','Suspense'],'Lost / Watchmen',94,89,12,'tv:damon-lindelof'],
['Showrunner','Jota Jota Abre Alas','J.J. Abrams',['Ficção científica','Ação'],'Lost / Alias',91,94,10,'tv:jj-abrams'],
['Showrunner','Amy Xermã Paladino','Amy Sherman-Palladino',['Comédia','Drama'],'Gilmore Girls / The Marvelous Mrs. Maisel',95,83,16,'tv:amy-sherman-palladino'],
['Showrunner','Mati Dúfer','Matt Duffer',['Terror','Ficção científica'],'Stranger Things',91,87,16,'netflix:duffers'],
['Showrunner','Rossi Dúfer','Ross Duffer',['Suspense','Ficção científica'],'Stranger Things',91,87,16,'netflix:duffers'],
['Showrunner','Noé Ráuli','Noah Hawley',['Policial','Suspense'],'Fargo / Legion',94,80,19,'tv:noah-hawley'],
['Roteirista','Xarli Cafemã','Charlie Kaufman',['Drama','Ficção científica'],'Eternal Sunshine of the Spotless Mind',98,83,6,'oscar:2005'],
['Roteirista','Arão Sorkim','Aaron Sorkin',['Drama','Policial'],'The Social Network',96,90,8,'oscar:2011'],
['Roteirista','Nora É Fron','Nora Ephron',['Romance','Comédia'],'When Harry Met Sally...',94,85,12,'oscar:1990'],
['Roteirista','Diabla Códia','Diablo Cody',['Comédia','Drama'],'Juno',93,79,22,'oscar:2008'],
['Roteirista','Fibi Uóler Ponte','Phoebe Waller-Bridge',['Comédia','Drama'],'Fleabag',96,86,12,'tv:phoebe-waller-bridge'],
['Roteirista','Raian Jônsson','Rian Johnson',['Policial','Suspense'],'Knives Out',94,86,13,'oscar:2020'],
['Roteirista','Quenti Tarantela','Quentin Tarantino',['Policial','Ação'],'Pulp Fiction / Django Unchained',97,97,5,'oscar:2013'],
['Roteirista','Paulo Xráder','Paul Schrader',['Drama','Suspense'],'First Reformed',95,80,16,'oscar:2019'],
['Roteirista','Estevão Zailhã','Steven Zaillian',['Drama','Policial'],'Schindler’s List / The Irishman',96,81,12,'oscar:2020'],
['Roteirista','Cris MacQuéri','Christopher McQuarrie',['Suspense','Ação'],'The Usual Suspects',94,89,13,'oscar:1996'],
['Roteirista','Teilor Xéridã','Taylor Sheridan',['Policial','Drama'],'Hell or High Water',93,90,14,'oscar:2017'],
['Roteirista','Celina Som','Celine Song',['Romance','Drama'],'Past Lives',92,78,23,'oscar:2024'],
['Roteirista','Esmeralda Funel','Emerald Fennell',['Suspense','Drama'],'Promising Young Woman',93,80,20,'oscar:2021'],
['Roteirista','Justina Triê','Justine Triet',['Policial','Drama'],'Anatomy of a Fall',96,81,14,'oscar:2024'],
['Roteirista','Toni Cuxiner','Tony Kushner',['Drama','Romance'],'Lincoln',96,80,14,'oscar:2013'],
['Roteirista','Juliano Félios','Julian Fellowes',['Drama','Romance'],'Gosford Park / Downton Abbey',94,87,14,'oscar:2002'],
['Roteirista','Rã Jin Uón','Han Jin Won',['Suspense','Drama'],'Parasite',93,75,22,'oscar:2020'],
['Roteirista','Cordi Jefersão','Cord Jefferson',['Comédia','Drama'],'American Fiction',93,77,24,'oscar:2024'],
['Direção','Estevão Espielburgo','Steven Spielberg',['Ação','Ficção científica'],'Jurassic Park / Schindler’s List',99,99,3,'oscar:1994'],
['Direção','Martim Escorseze','Martin Scorsese',['Policial','Drama'],'The Departed / The Irishman',99,98,4,'oscar:2007'],
['Direção','Cris Nulã','Christopher Nolan',['Ficção científica','Suspense'],'Inception / Oppenheimer',98,98,4,'oscar:2024'],
['Direção','Deni Vila Nova','Denis Villeneuve',['Ficção científica','Suspense'],'Arrival / Dune',97,94,7,'oscar:2017'],
['Direção','Jaiminho Câmeron','James Cameron',['Ficção científica','Ação'],'Titanic / Avatar',98,99,3,'oscar:1998'],
['Direção','Greta Gueruig','Greta Gerwig',['Comédia','Drama'],'Lady Bird / Barbie',96,93,8,'oscar:2018'],
['Direção','Bong João Rô','Bong Joon Ho',['Suspense','Drama'],'Parasite',98,93,6,'oscar:2020'],
['Direção','Parqui Xã Uqui','Park Chan-wook',['Suspense','Policial'],'Decision to Leave',97,87,10,'cannes:park'],
['Direção','Alfonso Cu Arão','Alfonso Cuarón',['Drama','Ficção científica'],'Roma / Gravity',98,91,7,'oscar:2019'],
['Direção','Guilhermo do Toro','Guillermo del Toro',['Fantasia','Terror'],'The Shape of Water / Pinocchio',97,93,7,'oscar:2018'],
['Direção','Raiao Miazaqui','Hayao Miyazaki',['Animação','Fantasia'],'Spirited Away / The Boy and the Heron',99,96,4,'oscar:2024'],
['Direção','Cati Biguelou','Kathryn Bigelow',['Ação','Drama'],'The Hurt Locker',97,86,12,'oscar:2010'],
['Direção','Petra Costura','Petra Costa',['Documentário','Drama'],'The Edge of Democracy',92,79,24,'oscar:2020'],
['Direção','Sofia Copola','Sofia Coppola',['Drama','Romance'],'Lost in Translation',95,86,13,'oscar:2004'],
['Direção','Raian Cúgler','Ryan Coogler',['Ação','Drama'],'Black Panther',96,92,10,'marvel:coogler'],
['Direção','Jordão Píli','Jordan Peele',['Terror','Suspense'],'Get Out',96,91,10,'oscar:2018'],
['Direção','Pedro Almodôvar','Pedro Almodóvar',['Drama','Romance'],'Talk to Her',98,89,8,'oscar:2003'],
['Direção','Taica Uaitíti','Taika Waititi',['Comédia','Fantasia'],'Jojo Rabbit',93,89,14,'oscar:2020'],
['Atuação','Wiu Ismiti','Will Smith',['Ação','Drama'],'King Richard',94,98,5,'oscar:2022'],
['Atuação','Lião Di Cápio','Leonardo DiCaprio',['Drama','Suspense'],'The Revenant',98,99,3,'oscar:2016'],
['Atuação','Morgão Frimã','Morgan Freeman',['Drama','Policial'],'Million Dollar Baby',97,98,5,'oscar:2005'],
['Atuação','Scarleta Johã','Scarlett Johansson',['Drama','Ficção científica'],'Marriage Story / Jojo Rabbit',95,97,6,'oscar:2020'],
['Atuação','Denzel Uóxintão','Denzel Washington',['Drama','Policial'],'Training Day / Fences',99,98,4,'oscar:2017'],
['Atuação','Meril Estripe','Meryl Streep',['Drama','Comédia'],'The Iron Lady',100,99,2,'oscar:2012'],
['Atuação','Viola Dá Vez','Viola Davis',['Drama','Suspense'],'Fences',99,95,5,'oscar:2017'],
['Atuação','Cati Uinsleti','Kate Winslet',['Drama','Romance'],'The Reader',97,95,6,'oscar:2009'],
['Atuação','Cati Blancheti','Cate Blanchett',['Drama','Fantasia'],'Blue Jasmine',99,96,4,'oscar:2014'],
['Atuação','Ema Estone','Emma Stone',['Comédia','Drama'],'La La Land / Poor Things',98,96,5,'oscar:2024'],
['Atuação','Mixeli Iô','Michelle Yeoh',['Ação','Ficção científica'],'Everything Everywhere All at Once',97,95,6,'oscar:2023'],
['Atuação','Tómi Ranks','Tom Hanks',['Drama','Comédia'],'Forrest Gump',98,99,4,'oscar:1995'],
['Atuação','Joaquim Fênix','Joaquin Phoenix',['Drama','Suspense'],'Joker',98,96,5,'oscar:2020'],
['Atuação','Tilda Suíntão','Tilda Swinton',['Drama','Fantasia'],'Michael Clayton',97,88,10,'oscar:2008'],
['Atuação','Lupita Ni Ongô','Lupita Nyong’o',['Drama','Terror'],'12 Years a Slave',97,89,10,'oscar:2014'],
['Atuação','Sandra Búloque','Sandra Bullock',['Drama','Comédia'],'The Blind Side',95,95,8,'oscar:2010'],
['Atuação','Xarlizi Terão','Charlize Theron',['Drama','Ação'],'Monster',97,94,7,'oscar:2004'],
['Atuação','Natália Portimã','Natalie Portman',['Drama','Ficção científica'],'Black Swan',97,94,7,'oscar:2011'],
['Atuação','Franci MacDormã','Frances McDormand',['Drama','Policial'],'Fargo / Nomadland',100,91,5,'oscar:2021'],
['Atuação','Zorze Clúni','George Clooney',['Drama','Comédia'],'Syriana',96,98,6,'oscar:2006'],
['Marketing','Su Crol','Sue Kroll',['Drama','Comédia'],'Marketing de estúdio / lançamentos globais',97,84,7,'marketing:kroll'],
['Marketing','Maico Mózes','Michael Moses',['Terror','Ação'],'Marketing cinematográfico / Universal',97,84,7,'marketing:universal'],
['Marketing','Joxi Goudstain','Josh Goldstine',['Comédia','Ação'],'Campanhas de cinema / Barbie',97,84,7,'marketing:goldstine'],
['Marketing','Marqui Uainstok','Marc Weinstock',['Animação','Ação'],'Marketing e distribuição / Paramount',94,78,12,'marketing:paramount'],
['Marketing','Dona Taubim','Dawn Taubin',['Animação','Fantasia'],'Marketing de animação / DreamWorks',94,76,13,'marketing:taubin'],
['Marketing','Timi Palém','Tim Palen',['Ação','Suspense'],'Franquias / Lionsgate',96,82,9,'marketing:palen'],
['Marketing','Téri Pressa','Terry Press',['Drama','Animação'],'Campanhas de cinema / DreamWorks',96,82,9,'marketing:press'],
['Marketing','Blair Rica','Blair Rich',['Ficção científica','Ação'],'Marketing e identidade de estúdio',95,79,11,'marketing:rich'],
['Marketing','Ana Globo','Anne Globe',['Animação','Ficção científica'],'Marcas de entretenimento / IMAX',95,78,12,'marketing:globe'],
['Marketing','Duaiti Cães','Dwight Caines',['Comédia','Terror'],'Marketing de cinema / Universal',94,77,14,'marketing:universal'],
['Dublagem','Tómi Quêni','Tom Kenny',['Animação','Comédia'],'SpongeBob SquarePants / Adventure Time',98,92,6,'voice:kenny'],
['Dublagem','Robi Paulzão','Rob Paulsen',['Animação','Comédia'],'Animaniacs / Goof Troop',98,87,8,'voice:disney'],
['Dublagem','Tara Forte','Tara Strong',['Animação','Fantasia'],'The Fairly OddParents',97,90,7,'voice:tara'],
['Dublagem','Nanci Cartão','Nancy Cartwright',['Animação','Comédia'],'The Simpsons / Goof Troop',98,90,6,'voice:simpsons'],
['Dublagem','Ranque Azária','Hank Azaria',['Comédia','Animação'],'The Simpsons',97,87,8,'voice:simpsons'],
['Dublagem','Dan Castelo Neto','Dan Castellaneta',['Comédia','Animação'],'The Simpsons',98,91,6,'voice:simpsons'],
['Dublagem','Franque Uélquer','Frank Welker',['Animação','Ação'],'Goof Troop / Transformers',99,91,5,'voice:disney'],
['Dublagem','Jimi Câmings','Jim Cummings',['Animação','Fantasia'],'The Tigger Movie / Goof Troop',98,90,6,'voice:tigger'],
['Dublagem','Marqui Ramil','Mark Hamill',['Suspense','Animação'],'Batman: The Animated Series',97,97,5,'voice:batman'],
['Dublagem','Quévim Conrói','Kevin Conroy',['Ação','Animação'],'Batman: The Animated Series',99,92,5,'voice:batman'],
['Dublagem','Jaimis Érli Jonis','James Earl Jones',['Fantasia','Drama'],'The Lion King',100,98,3,'voice:lion'],
['Dublagem','Jêni Fer Rale','Jennifer Hale',['Animação','Ficção científica'],'Cinderella III',97,85,9,'voice:cinderella'],
['Dublagem','Guilherme Brinks','Guilherme Briggs',['Ação','Animação'],'Superman / Buzz Lightyear (vozes em português)',97,94,6,'voice:brasil'],
['Dublagem','Uendel Bezêra','Wendel Bezerra',['Animação','Ação'],'Goku / SpongeBob (vozes em português)',98,95,5,'voice:brasil'],
['Dublagem','Miriã Fixa','Miriam Ficher',['Drama','Animação'],'Vozes em português de cinema e animação',95,84,11,'voice:brasil'],
['Dublagem','Manolo Reis','Manolo Rey',['Ação','Animação'],'Spider-Man / Scooby-Doo (vozes em português)',96,88,9,'voice:brasil']
];
const BETA_NETWORKS=[
['Netflix','Streaming',2.7,85000,86,['Drama','Ficção científica','Suspense'],'nf'],
['Praimi Video','Streaming',2.45,78000,82,['Ação','Drama','Comédia'],'pv'],
['HBO Máximo','Streaming',2.15,90000,91,['Drama','Policial','Fantasia'],'hbm'],
['Disnei+','Streaming',2.35,80000,85,['Animação','Fantasia','Ação'],'dp'],
['Maçã TV+','Streaming',1.75,95000,90,['Drama','Ficção científica','Documentário'],'apple'],
['Hululu','Streaming',1.8,66000,78,['Comédia','Drama','Suspense'],'hulu'],
['Paramonte+','Streaming',1.8,58000,77,['Ação','Policial','Animação'],'para'],
['Mubi Mundo','Streaming',.92,38000,87,['Drama','Documentário','Romance'],'mubi'],
['Crunchi Rolo','Streaming',1.45,44000,78,['Animação','Fantasia','Ação'],'cr'],
['Pavão Play','Streaming',1.6,55000,75,['Comédia','Reality','Policial'],'peac'],
['Globão Play','Streaming',1.7,55000,73,['Drama','Romance','Documentário'],'gp'],
['Telecine Play','Streaming',1.3,47000,72,['Drama','Ação','Suspense'],'tc'],
['Plutão TV','Streaming',1.15,29000,61,['Comédia','Ação','Documentário'],'plu'],
['Viki Vê','Streaming',1.05,34000,70,['Romance','Drama','Comédia'],'viki'],
['Starz Estelar','Cabo',1.1,41000,74,['Drama','Ação','Policial'],'starz'],
['TNT Séries','Cabo',1.15,39000,70,['Drama','Policial','Suspense'],'tnt'],
['AXN Flux','Cabo',1.02,37000,69,['Ação','Policial','Suspense'],'axn'],
['Canal Discovery','Cabo',1.16,33000,75,['Documentário','Reality','Ação'],'disc'],
['NatGeo Mundo','Cabo',1.12,40000,85,['Documentário','Ficção científica','Drama'],'nat'],
['Cartum Clube','Cabo',1.18,37000,74,['Animação','Comédia','Fantasia'],'cart'],
['Gloob Kids','Cabo',1.02,31000,66,['Animação','Fantasia','Comédia'],'gloob'],
['Comedy Clube','Cabo',1,32000,70,['Comédia','Reality','Animação'],'cc'],
['Canal Syfy','Cabo',1.03,39000,74,['Ficção científica','Terror','Fantasia'],'sy'],
['AMC Prisma','Cabo',1.18,51000,83,['Drama','Terror','Policial'],'amc'],
['Canal A&E','Cabo',.96,30000,64,['Policial','Documentário','Reality'],'ae'],
['Globão TV','Aberta',2.1,70000,84,['Drama','Romance','Comédia'],'glob'],
['SBTela','Aberta',1.75,44000,70,['Comédia','Romance','Reality'],'sbt'],
['Recorda TV','Aberta',1.65,46000,73,['Drama','Ação','Documentário'],'rec'],
['Bandô','Aberta',1.25,34000,62,['Reality','Documentário','Comédia'],'band'],
['Cultura Viva','Aberta',.85,24000,66,['Documentário','Animação','Drama'],'cult'],
['TV Brasilis','Aberta',.78,22000,61,['Documentário','Drama','Animação'],'br'],
['Rede Novo Tempo','Aberta',.7,20000,56,['Drama','Documentário','Romance'],'nt'],
['Rede Viva','Cabo',.88,29000,63,['Drama','Romance','Comédia'],'viva'],
['Tela Local','Aberta',.48,14000,38,['Drama','Comédia','Documentário'],'local'],
['Festival Play','Streaming',.65,21000,52,['Drama','Documentário','Terror'],'fest'],
['Cine Bairro','Aberta',.55,17000,43,['Comédia','Romance','Ação'],'bairro']
];
const WORLD_TITLES=['A Alma de Vidro','Quinta Avenida Lunar','Os Herdeiros da Chuva','Sinal Perdido','Café às Três','O Último Faroleiro','Cidade de Papel','Do Outro Lado da Porta','Operação Jabuticaba','O Clube dos Improváveis','Sob o Céu de Cobre','Pé na Estrada','Uma Vida por Cena','Mar de Memórias','A Frequência Azul','Distrito 27','As Vozes do Mangue','Casamento em Marte','A Casa Sem Relógio','Quando o Sol Dorme','Plano B de Brigadeiro','Manual de Sobrevivência','Horizonte de Neon','Os Guardiões da Feira','A Grande Virada','O Rio Invisível','Amores em Fita','O Segredo do Pátio','Folhas ao Vento','Antes da Próxima Aurora','Os Retratos do Amanhã','Coração de Algoritmo','A Biblioteca das Nuvens','Vizinhos do Futuro','Cozinha em Chamas','O Verão das Cartas','Recomeço na Madrugada','Tinta Vermelha','O Gigante da Janela','A Última Palavra'];
const WORLD_STUDIOS=['Estúdio Ipê','Maré Alta Filmes','Papel & Luz','Quasar Cinema','Pipoca Lunar','Oficina do Plano','Casa Girassol','Lente Norte'];

/* Empire TV beta — state, recruitment, measurable objectives and narrative analysis. */
const DAY_MS=86400000;
const BETA_VERSION='1.0.0.1 BETA';
const UPGRADE_NAMES={roteiro:'Sala de roteiros',filmagem:'Estúdios de filmagem',edicao:'Pós-produção',marketing:'Centro de marketing',elenco:'Capacidade da equipe',catalogo:'Produções simultâneas'};
const UPGRADE_HELP={roteiro:'Mais suporte à escrita e +2 pontos de argumento por nível.',filmagem:'Melhora os recursos de gravação em +3 pontos por nível.',edicao:'Melhora montagem e acabamento em +3 pontos por nível.',marketing:'Aumenta o alcance da divulgação em 4% por nível.',elenco:'Libera 4 vagas de contratação por nível.',catalogo:'Libera 2 obras simultâneas por nível.'};
talents.forEach(t=>{t.legacyOnly=true;t.fame=clamp(t.skill-10,20,95);t.specialties=[t.genre];});
TALENT_REFERENCES.forEach((a,i)=>talents.push({id:'beta'+i,role:a[0],name:a[1],reference:a[2],specialties:a[3],genre:a[3][0],career:a[4],skill:a[5],fame:a[6],weight:a[7],source:a[8],salary:Math.round((700+a[5]*30+a[6]*40+(a[6]>=94?3500:0))*(a[0]==='Atuação'?1.3:a[0]==='Marketing'?.78:1)/100)*100}));
for(let r=0;r<BETA_ROLES.length;r++)for(let i=0;i<44;i++)talents.push({id:'trainee'+r+'_'+i,role:BETA_ROLES[r],name:['Luz','Cena','Lente','Take','Tela','Voz'][r]+' Nova '+(i+1),specialties:[genres[(i+r)%genres.length]],genre:genres[(i+r)%genres.length],skill:48+i%14,fame:12+i%12,salary:1300+(i%8)*150,weight:30,trainee:true,career:'Profissional em início de carreira'});
BETA_NETWORKS.forEach(n=>networks.push({name:n[0],type:n[1],reach:n[2],fee:n[3],threshold:n[4],focus:n[5],id:n[6]}));
networks.slice(0,4).forEach((n,i)=>n.threshold=[60,70,73,56][i]);
let subpage='',menuOpen=false,agencyFilter='all',networkFilter='all',socialNetwork='tuiter';
let marketCache=null;
function talentBy(tid){return talents.find(t=>t.id===tid);}
function salaryOf(t){return s.contracts?.[t.id]?.salary??t.salary;}
function jobFor(tid){return s.assignments?.[tid]||talentBy(tid)?.role;}
function rosterCapacity(){return Math.max(s.hired.length,12+(s.upgrades.elenco||0)*4);}
function standardRosterCapacity(){return 12+(s.upgrades.elenco||0)*4;}
capacity=function(){return Math.min(40,2+Math.floor(s.level/2)*2+(s.upgrades.catalogo||0)*2);};
hired=function(role){return s.hired.map(talentBy).filter(t=>t&&(!role||jobFor(t.id)===role));};
hiredCost=function(){return hired().reduce((sum,t)=>sum+salaryOf(t),0);};
function technique(t,genre,role=t.role){return Math.round(clamp((t.skill+(t.specialties||[t.genre]).includes(genre)*12)*(role===t.role?1:.6),0,100));}
avgSkill=function(role,genre){const people=hired(role);return people.length?Math.max(...people.map(t=>technique(t,genre,role))):38;};
function crewMember(sh,role){const selected=talentBy(sh.team?.[role]);if(selected&&s.hired.includes(selected.id)&&jobFor(selected.id)===role)return selected;return hired(role).sort((a,b)=>technique(b,sh.genre,role)-technique(a,sh.genre,role))[0]||null;}
function crewSnapshot(sh,actorId){return BETA_ROLES.map(role=>{const selected=role==='Atuação'&&hired(role).some(t=>t.id===actorId)?talentBy(actorId):crewMember(sh,role);return{role,id:selected?.id||null,name:selected?.name||'Equipe de apoio',specialties:selected?.specialties||[],technique:selected?technique(selected,sh.genre,role):38,fame:selected?.fame||0,nativeRole:selected?.role||role};});}
function fameMultiplier(credits){const weights={Atuação:.0035,Direção:.0009,Showrunner:.0006,Roteirista:.0004,Marketing:.0004,Dublagem:.0004};return 1+credits.reduce((v,t)=>v+t.fame*weights[t.role],0);}
function addNews(title,text,topic='Mercado',showId=null){s.news.unshift({id:'news'+(++s.newsSeq),week:s.week,title,text,topic,showId});s.news=s.news.slice(0,350);}
function buildWorld(state){return networks.map((n,i)=>{const rng=seeded(state.campaignId+'world'+n.id);return{id:'world'+i,name:WORLD_TITLES[i],genre:n.focus[i%n.focus.length],kind:i%3===0?'film':'series',networkId:n.id,studio:WORLD_STUDIOS[i%WORLD_STUDIOS.length],season:1,episode:1+Math.floor(rng()*4),quality:58+Math.floor(rng()*34),viewers:Math.round((230000+rng()*780000)*n.reach),status:'active',debutWeek:1,updatedWeek:1,history:[]};});}
function migrateBeta(state){
 if(!state)return state;
 migrateV3(state);
 const first=!(state.schema>=4);
 state.assignments=state.assignments||{};state.contracts=state.contracts||{};
 Object.keys(UPGRADE_NAMES).forEach(k=>state.upgrades[k]=Number.isFinite(state.upgrades[k])?state.upgrades[k]:0);
 if(first){
  state.hired=state.hired.map(tid=>{const prior=talentBy(tid),replacement=prior?.legacyOnly?talents.find(t=>!t.legacyOnly&&!t.trainee&&norm(t.name)===norm(prior.name)):null;if(!replacement)return tid;state.contracts[replacement.id]=state.contracts[tid]||{salary:prior.salary,week:state.week};state.assignments[replacement.id]=state.assignments[tid]||prior.role;return replacement.id;});
  state.hired=[...new Set(state.hired)];
  state.finance={opening:state.cash,income:0,expenses:0,byCategory:{},sinceWeek:state.week,partial:state.week>1||state.ledger.length>0,transactions:0};
  state.ledgerPrior=state.ledger.slice();state.ledger=[];
  state.counts.assigned=state.counts.assigned||0;state.counts.sequels=state.counts.sequels||0;state.counts.rescues=state.counts.rescues||0;state.counts.renewals=state.counts.renewals||0;state.counts.networkUpgrades=state.counts.networkUpgrades||0;
  state.news=[];state.newsSeq=0;state.social={posts:[],used:{},serial:0};state.awards={lastCycle:Math.floor((state.week-1)/12),history:[],wins:0,nominations:0};state.daily={active:false,lastNow:Date.now(),cycle:0,tasks:[],expiresAt:0};state.assignedPeople=[];state.pendingTutorialRewards=[];
  state.world=buildWorld(state);
  state.feed.unshift({week:state.week,text:'Empire TV beta: equipe, redes, objetivos diários e emissoras disponíveis. O patrimônio e os resultados anteriores foram preservados.'});
  state.schema=4;
 }
 state.shows.forEach(sh=>{sh.team=sh.team||{};sh.pitchHistory=sh.pitchHistory||[];sh.rights=sh.rights||{rejected:[],previous:[]};sh.intent=sh.intent||'';sh.franchiseRoot=sh.franchiseRoot||sh.name;sh.sequelNumber=sh.sequelNumber||1;});
 state.hired.forEach(tid=>{if(!state.assignments[tid])state.assignments[tid]=talentBy(tid)?.role||'Atuação';});
 state.networks.forEach(n=>{n.levels=n.levels||{signal:0,technology:0,slots:0};n.focus=n.focus||genres.slice(0,3);n.slogan=n.slogan||'Sua tela, suas histórias.';n.adLoad=n.adLoad??1;n.subscriptionPrice=n.subscriptionPrice||24;n.promoBudget=n.promoBudget||0;n.subscribers=n.subscribers||0;n.metrics=n.metrics||{views:0,revenue:0,expenses:0,profit:0};n.licensed=n.licensed||[];n.history=n.history||[];n.quality=n.quality||50;n.lastWeekly=n.lastWeekly||null;});
 state.news=state.news||[];state.world=state.world||buildWorld(state);state.social=state.social||{posts:[],used:{},serial:0};
 return state;
}
const betaFreshBase=fresh;
fresh=function(name,difficulty){return migrateBeta(betaFreshBase(name,difficulty));};
function expenseCategory(label){const l=norm(label);if(/contratacao/.test(l))return'Contratações';if(/producao/.test(l))return'Produção';if(/desenvolvimento/.test(l))return'Desenvolvimento';if(/reforma|melhoria/.test(l))return'Melhorias';if(/abertura/.test(l))return'Emissoras';if(/folha/.test(l))return'Salários';if(/manutencao/.test(l))return'Manutenção';if(/divulgacao/.test(l))return'Divulgação';if(/licenca/.test(l))return'Licenciamento';if(/rejeitada/.test(l))return'Negociação';return'Outros custos';}
changeCash=function(amount,label,category){
 amount=Math.round(Number(amount)||0);if(!amount)return;
 migrateBeta(s);category=category||(amount<0?expenseCategory(label):/financiamento/i.test(label)?'Financiamento':/objetivo/i.test(label)?'Objetivos':/premio/i.test(label)?'Prêmios':'Exibições');
 s.cash+=amount;s.finance.transactions++;if(amount>0)s.finance.income+=amount;else s.finance.expenses-=amount;
 s.finance.byCategory[category]=(s.finance.byCategory[category]||0)+amount;
 s.ledger.unshift({id:s.finance.transactions,week:s.week,amount,label,category});s.ledger=s.ledger.slice(0,1000);
};
function inclusionProbabilities(pool){
 const result=new Map;let remaining=4,rest=pool.slice();
 while(rest.length){const sum=rest.reduce((v,t)=>v+t.weight,0),certain=rest.filter(t=>remaining*t.weight/sum>=1);
  if(!certain.length){rest.forEach(t=>result.set(t.id,remaining*t.weight/sum));break;}
  certain.forEach(t=>result.set(t.id,1));remaining-=certain.length;rest=rest.filter(t=>!certain.includes(t));
 }
 return result;
}
function rolePool(role){
 let pool=talents.filter(t=>t.role===role&&!t.legacyOnly&&!t.trainee&&!s.hired.includes(t.id));
 if(pool.length<4)pool=pool.concat(talents.filter(t=>t.trainee&&t.role===role&&!s.hired.includes(t.id)).slice(0,4-pool.length));
 return pool;
}
function marketCycle(epoch=marketEpoch()){
 const cacheKey=s.campaignId+'|'+epoch+'|'+s.hired.slice().sort().join(',');
 if(marketCache?.key===cacheKey)return marketCache;
 const entries=[],odds={};
 for(const role of BETA_ROLES){
  const pool=rolePool(role),p=inclusionProbabilities(pool),rng=seeded(s.campaignId+'agency'+role+epoch),ordered=pool.map(t=>({t,sort:rng()})).sort((a,b)=>a.sort-b.sort).map(x=>x.t);
  const start=rng();let cumulative=0,pick=0;
  for(const t of ordered){const end=cumulative+p.get(t.id);odds[t.id]=p.get(t.id);
   if(pick<4&&start+pick<end-1e-10){entries.push(t);pick++;}
   cumulative=end;
  }
  if(pick!==4)throw Error('A agência não conseguiu preencher quatro vagas de '+role+'.');
 }
 marketCache={key:cacheKey,entries,odds};return marketCache;
}
function marketChance(t,epoch=marketEpoch()){return marketCycle(epoch).odds[t.id]||0;}
availableTalent=function(t,epoch=marketEpoch()){return marketCycle(epoch).entries.some(x=>x.id===t.id);};
hireTalent=function(tid){
 const t=talentBy(tid);if(!t||s.hired.includes(tid))return;
 if(s.hired.length>=standardRosterCapacity())return notice('Equipe cheia. A melhoria Capacidade da equipe libera mais 4 vagas.',true);
 if(!availableTalent(t))return notice('Este profissional não está disponível nesta rodada de 5 minutos.',true);
 if(s.cash<t.salary*2)return notice('A contratação custa '+money(t.salary*2)+' e gera '+money(t.salary)+' de salário por semana.',true);
 changeCash(-t.salary*2,'Contratação: '+t.name);s.hired.push(t.id);s.assignments[t.id]=t.role;s.contracts[t.id]={salary:t.salary,week:s.week};s.counts.hire++;
 addXP(12);log(t.name+' assume '+t.role+'. Técnica '+t.skill+', fama '+t.fame+'.');update();notice('Contratação concluída; cargo inicial '+t.role+'.');
};
function assignJob(fd){const tid=fd.get('talentId'),role=fd.get('role');if(!s.hired.includes(tid)||!BETA_ROLES.includes(role))return;s.assignments[tid]=role;s.assignedPeople=s.assignedPeople||[];if(!s.assignedPeople.includes(tid)){s.assignedPeople.push(tid);s.counts.assigned++;}s.shows.forEach(sh=>Object.keys(sh.team).forEach(r=>{if(sh.team[r]===tid&&r!==role)delete sh.team[r];}));log(talentBy(tid).name+' agora trabalha em '+role+'.'+(role!==talentBy(tid).role?' Fora da formação: técnica ×0,60.':''));update();notice('Cargo atualizado. Produções já gravadas mantêm os créditos.');}
function assignCrew(fd){const sh=showBy(fd.get('showId'));if(!sh)return;for(const role of BETA_ROLES){const tid=fd.get(role);sh.team[role]=tid&&hired(role).some(t=>t.id===tid)?tid:null;}update();notice('Equipe da obra salva. A escolha será registrada na próxima gravação.');}
function upgradeCost(key){return Math.round((key==='elenco'?30000:key==='catalogo'?55000:45000)*Math.pow(1.65,s.upgrades[key]||0));}
upgrade=function(key){if(!Object.hasOwn(UPGRADE_NAMES,key))return;const level=s.upgrades[key];if(level>=5)return notice('Melhoria no nível máximo.',true);const cost=upgradeCost(key);if(s.cash<cost)return notice('A melhoria exige '+money(cost)+'.',true);changeCash(-cost,'Melhoria: '+UPGRADE_NAMES[key]);s.upgrades[key]++;addXP(23);log(UPGRADE_NAMES[key]+': nível '+s.upgrades[key]+'. '+UPGRADE_HELP[key]);update();notice('Melhoria aplicada. '+UPGRADE_HELP[key]);};

function uniqueWords(text){const ignore=new Set(['a','o','as','os','de','do','da','dos','das','e','em','um','uma','com','que','para','por','se','na','no']);return words(text).filter(w=>w.length>2&&!ignore.has(w));}
function textSignal(text,target){const w=words(text),u=new Set(uniqueWords(text));return clamp(u.size/target*100,0,100)*clamp(u.size/Math.max(1,uniqueWords(text).length)*1.7,.22,1);}
plotFactors=function(sh,script=''){
 const st=sh.story||{},combined=[sh.concept,st.motivation,st.conflict,st.payoff,script].join(' '),w=uniqueWords(combined),unique=new Set(w).size;
 const repeatRatio=unique/Math.max(1,w.length);
 const signals=/(porque|por isso|portanto|consequencia|para salvar|se nao|perde|arrisc|decid|escolh|para que|custo|sacrific|ao descobrir)/.test(norm(combined));
 const conceptWords=new Set(uniqueWords(sh.concept)),overlap=Math.max(0,...s.shows.filter(other=>other.id!==sh.id&&other.franchiseRoot!==sh.franchiseRoot).map(other=>{const ow=new Set(uniqueWords(other.concept));return [...conceptWords].filter(v=>ow.has(v)).length/Math.max(1,Math.min(conceptWords.size,ow.size));}));
 const original=clamp(45+Math.min(48,unique*.5)+(sh.intent?10:0)-Math.max(0,overlap-.65)*100-(repeatRatio<.25?35:0),0,100);
 return [
 factor('premise','Premissa',textSignal(sh.concept,18),'Premissa registrada: “'+shortText(sh.concept,145)+'”. '+conceptWords.size+' termos distintos.','Defina quem age, o objetivo e o obstáculo; evite repetir palavras para preencher espaço.',1.4),
 factor('motivation','Motivação',textSignal(st.motivation,10),st.motivation?'Motivação: “'+shortText(st.motivation,130)+'”.':'O protagonista ainda não tem motivação escrita.','Explique o motivo e o que o protagonista pode perder.',1.2),
 factor('conflict','Conflito',textSignal(st.conflict,11),st.conflict?'Conflito: “'+shortText(st.conflict,130)+'”.':'Não foi escrito um obstáculo concreto.','Dê ao desejo uma oposição que force uma decisão.',1.3),
 factor('payoff','Consequência',textSignal(st.payoff,11),st.payoff?'Consequência planejada: “'+shortText(st.payoff,130)+'”.':'A resolução ainda não foi escrita.','Mostre a decisão final e o preço ou a mudança que ela produz.',1.2),
 factor('causality','Causa e decisão',signals?90:45,signals?'O argumento contém sinais explícitos de decisão, risco ou consequência.':'O argumento ainda não liga explicitamente ação e consequência.','Ligue objetivo, obstáculo e resultado em uma cadeia de causa.',.8),
 factor('development','Desenvolvimento',textSignal(script||combined,38),'Argumento da produção: '+words(script||combined).length+' palavras; '+new Set(uniqueWords(script||combined)).size+' termos distintos.','Conte o que acontece: abertura, virada, escolha e consequência.',1),
 factor('originality','Identidade e criatividade',original,'Identidade textual '+Math.round(original)+'/100. '+(sh.intent?'Intenção: “'+shortText(sh.intent,120)+'”. ':'')+(overlap>.65?'Há semelhança textual com outra premissa da sua produtora.':'A proposta tem vocabulário próprio dentro do catálogo da produtora.'),'Explore um contraste ou ponto de vista próprio e explique por que ele funciona; uma sequência pode preservar a identidade.',1.7)
 ];
};
buildAnalysis=function(sh,ep){
 const snapshot={...sh,concept:ep.storySnapshot?.concept??sh.concept,story:ep.storySnapshot?.story??sh.story,intent:ep.intent||sh.intent},fs=plotFactors(snapshot,ep.script),dir=ep.direction||elements.map(()=>1);
 const narrative=weighted(fs),intentSupport=textSignal(ep.intent||sh.intent,9),storyStrong=narrative>=72,credits=ep.credits||[];
 for(let i=0;i<elements.length;i++){
  let score=storyStrong?89:72,advice=DIR_HELP[i],problem='';
  if(i===5&&dir[5]===2&&dir[11]===2&&intentSupport<60){score-=13;problem='Trilha e diálogos ocupam o primeiro plano ao mesmo tempo.';}
  if(i===9&&dir[9]===2&&narrative<55){score-=18;problem='Estrutura fragmentada com argumento pouco desenvolvido.';}
  if(i===1&&dir[1]===2&&dir[0]===2){score=intentSupport>=65?94:72;problem=intentSupport>=65?'O contraste entre humor e intensidade foi assumido na intenção.':'O contraste entre humor e intensidade precisa de intenção clara.';}
  fs.push(factor('dir'+i,elements[i],score,elements[i]+': '+DIR_OPTIONS[i][dir[i]]+'. '+(problem||'O efeito é avaliado junto da narrativa; o gênero não impõe uma única escolha correta.'),advice,.42));
 }
 const complexity=1+dir[7]*.13+dir[8]*.16+dir[6]*.1,per45=(ep.baseBudget||ep.budget)/(sh.duration/45);
 fs.push(factor('budget','Recursos de gravação',clamp(50+Math.log2(Math.max(.25,per45/15000))*17-(complexity-1)*20+(s.upgrades.filmagem||0)*3,10,100),money(ep.baseBudget)+' de filmagem para '+sh.duration+' min; complexidade '+complexity.toFixed(2)+'×. Divulgação '+money(ep.promo)+'; gasto total '+money(ep.budget)+'.','Com pouco orçamento, concentre locações e cenários. Uma boa ideia mantém peso mesmo em produção econômica.',1));
 fs.push(factor('crew','Equipe e execução',ep.crew,'Técnica da equipe registrada na gravação: '+Math.round(ep.crew)+'/100. '+credits.filter(c=>c.id).map(c=>c.role+': '+c.name+' ('+c.technique+')').join('; ')+'.','Atribua cada profissional à formação e ao gênero adequados. Cargo diferente usa 60% da técnica.',1));
 const voice=credits.find(c=>c.role==='Dublagem');
 fs.push(factor('voice','Voz e acessibilidade',voice?.technique||38,'Responsável pelas vozes: '+(voice?.name||'Equipe de apoio')+'. Técnica '+(voice?.technique||38)+'/100.','Um especialista de dublagem melhora vozes e localização, sobretudo em animação e streaming.',.5));
 const dense=dir[10]===2&&(dir[3]===2||sh.duration<=30);
 fs.push(factor('density','Tempo de compreensão',dense?(storyStrong&&intentSupport>=65?86:55):88,'Densidade '+DIR_OPTIONS[10][dir[10]]+', ritmo '+DIR_OPTIONS[3][dir[3]]+', duração '+sh.duration+' min.','Se escolher densidade e velocidade, explique na intenção como vai orientar o público.',.7));
 const prev=sh.episodes.filter(e=>e.status==='aired').at(-1);
 if(prev&&!isFilm(sh)){const drift=dir.reduce((sum,v,i)=>sum+Math.abs(v-(prev.direction?.[i]??v)),0);fs.push(factor('continuity','Continuidade',clamp(95-drift*(intentSupport>=65?.35:1.5),50,100),drift+' pontos de mudança de estilo; '+(intentSupport>=65?'a intenção explica a transição.':'intenção ainda pouco desenvolvida.'),'Uma mudança pode ser criativa: estabeleça a transição e preserve a motivação.',.55));}
 fs.push(factor('intention','Intenção criativa',intentSupport,ep.intent?'Intenção registrada: “'+shortText(ep.intent,150)+'”.':'A direção não registrou a intenção por trás das escolhas.','Explique como o tom, a estrutura e a linguagem servem à ideia; isso sustenta escolhas fora do padrão.',.8));
 return fs;
};
function creativeQuality(sh,ep){
 const fs=ep.analysis,narrative=weighted(fs.filter(f=>['premise','motivation','conflict','payoff','causality','development','originality'].includes(f.key))),technical=weighted(fs.filter(f=>['budget','crew','voice'].includes(f.key))),direction=weighted(fs.filter(f=>f.key.startsWith('dir')||['density','continuity','intention'].includes(f.key)));
 let quality=narrative*.65+technical*.18+direction*.17+(s.upgrades.roteiro||0)*2+(s.upgrades.edicao||0)*1.5+ep.qualityBoost;
 return Math.round(clamp(quality,5,100));
}
const betaCreateV3=createShow;
createShow=function(fd){const count=s.shows.length;betaCreateV3(fd);if(s.shows.length===count)return;const sh=s.shows.at(-1);sh.intent=String(fd.get('intent')||'').trim().slice(0,1200);sh.team={};sh.pitchHistory=[];sh.rights={rejected:[],previous:[]};sh.franchiseRoot=sh.name;sh.sequelNumber=1;sh.appeal=Math.round(25+weighted(plotFactors(sh))*.65);addNews('Nova obra em desenvolvimento',s.name+' anunciou '+sh.name+', '+(isFilm(sh)?'filme':'série')+' de '+sh.genre+'.','Produções',sh.id);update();};
const betaEditV3=editStory;
editStory=function(fd){const sh=showBy(fd.get('showId'));if(!sh||sh.episodes.some(e=>e.status==='produced'))return betaEditV3(fd);sh.intent=String(fd.get('intent')||'').trim().slice(0,1200);betaEditV3(fd);};
produce=function(fd){
 const sh=showBy(fd.get('showId'));if(!sh||sh.status!=='active')return notice('Apresente a obra a uma emissora antes de produzir.',true);
 if(seasonAired(sh)+seasonProduced(sh)>=sh.episodesPerSeason||sh.episodes.some(e=>e.status==='produced'))return notice('Existe material pronto ou a temporada já foi concluída.',true);
 if(s.networks.find(n=>n.id===sh.networkId)?.paused)return notice('Retome sua emissora antes de produzir para ela.',true);
 const budget=clamp(Number(fd.get('budget'))||30000,15000,170000),promo=clamp(Number(fd.get('promo'))||0,0,20000),requested=String(fd.get('boost')||''),boost=POWERUPS.includes(requested)&&s.boosts[requested]>0&&s.difficulty!=='director'?requested:'',total=costPreview(sh,budget,promo,boost);
 if(s.cash<total)return notice('Faltam '+money(total-s.cash)+' para gravar esta produção.',true);
 const credits=crewSnapshot(sh,String(fd.get('actor')||'')),actor=credits.find(c=>c.role==='Atuação'),crew=credits.filter(c=>c.role!=='Marketing').reduce((sum,c)=>sum+c.technique,0)/5;
 const ep={id:id(),number:sh.episodes.filter(e=>e.season===sh.season).length+1,season:sh.season,title:String(fd.get('epTitle')||'').trim().slice(0,75)||(isFilm(sh)?sh.name:'Episódio '+(seasonAired(sh)+1)),status:'produced',producedWeek:s.week,airWeek:s.week+1,budget:total,baseBudget:budget*(sh.duration/45),promo,direction:elements.map((_,i)=>clamp(Number(fd.get('dir'+i))||0,0,2)),crew,credits,actorId:actor.id,actorName:actor.id?actor.name:'',actorGenre:actor.specialties[0]||'',dept:s.upgrades.roteiro+s.upgrades.filmagem+s.upgrades.edicao,script:String(fd.get('script')||'').trim().slice(0,3500),intent:String(fd.get('intent')||sh.intent||'').trim().slice(0,1200),storySnapshot:{concept:sh.concept,story:{...sh.story}},boostAudience:boost==='audiencia',qualityBoost:boost==='inspiracao'?15:0,critics:null,viewers:null,viewership:null,controversial:false};
 ep.analysis=buildAnalysis(sh,ep);ep.quality=creativeQuality(sh,ep);ep.fameMultiplier=fameMultiplier(credits);ep.marketingTechnique=credits.find(c=>c.role==='Marketing').technique;ep.fit=1;
 if(boost)s.boosts[boost]--;changeCash(-total,'Produção '+unitLabel(sh,ep)+': '+sh.name);sh.episodes.push(ep);s.counts.produce++;addXP(24);
 log(sh.name+' '+unitLabel(sh,ep)+' gravado: '+money(total)+', criatividade e execução '+ep.quality+'/100; fama da equipe +'+Math.round((ep.fameMultiplier-1)*100)+'% no alcance potencial.');update();notice('Gravação concluída. A estreia ocorre ao avançar a semana.');
};

/* Empire TV beta — tutorial, 144 daily challenges, rights and owned networks. */
const DAILY_FAMILIES=[
 ['create','Desenvolver obras',[1,2,3,4,6,8],'Desenvolva {n} obras.'],
 ['hire','Contratar profissionais',[1,2,3,4,6,8],'Contrate {n} profissionais.'],
 ['assigned','Organizar os cargos',[1,2,3,4,6,8],'Salve {n} atribuições de cargo.'],
 ['pitch','Negociar contratos',[1,2,3,4,5,6],'Feche {n} contratos de distribuição.'],
 ['produce','Gravar novas histórias',[1,2,3,4,6,8],'Grave {n} episódios ou filmes.'],
 ['air','Colocar obras no ar',[1,2,3,4,6,10],'Exiba {n} produções inéditas.'],
 ['views','Conquistar espectadores',[100000,300000,750000,1500000,4000000,10000000],'Some {n} visualizações inéditas.'],
 ['likes','Receber gostei',[20000,75000,200000,600000,1800000,4000000],'Receba {n} gostei nas estreias.'],
 ['favorites','Entrar nos favoritos',[3000,10000,25000,70000,180000,500000],'Receba {n} adições aos favoritos.'],
 ['goodReviews','Agradar o público',[1,2,3,4,6,8],'Exiba {n} produções com público ≥70.'],
 ['revenue','Faturar na tela',[15000,50000,100000,250000,600000,1500000],'Gere {n} de receita operacional.'],
 ['films','Fazer cinema',[1,2,3,4,5,6],'Estreie {n} filmes.'],
 ['series','Contar em capítulos',[1,2,3,4,6,8],'Estreie {n} episódios de série.'],
 ['sequels','Expandir universos',[1,2,3,4,5,6],'Desenvolva {n} continuações.'],
 ['renewals','Renovar temporadas',[1,2,3,4,5,6],'Renove {n} temporadas.'],
 ['rescues','Recuperar obras',[1,2,3,4,5,6],'Leve {n} obras canceladas a uma nova emissora.'],
 ['network','Criar emissoras',[1,1,1,2,2,3],'Abra {n} emissoras próprias.'],
 ['networkUpgrades','Melhorar a transmissão',[1,2,3,4,6,8],'Compre {n} melhorias de emissora.'],
 ['upgrades','Investir na produtora',[1,2,3,4,6,8],'Compre {n} melhorias da empresa.'],
 ['genres','Diversificar estreias',[1,2,3,4,5,6],'Estreie obras de {n} gêneros diferentes neste ciclo.'],
 ['awards','Ganhar prêmios',[1,1,2,2,3,4],'Ganhe {n} prêmios.'],
 ['subscribers','Converter assinantes',[100,250,750,2000,5000,12000],'Conquiste {n} novos assinantes nas suas plataformas.'],
 ['ownRevenue','Fortalecer a própria rede',[10000,25000,60000,140000,300000,700000],'Gere {n} de receita nas suas emissoras.'],
 ['creativeHits','Ideias que funcionam',[1,2,3,4,6,8],'Estreie {n} produções com narrativa ≥80.']
];
const TIER_NAMES=['Muito fácil','Fácil','Médio','Difícil','Muito difícil','Lendário'];
const DAILY_OBJECTIVES=DAILY_FAMILIES.flatMap((a,index)=>a[2].map((goal,tier)=>({id:'daily'+index+'_'+tier,metric:a[0],title:a[1]+' · '+TIER_NAMES[tier],desc:a[3].replace('{n}',a[0].toLowerCase().includes('revenue')||a[0]==='revenue'?money(goal):compact(goal)),goal,tier,xp:[35,60,95,140,200,280][tier],cash:[6000,14000,30000,55000,90000,160000][tier],boostCount:[0,1,1,2,2,3][tier],boost:POWERUPS[(index+tier)%3]})));
objectiveDefs.forEach((o,i)=>{o.cash=[4000,5000,7000,6000,8000,10000,12000,15000,20000,25000,14000][i];o.title=o.title.replace('programa','obra').replace('séries','obras').replace('Império','Empresa');});
function metricTotals(state=s){
 const aired=state.shows.flatMap(sh=>sh.episodes.filter(e=>e.status==='aired').map(ep=>({sh,ep})));
 return {create:state.counts.create,hire:state.counts.hire,assigned:state.counts.assigned||0,pitch:state.counts.pitch,produce:state.counts.produce,air:state.counts.air,views:aired.reduce((v,x)=>v+(x.ep.viewership||0),0),likes:aired.reduce((v,x)=>v+(x.ep.likes||0),0),favorites:aired.reduce((v,x)=>v+(x.ep.favorites||0),0),goodReviews:state.counts.reviews4,revenue:state.counts.revenue,films:aired.filter(x=>isFilm(x.sh)).length,series:aired.filter(x=>!isFilm(x.sh)).length,sequels:state.counts.sequels||0,renewals:state.counts.renewals||0,rescues:state.counts.rescues||0,network:state.counts.network,networkUpgrades:state.counts.networkUpgrades||0,upgrades:Object.values(state.upgrades).reduce((a,b)=>a+b,0),genres:new Set(aired.map(x=>x.sh.genre)).size,awards:state.awards?.wins||0,subscribers:state.counts.subscribers||0,ownRevenue:state.networks.reduce((v,n)=>v+(n.metrics?.revenue||0),0),creativeHits:aired.filter(x=>x.ep.analysis&&weighted(x.ep.analysis.filter(f=>['premise','motivation','conflict','payoff','causality','development','originality'].includes(f.key)))>=80).length};
}
function dailyEligible(o){
 if(o.metric==='network'&&s.networks.length>=ownNetworkLimit())return false;
 if(o.metric==='upgrades'&&Object.values(s.upgrades).every(v=>v>=5))return false;
 if(o.metric==='hire'&&s.hired.length>=standardRosterCapacity())return false;
 if(o.metric==='assigned'&&s.hired.length>=standardRosterCapacity()&&s.hired.every(tid=>s.assignedPeople.includes(tid)))return false;
 if(o.metric==='networkUpgrades'&&!s.networks.some(n=>Object.values(n.levels).some(v=>v<5)))return false;
 if(['subscribers','ownRevenue'].includes(o.metric)&&!s.networks.some(n=>!n.paused&&(o.metric!=='subscribers'||n.type==='Streaming')))return false;
 if(o.metric==='awards'&&s.shows.every(sh=>sh.episodes.length===0))return false;
 return true;
}
function rollDaily(now){
 const d=s.daily,rng=seeded(s.campaignId+'daily'+(d.cycle+1));d.cycle++;d.active=true;d.expiresAt=now+DAY_MS;d.startedAt=now;d.baseline=metricTotals();d.airedIds=s.shows.flatMap(sh=>sh.episodes.filter(e=>e.status==='aired').map(e=>e.id));d.tasks=[];
 const chosen=new Set;
 for(let tier=0;tier<6;tier++){let pool=DAILY_OBJECTIVES.filter(o=>o.tier===tier&&!chosen.has(o.metric)&&dailyEligible(o));if(!pool.length)pool=DAILY_OBJECTIVES.filter(o=>o.tier===tier&&!chosen.has(o.metric)&&['produce','air','views','likes','revenue','creativeHits'].includes(o.metric));const def=pool[Math.floor(rng()*pool.length)];chosen.add(def.metric);d.tasks.push({id:def.id,claimed:false});}
 d.lastNow=now;addNews('Nova rodada de objetivos', 'Seis desafios por 24 horas reais, de Muito fácil a Lendário. Cada recompensa pode ser resgatada uma vez.','Objetivos');
}
function ensureDaily(now=Date.now()){
 if(!s||!s.daily)return false;now=Math.max(now,s.daily.lastNow||0);s.daily.lastNow=now;
 if(!objectiveDefs.every(o=>s.claimed.includes(o.id)))return false;
 if(!s.daily.active||now>=s.daily.expiresAt){rollDaily(now);return true;}return false;
}
checkGoals=function(){if(!s)return;migrateBeta(s);if(s.grantTaken&&s.pendingTutorialRewards?.length){const queued=s.pendingTutorialRewards;s.pendingTutorialRewards=[];for(const reward of queued)changeCash(reward.cash,'Objetivo inicial: '+reward.title,'Objetivos');}for(const o of objectiveDefs){if(!s.claimed.includes(o.id)&&goalValue(o)>=o.goal){s.claimed.push(o.id);if(s.difficulty!=='director')s.boosts[o.boost]++;const deferred=s.difficulty==='director'&&!s.grantTaken;if(deferred)s.pendingTutorialRewards.push({id:o.id,title:o.title,cash:o.cash});else changeCash(o.cash,'Objetivo inicial: '+o.title,'Objetivos');addXP(o.xp);log('Objetivo concluído: '+o.title+' · '+money(o.cash)+(deferred?' (libera depois do financiamento)':'')+' + '+o.xp+' XP'+(s.difficulty==='director'?'':', 1 powerup')+'.');}}ensureDaily();};
function dailyValue(o){
 if(o.metric==='genres'){const ids=new Set(s.daily.airedIds);return new Set(s.shows.filter(sh=>sh.episodes.some(ep=>ep.status==='aired'&&!ids.has(ep.id))).map(sh=>sh.genre)).size;}
 return Math.max(0,(metricTotals()[o.metric]||0)-(s.daily.baseline[o.metric]||0));
}
function claimDaily(oid){
 if(ensureDaily())save();const item=s.daily.tasks.find(x=>x.id===oid),o=DAILY_OBJECTIVES.find(x=>x.id===oid);
 if(!s.daily.active||!item||item.claimed||!o||dailyValue(o)<o.goal)return notice('Este objetivo ainda não está pronto para resgatar.',true);
 item.claimed=true;changeCash(o.cash,'Objetivo diário: '+o.title,'Objetivos');if(s.difficulty!=='director')s.boosts[o.boost]+=o.boostCount;addXP(o.xp);update();notice(money(o.cash)+' recebidos'+(s.difficulty==='director'?'':'; '+o.boostCount+' powerup(s)')+'.');
}
function pitchPreview(sh,n){
 const own=s.networks.some(x=>x.id===n.id),narrative=weighted(plotFactors(sh)),aired=sh.episodes.filter(e=>e.status==='aired'),proof=aired.length?aired.reduce((v,e)=>v+e.quality,0)/aired.length:narrative;
 const quality=narrative*.75+proof*.25,genreFit=n.focus.includes(sh.genre),evidence=quality*.83+avgSkill('Showrunner',sh.genre)*.07+s.reputation*.1+(genreFit?8:-5),exceptional=quality>=88;
 const hurdle=own?0:n.threshold,reachHurdle=exceptional?0:Math.max(0,n.reach-1)*8;
 const chance=own?100:Math.round(clamp(72+(evidence-hurdle)*2.1-reachHurdle+policy().leniency+(exceptional?22:0),4,98));
 return {quality:Math.round(quality),narrative:Math.round(narrative),chance,genreFit,exceptional,hurdle,fee:own?0:Math.round(n.fee*(.78+quality/190)*(isFilm(sh)?3.8:1)),why:own?'Aprovação da sua rede; sujeita a vagas e grade.':(genreFit?'Gênero no foco. ':'Gênero fora do foco: −5 na evidência. ')+(exceptional?'Proposta excelente: dispensa a barreira de alcance e recebe +22 pontos na chance. ':'Alcance maior exige evidência e reputação. ')+'Exigência '+hurdle+'/100; argumento '+Math.round(narrative)+'/100.'};
}
pitch=function(showId,netId){
 const sh=showBy(showId),n=networkBy(netId);if(!sh||!n||!['development','cancelled'].includes(sh.status))return;
 if(s.difficulty==='director'&&!s.grantTaken)return notice('Aceite primeiro uma oferta de financiamento para a campanha.',true);
 if(activeCount()>=capacity())return notice('Capacidade de obras ativas atingida. Melhore Produções simultâneas.',true);
 const own=s.networks.find(x=>x.id===netId);if(own?.paused)return notice('Esta emissora está pausada.',true);
 if(own&&networkShows(own).length+own.licensed.filter(l=>l.until>=s.week).length>=networkSlotCapacity(own))return notice('Sua emissora está sem vagas de programação. Amplie a grade.',true);
 if(sh.status==='cancelled'&&netId===sh.networkId)return notice('Busque outra emissora para recuperar esta obra.',true);
 const p=pitchPreview(sh,n),signature=hashText([sh.concept,sh.story.motivation,sh.story.conflict,sh.story.payoff,sh.intent].join('|'));
 if(sh.pitchHistory.some(x=>x.networkId===netId&&x.week===s.week&&x.signature===signature&&x.result==='rejected'))return notice('A rede já avaliou este argumento nesta semana. Revise a proposta ou avance a semana.',true);
 const rng=seeded(s.campaignId+'pitch'+sh.id+n.id+s.week+signature),accepted=own||p.quality>=95||rng()*100<p.chance;
 sh.pitchHistory.unshift({networkId:n.id,network:n.name,week:s.week,signature,chance:p.chance,quality:p.quality,fee:p.fee,result:accepted?'accepted':'rejected',why:p.why});
 if(!accepted){const cost=Math.min(Math.max(0,s.cash),Math.round(1500*policy().cost));changeCash(-cost,'Apresentação rejeitada: '+sh.name);sh.rights.rejected.push({networkId:n.id,week:s.week});log(n.name+' recusou '+sh.name+'. '+p.why);update();return notice('Proposta recusada. A análise da negociação está no catálogo.',true);}
 const rescued=sh.status==='cancelled';if(sh.networkId)sh.rights.previous.push({networkId:sh.networkId,season:sh.season,fee:sh.fee,week:s.week});
 if(rescued&&!isFilm(sh)&&seasonCompleted(sh))sh.season++;
 sh.status='active';sh.networkId=n.id;sh.fee=p.fee;sh.hype=clamp(12+sh.fanBase/60000,12,35);sh.showrunner=crewMember(sh,'Showrunner')?.id||null;sh.finalSeason=false;
 if(own&&own.type!=='Streaming'&&slotConflicts(own,sh,sh.day,sh.slot)){const available=networkAvailableSlot(own,sh);if(available){sh.day=available.day;sh.slot=available.slot;}}
 s.counts.pitch++;if(rescued)s.counts.rescues++;addXP(40);log(n.name+' aprovou '+sh.name+'. '+(own?'Receita de publicidade e assinaturas da própria rede.':money(sh.fee)+(isFilm(sh)?' pela exibição do filme.':' por episódio inédito.')));
 addNews(rescued?'Obra ganha uma nova casa':'Contrato anunciado',sh.name+' será distribuída por '+n.name+'. Proposta '+p.quality+'/100.','Contratos',sh.id);update();notice('Distribuição confirmada. Produza a próxima história.');
};
renew=function(showId){
 const sh=showBy(showId);if(!sh||sh.status!=='between'||isFilm(sh))return;
 const eps=sh.episodes.filter(e=>e.season===sh.season&&e.status==='aired'),quality=eps.reduce((v,e)=>v+e.viewers,0)/Math.max(1,eps.length),own=s.networks.some(n=>n.id===sh.networkId),chance=clamp(30+(quality-40)*1.2+s.reputation*.2,12,98),rng=seeded(s.campaignId+'renew'+sh.id+sh.season);
 if(!own&&rng()*100>chance){sh.status='cancelled';sh.rights.rejected.push({networkId:sh.networkId,week:s.week});addNews('Renovação recusada',networkBy(sh.networkId).name+' não renovou '+sh.name+'. Público médio '+Math.round(quality)+'/100; chance de renovação '+Math.round(chance)+'%. A obra pode buscar outra emissora.','Contratos',sh.id);log(sh.name+' não foi renovada. Você mantém o catálogo e pode apresentar a próxima temporada a outra rede.');update();return notice('Sem renovação. A opção Apresentar a outra emissora foi liberada.',true);}
 sh.season++;sh.status='active';sh.episodesPerSeason=6;sh.fee=Math.round(sh.fee*1.06);sh.finalSeason=false;s.counts.renewals++;addXP(30);update();notice('Nova temporada aprovada; licença reajustada em 6%.');
};
endShow=function(showId){const sh=showBy(showId);if(!sh||!['active','between','cancelled'].includes(sh.status))return;if(sh.episodes.some(e=>e.status==='produced'))return notice('Exiba primeiro a produção que já foi gravada.',true);sh.status='ended';log(sh.name+' finalizada. Uma continuação pode ser desenvolvida com um novo contrato.');update();notice('Obra finalizada; continuação disponível no catálogo.');};
function makeSequel(showId){
 const parent=showBy(showId);if(!parent||parent.status!=='ended')return;
 const cost=s.difficulty==='director'?0:Math.round(12000*policy().cost);if(s.cash<cost)return notice('A continuação exige '+money(cost)+' de desenvolvimento.',true);
 const rootName=parent.franchiseRoot||parent.name,number=Math.max(...s.shows.filter(sh=>sh.franchiseRoot===rootName).map(sh=>sh.sequelNumber||1),1)+1;
 let name=rootName+' '+number;if(s.shows.some(sh=>norm(sh.name)===norm(name)))return notice('Já existe uma obra com esse título.',true);
 const sequel={...JSON.parse(JSON.stringify(parent)),id:id(),name,season:1,sequelNumber:number,franchiseRoot:rootName,parentId:parent.id,status:'development',networkId:null,fee:0,episodes:[],totalViewers:0,avgAudience:0,avgCritics:0,fanBase:Math.round(parent.fanBase*.3),hype:clamp(parent.fanBase/50000,0,20),createdWeek:s.week,funding:{offers:[],accepted:null},pitchHistory:[],rights:{previous:[],rejected:[]},finalSeason:false};
 changeCash(-cost,'Desenvolvimento: '+name);s.shows.push(sequel);s.counts.create++;s.counts.sequels++;addXP(18);addNews('Continuação em desenvolvimento',s.name+' anunciou '+name+'. '+compact(sequel.fanBase)+' fãs da franquia acompanham o novo projeto.','Produções',sequel.id);tab='shows';update();notice(name+' criada. Revise o argumento e negocie um novo contrato.');
}
function ownNetworkLimit(){return Math.min(6,1+Math.floor(s.level/3));}
function networkShows(n){return s.shows.filter(sh=>sh.networkId===n.id&&['active','between'].includes(sh.status));}
function networkSlotCapacity(n){return 4+(n.levels?.slots||0)*2;}
const WEEK_DAYS=['Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'];
function slotConflicts(n,sh,day,slot){if(n.type==='Streaming')return false;const start=WEEK_DAYS.indexOf(day)*1440+Number(slot.split(':')[0])*60,end=start+sh.duration;return networkShows(n).some(other=>{if(other.id===sh.id)return false;const otherStart=WEEK_DAYS.indexOf(other.day)*1440+Number(other.slot.split(':')[0])*60;return[-10080,0,10080].some(shift=>start<otherStart+shift+other.duration&&end>otherStart+shift);});}
function networkAvailableSlot(n,sh){for(const day of WEEK_DAYS)for(const slot of ['20:00','18:00','22:00','16:00','00:00'])if(!slotConflicts(n,sh,day,slot))return{day,slot};return null;}
function networkWeeklyCost(n){return n.paused?1800:Math.round((n.type==='Streaming'?11500:8500)+(n.levels.signal||0)*1400+(n.levels.technology||0)*1100+(n.levels.slots||0)*700);}
function studioOverhead(){if(s.difficulty==='director'&&!s.grantTaken&&s.hired.length===0&&!s.networks.length)return 0;return Math.round((1600+['roteiro','filmagem','edicao','marketing'].reduce((v,k)=>v+s.upgrades[k]*700,0))*policy().cost);}
overhead=function(){return studioOverhead()+s.networks.reduce((v,n)=>v+networkWeeklyCost(n)+(n.paused?0:n.promoBudget),0);};
openNetwork=function(type){
 if(s.networks.length>=ownNetworkLimit())return notice('Suba o nível da empresa para abrir outra emissora.',true);type=type==='Streaming'?'Streaming':'Aberta';
 const cost=type==='Streaming'?350000:220000;if(s.cash<cost)return notice('Abertura exige '+money(cost)+'.',true);
 changeCash(-cost,'Abertura de emissora');const n={id:'own'+id(),name:s.name+(type==='Streaming'?' Play':' TV')+(s.networks.length?' '+(s.networks.length+1):''),type,reach:type==='Streaming'?1.05:.92,fee:0,focus:genres.slice(0,3),paused:false,levels:{signal:0,technology:0,slots:0},slogan:'Sua tela, suas histórias.',adLoad:1,subscriptionPrice:24,promoBudget:0,subscribers:0,metrics:{views:0,revenue:0,expenses:cost,profit:-cost},licensed:[],history:[],quality:50,lastWeekly:null};
 s.networks.push(n);s.counts.network++;addXP(48);tab='networks';subpage='owned';addNews('Nova emissora no mercado',n.name+' iniciou as operações como '+type+'.','Emissoras');update();notice('Emissora aberta. Configure público, receita e grade na aba Minhas emissoras.');
};
function configureNetwork(fd){
 const n=s.networks.find(x=>x.id===fd.get('networkId'));if(!n)return;
 n.name=String(fd.get('name')||n.name).trim().slice(0,60)||n.name;n.slogan=String(fd.get('slogan')||'').trim().slice(0,160);
 n.focus=fd.getAll('focus').filter(g=>genres.includes(g)).slice(0,3);if(!n.focus.length)n.focus=[genres[0]];
 n.adLoad=clamp(Math.round(Number(fd.get('adLoad'))||0),0,3);n.subscriptionPrice=clamp(Number(fd.get('subscriptionPrice'))||24,12,60);n.promoBudget=clamp(Number(fd.get('promoBudget'))||0,0,20000);
 update();notice('Configuração salva. A política comercial vale para as próximas semanas.');
}
function upgradeNetwork(nid,key){
 const n=s.networks.find(x=>x.id===nid);if(!n||!['signal','technology','slots'].includes(key)||n.levels[key]>=5)return;
 const cost=Math.round((key==='slots'?35000:65000)*Math.pow(1.6,n.levels[key]));if(s.cash<cost)return notice('A melhoria exige '+money(cost)+'.',true);
 changeCash(-cost,'Melhoria de emissora: '+n.name);n.metrics.expenses+=cost;n.metrics.profit-=cost;n.levels[key]++;if(key==='signal')n.reach=Math.round((n.reach+.14)*100)/100;s.counts.networkUpgrades++;update();notice(key==='signal'?'Alcance aumentado em 14 pontos percentuais.':key==='technology'?'Qualidade da transmissão +3 pontos.':'Grade ampliada: +2 obras simultâneas.');
}
scheduleShow=function(fd){
 const sh=showBy(fd.get('showId')),n=s.networks.find(x=>x.id===sh?.networkId);if(!sh||!n)return;
 const day=String(fd.get('day')),slot=String(fd.get('slot'));if(!['Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'].includes(day)||!['16:00','18:00','20:00','22:00','00:00'].includes(slot))return;
 if(slotConflicts(n,sh,day,slot))return notice('A duração desta obra invade um horário reservado na emissora.',true);
 sh.day=day;sh.slot=slot;update();notice(n.type==='Streaming'?'Janela de lançamento atualizada. Streaming não aplica bônus de horário.':'Grade atualizada; o horário influencia o alcance.');
};
function licenseWorld(nid,wid){
 const n=s.networks.find(x=>x.id===nid),w=s.world.find(x=>x.id===wid);if(!n||!w||n.paused||n.licensed.some(x=>x.worldId===wid&&x.until>=s.week))return;
 if(n.licensed.filter(x=>x.until>=s.week).length>=networkSlotCapacity(n)-networkShows(n).length)return notice('Não há vaga na grade para outra licença.',true);
 const cost=Math.round(8000+w.quality*140+(w.kind==='film'?3000:0));if(s.cash<cost)return notice('Licença de seis semanas exige '+money(cost)+'.',true);
 changeCash(-cost,'Licença: '+w.name+' / '+n.name);n.metrics.expenses+=cost;n.metrics.profit-=cost;n.licensed.push({worldId:wid,name:w.name,genre:w.genre,quality:w.quality,views:w.viewers,cost,from:s.week+1,until:s.week+6});update();notice('Licença comprada: exibições semanais a partir da próxima semana, durante seis semanas.');
}

/* Empire TV beta — reception, contextual conversations, living market and awards. */
const SOCIAL_NAMES=['Lia','Caio','Bia','Rui','Joana','Leo','Dora','Mauro','Ana','Nando','Cida','Tom','Jade','Paulo','Rosa','Beto','Nina','Ivo','Luna','Otávio','Marta','Luca','Davi','Isa','Sueli','Renato','Zeca','Clara','Celso','Olga','Miguel','Tânia'];
const SOCIAL_VOICES=['Jovem','Adulto','Senhor'];
function pick(rng,values){return values[Math.floor(rng()*values.length)];}
function speech(voice,rng,positive){
 const positiveStarts={Jovem:['ok, isso me pegou:','terminei e fiquei pensando nisso:','vim pela curiosidade e ó:','gente, vou falar uma coisa:','eu tava sem expectativa, mas','isso aqui merece conversa:','marquei a galera porque','não esperava me envolver, só que'],Adulto:['Assisti depois do trabalho e','Vi com atenção e','O que ficou comigo foi que','Achei interessante como','Minha impressão é que','Depois de assistir, penso que','A escolha me chamou atenção:','Eu voltaria a assistir porque'],Senhor:['Vi com calma e gostei de perceber que','Aqui em casa, o que comentamos foi que','Depois de tantos programas, me chamou atenção que','Assisti até o fim porque','Na minha opinião, vale destacar que','Gostei de ver uma história em que','Acompanhando com atenção, reparei que','Fiquei contente por ver que']};
 const negativeStarts={Jovem:['curti a ideia, mas pera:','não vou fingir que não senti:','o potencial tá aí, só que','fui animado pra ver e fiquei com isso na cabeça:','alguém mais reparou nisso?','eu queria gostar mais, mas','tem coisa boa, porém','preciso comentar uma escolha:'],Adulto:['A proposta é boa, mas senti que','O investimento aparece, porém','Tenho uma ressalva concreta:','O resultado poderia melhorar se','O que me tirou da história foi que','Queria entender a decisão porque','Acho que o próximo trabalho precisa rever como','Minha crítica é ao efeito dessa escolha:'],Senhor:['A ideia me interessou, mas senti falta de atenção porque','Não desgostei de tudo, porém','Aqui em casa ficamos com uma dúvida:','Parece que essa escolha pede mais cuidado:','Gostaria de acompanhar melhor, mas','Se posso dar uma opinião, eu reveria como','Para mim, faltou explicar uma parte:','Vi potencial, embora']};
 return pick(rng,(positive?positiveStarts:negativeStarts)[voice]);
}
commentThread=function(sh,ep,fs,rng){
 const chosen=fs.slice().sort((a,b)=>a.score-b.score).slice(0,s.difficulty==='director'?fs.length:policy().detail),comments=[],context=sh.name+' · '+unitLabel(sh,ep)+' “'+ep.title+'”';
 chosen.forEach((f,i)=>{
  const voice=SOCIAL_VOICES[i%3],user=pick(rng,SOCIAL_NAMES)+'_'+ep.id+'_'+i,positive=f.score>=70;
  const text=context+': '+speech(voice,rng,positive)+' '+f.evidence+' '+(positive?'O efeito dessa escolha me convenceu.':f.advice);
  const parent={id:'ep'+ep.id+'c'+comments.length,user,role:i%2?'Fã':'Crítico',voice,text,likes:Math.floor(rng()*Math.max(5,ep.viewership*.00003)),factor:f.key,parent:null};comments.push(parent);
  if(s.difficulty==='director'){
   const responder=pick(rng,SOCIAL_NAMES)+'_'+ep.id+'_r'+i,other=fs[(i+3)%fs.length];
   comments.push({id:'ep'+ep.id+'c'+comments.length,user:responder,role:'Fã',voice:SOCIAL_VOICES[(i+1)%3],text:'@'+parent.user+', eu dei outro peso a '+f.label.toLowerCase()+'. '+(ep.actorName?'A presença de '+ep.actorName+' me fez prestar mais atenção. ':'')+'Mas concordo que precisamos olhar '+other.label.toLowerCase()+': '+other.evidence,likes:Math.floor(rng()*100),factor:f.key,parent:parent.id});
   comments.push({id:'ep'+ep.id+'c'+comments.length,user:parent.user,role:'Crítico',voice,text:'@'+responder+', faz sentido ter outra preferência. Minha sugestão para a direção é concreta: '+f.advice+' Depois compare '+f.label.toLowerCase()+' e o número de favoritos na próxima produção.',likes:Math.floor(rng()*50),factor:f.key,parent:parent.id});
  }
 });
 if(ep.actorName)comments.push({id:'ep'+ep.id+'cast',user:'FãDeElenco_'+ep.id,role:'Fã',voice:'Jovem',text:'caramba, '+ep.actorName+' participou de '+sh.name+'! Vim pelo elenco, e a história recebeu '+ep.viewers+'/100 do público. '+(ep.viewers>=75?'Vou recomendar esse trabalho.':'Quero que a próxima obra aproveite ainda melhor essa equipe.'),likes:Math.floor(rng()*200),parent:null,factor:'cast'});
 if(s.difficulty==='easy')comments.push({id:'ep'+ep.id+'artificial',user:'ModoTeste',role:'Teste',text:'Avaliação artificial: '+ep.viewers+'/100. Esta campanha suaviza a recepção para você experimentar.',likes:0,parent:null});
 return comments;
};
function publishSocial(sh,ep){
 const rng=seeded(s.campaignId+'social'+ep.id),stars=(ep.credits||[]).filter(c=>c.id).sort((a,b)=>b.fame-a.fame),star=stars[0],count=clamp(4+Math.floor(Math.log10(Math.max(10,sh.fanBase)))*2+Math.floor((star?.fame||0)/25),5,20);
 const facts=ep.analysis?.length?ep.analysis:[factor('general','Recepção',ep.viewers,'Nota do público: '+ep.viewers+'/100.','Desenvolva o argumento.')];
 for(let i=0;i<count;i++){
  const serial=++s.social.serial,voice=SOCIAL_VOICES[i%3],f=facts[Math.floor(rng()*facts.length)],positive=f.score>=65,platform=['tuiter','istagram','facibuk'][(i+ep.id)%3],name=pick(rng,SOCIAL_NAMES)+'_'+(100+Math.floor(rng()*900));
  let content=speech(voice,rng,positive)+' '+(i%4===0&&star?'a participação de '+star.name+' em '+star.role.toLowerCase()+' me levou a assistir. Técnica da gravação: '+star.technique+'/100. ':f.evidence+' ')+(positive?pick(rng,['Quero acompanhar o próximo trabalho.','Ficou na minha lista.','Foi o detalhe que mais guardei.','Vale conversar sobre essa proposta.','Falei dessa escolha em casa.']):f.advice);
  const text=sh.name+' · '+unitLabel(sh,ep)+' “'+ep.title+'”: '+content,key=hashText(text);
  if(s.social.used[key])continue;s.social.used[key]=true;
  const base={id:'post'+serial,platform,user:name,voice,week:s.week,showId:sh.id,title:sh.name,text,likes:Math.floor(rng()*(30+ep.viewership*.00015)),replyTo:null};s.social.posts.unshift(base);
  if(s.difficulty==='director'&&i%4===1){
   const replyId=++s.social.serial,replyText='@'+name+', vejo de outro jeito em '+sh.name+' '+unitLabel(sh,ep)+': '+(star?'ter '+star.name+' chamou atenção, mas ':'')+f.label.toLowerCase()+' ainda precisa ser discutido. '+facts[(i+1)%facts.length].evidence,keyReply=hashText(replyText);
   if(!s.social.used[keyReply]){s.social.used[keyReply]=true;s.social.posts.unshift({id:'post'+replyId,platform,user:pick(rng,SOCIAL_NAMES)+'_debate'+replyId,voice:SOCIAL_VOICES[(i+1)%3],week:s.week,showId:sh.id,title:sh.name,text:replyText,likes:Math.floor(rng()*80),replyTo:base.id});}
  }
 }
 s.social.posts=s.social.posts.slice(0,600);
}
airEpisode=function(sh,ep){
 if(ep.status==='aired')return null;
 const n=networkBy(sh.networkId),own=s.networks.find(x=>x.id===sh.networkId),rng=seeded(s.campaignId+'air'+ep.id),dist=distribution(sh);
 ep.qualityBoost=ep.qualityBoost||0;ep.promo=ep.promo||0;ep.analysis=ep.analysis||buildAnalysis(sh,{...ep,baseBudget:ep.baseBudget||ep.budget,crew:ep.crew||38,dept:ep.dept||0});
 const fs=ep.analysis,narrative=weighted(fs.filter(f=>['premise','motivation','conflict','payoff','causality','development','originality'].includes(f.key))),technical=weighted(fs.filter(f=>['budget','crew','voice'].includes(f.key))),artificial=s.difficulty==='easy',quality=Number.isFinite(ep.quality)?ep.quality:weighted(fs);
 const adPenalty=own&&own.type!=='Streaming'?own.adLoad*2:0;
 const critics=clamp((artificial?70+quality*.23:narrative*.68+technical*.16+quality*.16)+policy().leniency+ep.qualityBoost*.15,5,100);
 const fans=clamp((artificial?73+quality*.21:narrative*.6+technical*.18+quality*.22)+policy().leniency-adPenalty,5,100);
 const debate=Math.abs(fans-critics)>=8;
 const rivals=s.world.filter(w=>w.networkId===sh.networkId&&w.status==='active'&&w.genre===sh.genre),competition=1-clamp(rivals.reduce((v,w)=>v+w.viewers,0)/18000000,0,.12);
 const starMultiplier=ep.fameMultiplier||1,marketing=1+(ep.marketingTechnique||38)*.001+(s.upgrades.marketing||0)*.04,ownPromo=1+(own?.promoBudget||0)/200000;
 const base=100000+sh.appeal*4500+sh.hype*2800+ep.promo*25+quality*6800+Math.min(1000000,sh.fanBase*.5);
 const audience=Math.max(1,Math.round(base*(n?.reach||.7)*dist.fit*(dist.type==='Streaming'?1:dist.slot*dist.weekend)*(1+s.reputation/250)*(sh.genre===s.trend?1.2:1)*starMultiplier*marketing*ownPromo*competition*(ep.boostAudience?1.4:1)*(.96+rng()*.08)));
 const adRates=[0,.034,.056,.079],revenue=own?Math.round(audience*(own.type==='Streaming'?.015:adRates[own.adLoad])):Math.round(sh.fee*(fans>=75?1.16:1));
 const previous=sh.episodes.filter(e=>e.status==='aired').at(-1);
 ep.status='aired';ep.airWeek=s.week;ep.viewers=Math.round(fans);ep.critics=Math.round(critics);ep.quality=Math.round(quality);ep.viewership=audience;ep.likes=Math.round(audience*clamp(fans/100*.52,0,.65));ep.favorites=Math.round(ep.likes*clamp(narrative/100*.19+(isFilm(sh)?.01:.04),.01,.3));ep.reviewCount=Math.round(audience*(.015+critics/100*.025));ep.negativeReviews=Math.round(ep.reviewCount*(1-critics/100));ep.controversial=debate;ep.revenue=revenue;ep.netProduction=revenue-ep.budget;ep.artificial=artificial;
 ep.distribution={...dist,networkId:n?.id,networkName:n?.name||'Independente',reach:n?.reach||.7,trend:sh.genre===s.trend,hype:sh.hype,reputation:s.reputation,marketing:s.upgrades.marketing,starMultiplier,marketingMultiplier:marketing,competition,adLoad:own?.adLoad??null,revenuePolicy:own?'Publicidade: '+(own.type==='Streaming'?'.015':adRates[own.adLoad])+' por visualização. Assinaturas são registradas no fechamento semanal.':'Licença: '+money(sh.fee)+', com bônus de 16% se público ≥75.'};
 ep.comparison=previous?{id:previous.id,title:previous.title,views:audience-previous.viewership,public:ep.viewers-previous.viewers,critics:ep.critics-previous.critics}:null;
 ep.comments=commentThread(sh,ep,fs,rng);ep.reviewCritic=ep.comments.find(c=>c.role==='Crítico')?.text||'';ep.reviewFan=ep.comments.find(c=>c.role==='Fã')?.text||'';
 changeCash(revenue,'Exibição '+unitLabel(sh,ep)+': '+sh.name,own?'Publicidade própria':'Exibições');sh.totalViewers+=audience;const aired=sh.episodes.filter(e=>e.status==='aired');sh.avgAudience=Math.round(sh.totalViewers/aired.length);sh.avgCritics=Math.round(aired.reduce((v,e)=>v+e.critics,0)/aired.length);sh.hype=clamp(sh.hype+(fans-50)/15,0,75);
 ep.newFans=Math.round(audience*fans/100*.02);sh.fanBase+=ep.newFans;s.fans+=ep.newFans;s.reputation=clamp(s.reputation+(critics>=80?2:critics<40?-2:0),0,100);s.counts.air++;s.counts.revenue+=revenue;if(fans>=70)s.counts.reviews4++;
 if(own){own.metrics.views+=audience;own.metrics.revenue+=revenue;own.metrics.profit+=revenue;}
 publishSocial(sh,ep);addNews('Estreia: '+sh.name,compact(audience)+' visualizações. Público '+ep.viewers+'/100; crítica '+ep.critics+'/100. '+(ep.actorName?'Participação de '+ep.actorName+'.':''),'Estreias',sh.id);log(sh.name+' '+unitLabel(sh,ep)+': '+compact(audience)+' visualizações; '+compact(ep.likes)+' gostei; '+compact(ep.favorites)+' favoritos.');
 return{show:sh.name,showId:sh.id,episodeId:ep.id,episode:ep.number,season:ep.season,kind:sh.kind,viewers:ep.viewers,critics:ep.critics,audience,revenue,controversial:debate};
};
function closeOwnedNetwork(n,reports){
 const fixed=networkWeeklyCost(n),promo=n.paused?0:n.promoBudget;changeCash(-fixed,'Manutenção de emissora: '+n.name,'Emissoras');if(promo)changeCash(-promo,'Divulgação da emissora: '+n.name,'Divulgação');n.metrics.expenses+=fixed+promo;n.metrics.profit-=fixed+promo;
 if(n.paused){n.lastWeekly={networkId:n.id,name:n.name,week:s.week,views:0,revenue:0,expenses:fixed,profit:-fixed,subscribers:n.subscribers,newSubscribers:0,churn:0,licensedRevenue:0,subscriptions:0};n.history.push(n.lastWeekly);n.history=n.history.slice(-100);return n.lastWeekly;}
 let views=0,licensedRevenue=0,qualitySum=0,items=0,originalRevenue=0;
 for(const r of reports.filter(x=>showBy(x.showId)?.networkId===n.id)){views+=r.audience;qualitySum+=r.viewers;items++;originalRevenue+=r.revenue;}
 for(const l of n.licensed.filter(x=>x.from<=s.week&&x.until>=s.week)){
  const fit=n.focus.includes(l.genre)?1.08:.9,audience=Math.round(l.views*.32*n.reach*fit*(1+n.promoBudget/200000)),revenue=Math.round(audience*(n.type==='Streaming'?.01:[0,.025,.045,.065][n.adLoad]));
  views+=audience;licensedRevenue+=revenue;qualitySum+=l.quality;items++;n.metrics.views+=audience;
 }
 if(licensedRevenue){changeCash(licensedRevenue,'Licenciamento exibido: '+n.name,'Catálogo próprio');s.counts.revenue+=licensedRevenue;n.metrics.revenue+=licensedRevenue;n.metrics.profit+=licensedRevenue;}
 if(items)n.quality=Math.round(clamp(qualitySum/items+(n.levels.technology||0)*3,0,100));
 let gained=0,churn=0,subscriptions=0;
 if(n.type==='Streaming'){
  const conversion=clamp(.002*(n.quality/100)*(24/n.subscriptionPrice),.00015,.006),churnRate=clamp(.075-n.quality*.00045+(n.subscriptionPrice-24)*.0015,.02,.15);
  gained=Math.round(views*conversion);churn=Math.round(n.subscribers*churnRate);n.subscribers=Math.max(0,n.subscribers-churn+gained);subscriptions=Math.round(n.subscribers*n.subscriptionPrice/4);
  s.counts.subscribers=(s.counts.subscribers||0)+gained;if(subscriptions){changeCash(subscriptions,'Assinaturas: '+n.name,'Assinaturas');s.counts.revenue+=subscriptions;n.metrics.revenue+=subscriptions;n.metrics.profit+=subscriptions;}
 }
 const revenue=originalRevenue+licensedRevenue+subscriptions,cost=fixed+promo;n.lastWeekly={networkId:n.id,name:n.name,week:s.week,views,revenue,expenses:cost,profit:revenue-cost,subscribers:n.subscribers,newSubscribers:gained,churn,licensedRevenue,subscriptions,originalRevenue};n.history.push(n.lastWeekly);n.history=n.history.slice(-100);
 return n.lastWeekly;
}
function advanceWorld(){
 for(const w of s.world){
  const rng=seeded(s.campaignId+'world'+w.id+s.week),n=networkBy(w.networkId);w.updatedWeek=s.week;
  if(w.kind==='series'){w.episode++;if(w.episode>8){w.season++;w.episode=1;}}
  else if(s.week%8===0){w.season++;w.name= WORLD_TITLES[Number(w.id.replace('world',''))]+(w.season>1?' '+w.season:'');}
  w.quality=clamp(w.quality+Math.floor(rng()*7)-3,48,95);w.viewers=Math.round((250000+w.quality*7000+rng()*230000)*n.reach*(w.genre===s.trend?1.2:1));w.history.push({week:s.week,quality:w.quality,views:w.viewers});w.history=w.history.slice(-12);
 }
 const top=s.world.slice().sort((a,b)=>b.viewers-a.viewers),leader=top[(s.week-1)%Math.min(top.length,8)];addNews('Panorama da semana '+s.week,leader.name+', de '+leader.studio+', fez '+compact(leader.viewers)+' visualizações em '+networkBy(leader.networkId).name+'. A crítica simulada marcou '+leader.quality+'/100.','Mercado');
 const serial=++s.social.serial,rng=seeded(s.campaignId+'industry'+s.week),text='Semana '+s.week+': alguém acompanhou '+leader.name+' na '+networkBy(leader.networkId).name+'? '+compact(leader.viewers)+' visualizações e '+leader.quality+'/100 de crítica. '+pick(rng,['Quero comparar com os novos lançamentos.','Fiquei curioso com a próxima produção desse estúdio.','Vou acompanhar o que as outras produtoras fazem agora.','A disputa por atenção tá boa nesta semana.']);
 const key=hashText(text);if(!s.social.used[key]){s.social.used[key]=true;s.social.posts.unshift({id:'post'+serial,platform:['tuiter','istagram','facibuk'][s.week%3],user:pick(rng,SOCIAL_NAMES)+'_cinema',voice:SOCIAL_VOICES[s.week%3],week:s.week,title:leader.name,text,likes:Math.floor(rng()*350),replyTo:null,showId:null});s.social.posts=s.social.posts.slice(0,600);}
}
const AWARD_CATEGORIES=[
 {id:'film',name:'Melhor filme',event:'Oscar do Império',cash:110000,kind:'film',mode:'quality'},
 {id:'series',name:'Melhor série',event:'Coroa de Ouro TV',cash:100000,kind:'series',mode:'quality'},
 {id:'script',name:'Roteiro original',event:'Oscar do Império',cash:80000,mode:'story'},
 {id:'direction',name:'Direção',event:'Coroa de Ouro TV',cash:60000,mode:'direction'},
 {id:'acting',name:'Atuação',event:'Coroa de Ouro TV',cash:60000,mode:'acting'},
 {id:'voice',name:'Voz e dublagem',event:'Coroa de Ouro TV',cash:45000,mode:'voice'},
 {id:'public',name:'Escolha do público',event:'Coroa de Ouro TV',cash:65000,mode:'public'}
];
function awardScore(ep,mode){
 if(mode==='story')return weighted((ep.analysis||[]).filter(f=>['premise','motivation','conflict','payoff','causality','development','originality'].includes(f.key)));
 if(mode==='direction')return ep.quality*.8+(ep.credits?.find(c=>c.role==='Direção')?.technique||38)*.2;
 if(mode==='acting')return ep.viewers*.65+(ep.credits?.find(c=>c.role==='Atuação')?.technique||38)*.35;
 if(mode==='voice')return ep.quality*.65+(ep.credits?.find(c=>c.role==='Dublagem')?.technique||38)*.35;
 if(mode==='public')return ep.viewers*.8+clamp(Math.log10(Math.max(1,ep.viewership))*3,0,20);
 return ep.quality*.7+ep.critics*.3;
}
function runAwards(){
 const cycle=Math.floor(s.week/12);if(!cycle||s.awards.lastCycle>=cycle)return;s.awards.lastCycle=cycle;
 const start=(cycle-1)*12,end=cycle*12,results=[];
 for(const cat of AWARD_CATEGORIES){
  const entries=[];
  for(const sh of s.shows){if(cat.kind&&sh.kind!==cat.kind)continue;const eligible=sh.episodes.filter(ep=>ep.status==='aired'&&ep.airWeek>start&&ep.airWeek<=end);if(!eligible.length)continue;const best=eligible.sort((a,b)=>awardScore(b,cat.mode)-awardScore(a,cat.mode))[0];entries.push({showId:sh.id,episodeId:best.id,title:sh.name,studio:s.name,score:Math.round(awardScore(best,cat.mode)),player:true});}
  for(const w of s.world){if(cat.kind&&w.kind!==cat.kind)continue;const rng=seeded(w.id+cat.id+cycle);entries.push({showId:w.id,title:w.name,studio:w.studio,score:clamp(w.quality+Math.floor(rng()*9)-5,40,98),player:false});}
  entries.sort((a,b)=>b.score-a.score||String(a.showId).localeCompare(String(b.showId)));const nominees=entries.slice(0,3),winner=nominees[0];if(!winner)continue;
  const nominations=nominees.filter(x=>x.player).length;s.awards.nominations+=nominations;
  if(winner.player){s.awards.wins++;changeCash(cat.cash,'Prêmio: '+cat.name+' / '+winner.title,'Prêmios');s.reputation=clamp(s.reputation+4,0,100);addXP(100);}
  results.push({category:cat.name,event:cat.event,nominees,winner,reward:winner.player?cat.cash:0});
  addNews(cat.event+': '+cat.name,winner.title+' ('+winner.studio+') venceu com '+winner.score+'/100 no júri simulado.'+(winner.player?' '+money(cat.cash)+' depositados.':''),'Prêmios',winner.player?winner.showId:null);
 }
 s.awards.history.unshift({cycle,week:s.week,start:start+1,end,results});s.awards.history=s.awards.history.slice(0,60);
}
nextWeek=function(){
 if(s.difficulty==='director'&&!s.grantTaken)return notice('Apresente um mini roteiro e aceite financiamento para iniciar a produção.',true);
 migrateBeta(s);const startCash=s.cash;s.week++;const reports=[],payroll=hiredCost(),studio=studioOverhead();changeCash(-payroll,'Folha de pagamento','Salários');changeCash(-studio,'Manutenção da produtora','Manutenção');
 for(const sh of s.shows){
  if(!['active','between'].includes(sh.status))continue;
  for(const ep of sh.episodes)if(ep.status==='produced'&&ep.airWeek<=s.week&&!s.networks.find(n=>n.id===sh.networkId)?.paused){const result=airEpisode(sh,ep);if(result)reports.push(result);}
  if(sh.status==='active'&&seasonCompleted(sh)){sh.status=isFilm(sh)?'ended':'between';log(sh.name+(isFilm(sh)?' concluiu a estreia. Continuação disponível.':' concluiu a temporada '+sh.season+'. Avalie a renovação.'));}
 }
 const networkReports=s.networks.map(n=>closeOwnedNetwork(n,reports));if(s.week%4===0)s.trend=genres[dice(Math.min(genres.length,3+s.level*2))];advanceWorld();runAwards();addXP(reports.length*8+2);checkGoals();
 if(s.cash<0){s.reputation=clamp(s.reputation-3,0,100);log('Caixa negativo. Revise folha, publicidade, contratos e custos da grade.');}
 const fixed=payroll+studio+networkReports.reduce((v,n)=>v+n.expenses,0),net=s.cash-startCash;
 s.history.push({week:s.week,cash:s.cash,fans:s.fans,viewers:reports.reduce((v,r)=>v+r.audience,0),aired:reports.length,net,expenses:fixed});s.history=s.history.slice(-200);
 currentEnd={week:s.week,expense:fixed,reports,networkReports,net,startCash};tab='end';save();render();
};

/* Empire TV beta — responsive pages and contextual navigation. */
const TV_LOGO='<svg viewBox="0 0 64 64" role="img" aria-label="Empire TV: televisão com coroa" xmlns="http://www.w3.org/2000/svg"><path d="M18 19 13 6 24 12 32 3 40 12 51 6 46 19Z" fill="#f4c65b"/><rect x="7" y="24" width="50" height="33" rx="8" fill="#18283d" stroke="#efc35a" stroke-width="3"/><rect x="13" y="30" width="31" height="20" rx="4" fill="#78ded0"/><path d="m25 34 10 6-10 6Z" fill="#17324a"/><circle cx="50" cy="35" r="2" fill="#f4c65b"/><path d="M48 43h4M20 58l-3 3m27-3 3 3" stroke="#f4c65b" stroke-width="2.5" stroke-linecap="round"/></svg>';
const NAV_ITEMS=[['home','⌂','Estúdio'],['shows','▣','Obras'],['production','▶','Produção'],['reports','◉','Análises'],['team','♟','Equipe'],['networks','◈','Emissoras'],['goals','◎','Objetivos'],['company','▤','Empresa'],['social','♡','Redes'],['awards','♛','Prêmios'],['settings','⚙','Configurações']];
function rightsFooter(){return'<footer class="rights">© 2026 V&amp;D Digital. Todos os direitos reservados.</footer>';}
function pill(value,color=''){return'<span class="pill '+color+'">'+esc(value)+'</span>';}
function kpis(items){return'<div class="kpi-grid">'+items.map(x=>'<div class="kpi"><small>'+esc(x[0])+'</small><b>'+esc(x[1])+'</b>'+(x[2]?'<span>'+esc(x[2])+'</span>':'')+'</div>').join('')+'</div>';}
function pageHead(title,desc,badge=''){return'<section class="section"><div class="head"><h2>'+esc(title)+'</h2>'+(badge?pill(badge,'cyan'):'')+'</div><p class="subhead">'+esc(desc)+'</p>';}
function closePage(){return'</section>';}
function jump(label,to,style='secondary'){return'<button class="'+style+'" data-tab="'+esc(to)+'">'+esc(label)+'</button>';}
function field(label,name,value='',type='text',attrs=''){return'<label class="label">'+esc(label)+'</label><input type="'+type+'" name="'+esc(name)+'" value="'+esc(value)+'" '+attrs+'>';}
function optionSelect(label,name,values,current,attrs=''){return'<label class="label">'+esc(label)+'</label><select name="'+esc(name)+'" '+attrs+'>'+values.map(v=>'<option value="'+esc(Array.isArray(v)?v[0]:v)+'" '+((Array.isArray(v)?v[0]:v)===current?'selected':'')+'>'+esc(Array.isArray(v)?v[1]:v)+'</option>').join('')+'</select>';}
function betaHeader(){
 return'<header class="beta-header"><div class="beta-brand"><button type="button" class="menu-trigger" data-toggle-menu aria-label="Abrir menu" aria-expanded="'+menuOpen+'" aria-controls="beta-menu">☰</button><div class="brand"><div class="beta-logo">'+TV_LOGO+'</div><div><h1>EMPIRE TV '+pill('BETA','orange')+'</h1><p>'+esc(s.name)+'</p></div></div></div><div class="header-actions"><span class="syncpill">'+(account.type==='cloud'?(syncStatus==='cloud'?'Sincronizado':'Sincronização pendente'):'Conta local')+'</span><button class="small-btn" data-tab="settings" aria-label="Abrir configurações">⚙</button></div><nav class="beta-nav" id="beta-menu" '+(menuOpen?'':'hidden')+' aria-label="Menu principal">'+NAV_ITEMS.map(x=>'<button type="button" class="'+(tab===x[0]?'active':'')+'" data-beta-nav="'+x[0]+'"><span class="nav-icon">'+x[1]+'</span>'+x[2]+'</button>').join('')+'</nav></header>';
}
function pageSubnav(){
 const groups={home:[['','Estúdio'],['goals','Objetivos'],['production','Produção']],shows:[['','Catálogo'],['production','Produção'],['reports','Análises']],production:[['','Gravação'],['shows','Obras'],['team','Equipe']],reports:[['','Resultados'],['shows','Catálogo']],team:[['','Equipe'],['agency','Agência de talentos']],networks:[['','Emissoras'],['owned','Minhas emissoras'],['world','Produções do mercado']],goals:[['','Objetivos'],['catalog','Catálogo de desafios']],company:[['','Estatísticas'],['upgrades','Melhorias']],social:[['tuiter','Tuiter'],['istagram','Istagram'],['facibuk','Facibuk']],awards:[['','Prêmios'],['journal','Jornal']],settings:[['','Conta e campanhas'],['help','Como jogar']]};
 return'<nav class="page-subnav" aria-label="Abas desta página">'+(groups[tab]||groups.home).map(x=>{
  const external=['home','shows','production','reports'].includes(tab)&&x[0]!=='';const active=tab==='social'?socialNetwork===x[0]:!external&&subpage===x[0];
  return'<button class="'+(active?'active':'')+'" '+(external?'data-tab="'+x[0]+'"':'data-subpage="'+x[0]+'"')+'>'+esc(x[1])+'</button>';
 }).join('')+'</nav>';
}
const betaStoryBase=storyInputs;
storyInputs=function(sh){return betaStoryBase(sh)+'<label class="label">Intenção criativa / identidade da obra</label><textarea name="intent" maxlength="1200" placeholder="Explique como suas escolhas servem à ideia. Ex.: o humor aparece como defesa do protagonista, e a montagem fragmentada revela sua memória.">'+esc(sh?.intent||'')+'</textarea><p class="scope-label">A avaliação combina argumento, intenção e execução. Você pode misturar gêneros e estilos; explique o efeito desejado em vez de seguir uma combinação fixa.</p>';};
const betaNewShowBase=newShowForm;
newShowForm=function(){return betaNewShowBase()+'<p class="scope-label">Gêneros liberados no nível '+s.level+': '+genres.filter(genreUnlocked).map(esc).join(', ')+'. Novos gêneros entram com o nível da produtora.</p>';};
function crewForm(sh){
 return'<details><summary>Equipe desta obra · cargos e responsabilidades</summary><form data-action="assignCrew"><input type="hidden" name="showId" value="'+sh.id+'"><div class="formgrid">'+BETA_ROLES.map(role=>optionSelect(role,role,[['','Melhor profissional disponível']].concat(hired(role).map(t=>[t.id,t.name+' · '+technique(t,sh.genre,role)+' técnica / '+t.fame+' fama'])),sh.team[role]||'')).join('')+'</div><button type="submit" class="secondary">Salvar equipe da obra</button></form><p class="scope-label">A atribuição de cargo fica na página Equipe. Aqui você escolhe o responsável por cada função desta obra. Apoio interno usa técnica 38 e fama 0.</p></details>';
}
function pitchPanel(sh){
 const choices=[...s.networks.filter(n=>!n.paused),...networks].filter(n=>sh.status!=='cancelled'||n.id!==sh.networkId).sort((a,b)=>(a.threshold||0)-(b.threshold||0));
 const first=choices[0],p=first?pitchPreview(sh,first):null;
 return'<details '+(sh.status==='cancelled'?'open':'')+'><summary>'+(sh.status==='cancelled'?'Apresentar a outra emissora':'Negociar distribuição')+'</summary><p class="scope-label">As 40 redes do mercado têm alcance, especialidades e exigências diferentes. Uma proposta excelente recebe vantagem mesmo com pouca reputação.</p><form data-action="pitch"><input type="hidden" name="showId" value="'+sh.id+'">'+optionSelect('Emissora','network',choices.map(n=>[n.id,n.name+' · '+n.type+' · '+pitchPreview(sh,n).chance+'% de aprovação']),first?.id||'','data-pitch-preview="'+sh.id+'"')+'<div class="info" data-pitch-info>'+esc(p?first.name+': '+p.why+' Chance '+p.chance+'%. Licença '+money(p.fee)+(isFilm(sh)?' pelo filme.':' por episódio.'):'Nenhuma emissora disponível.')+'</div><button type="submit" class="primary">Apresentar proposta</button></form></details>';
}
showTile=function(sh){
 const aired=sh.episodes.filter(e=>e.status==='aired'),mean=aired.length?Math.round(aired.reduce((v,e)=>v+e.viewers,0)/aired.length):null;
 return'<article class="card"><div class="between wrap"><div><span class="tag">'+(isFilm(sh)?'FILME':'SÉRIE · T'+sh.season)+' · '+esc(sh.genre)+' · '+sh.duration+' MIN</span><h3>'+esc(sh.name)+'</h3></div>'+pill(showStatus(sh),sh.status==='active'?'green':sh.status==='cancelled'?'red':'orange')+'</div><p>'+esc(sh.concept||'Escreva a premissa para fortalecer a proposta.')+'</p>'+kpis([['Visualizações',compact(sh.totalViewers)],['Público',fmtScore(mean)],['Crítica',fmtScore(aired.length?sh.avgCritics:null)],['Fãs da obra',compact(sh.fanBase)]])+'<p class="small">'+esc(networkBy(sh.networkId)?.name||'Sem distribuidor')+(sh.networkId?' · '+money(sh.fee)+(isFilm(sh)?' por filme':' por episódio'):'')+'</p>'+ (sh.parentId?'<p class="scope-label">Continuação de '+esc(showBy(sh.parentId)?.name||sh.franchiseRoot)+' · franquia '+esc(sh.franchiseRoot)+'.</p>':'')+'<div class="btnrow">'+(sh.status==='active'?'<button class="primary" data-produce-tab="'+sh.id+'">Produzir '+(isFilm(sh)?'filme':'episódio')+'</button>':'')+(sh.status==='between'?'<button class="primary" data-renew="'+sh.id+'">Tentar renovação</button>':'')+(['active','between','cancelled'].includes(sh.status)?'<button class="ghost" data-end="'+sh.id+'">Finalizar obra</button>':'')+(sh.status==='ended'?'<button class="secondary" data-sequel="'+sh.id+'">Desenvolver continuação</button>':'')+(sh.episodes.length?'<button class="secondary" data-history="'+sh.id+'">Exibições e comentários</button>':'')+'</div>'+ (formDefaults.history===sh.id?episodeHistory(sh):'')+
 '<details><summary>Revisar argumento e intenção</summary><form data-action="editStory"><input type="hidden" name="showId" value="'+sh.id+'">'+storyInputs(sh)+'<button class="secondary" type="submit">Salvar argumento</button></form></details>'+crewForm(sh)+fundingPanel(sh)+(['development','cancelled'].includes(sh.status)?pitchPanel(sh):'')+
 (sh.pitchHistory.length?'<details><summary>Histórico de negociações</summary>'+sh.pitchHistory.slice(0,12).map(p=>'<div class="world-item"><b>'+esc(p.network)+' · '+(p.result==='accepted'?'Aprovada':'Recusada')+'</b><p>Semana '+p.week+' · proposta '+p.quality+'/100 · chance '+p.chance+'% · licença '+money(p.fee)+'.</p><p>'+esc(p.why)+'</p></div>').join('')+'</details>':'')+'</article>';
};
shows=function(){return pageHead('Séries, filmes e continuações','Desenvolva, revise o argumento e negocie cada obra. Uma série sem renovação pode buscar outra emissora.',activeCount()+'/'+capacity()+' obras ativas')+'<div class="catalog-grid"><div>'+newShowForm()+'</div><div class="rows">'+s.shows.slice().reverse().map(showTile).join('')+(s.shows.length?'':'<div class="empty">Seu catálogo começa com uma ideia.</div>')+'</div></div>'+closePage();};
const betaProductionFormBase=productionForm;
productionForm=function(sh){
 let html=betaProductionFormBase(sh);if(!html.includes('data-action="produce"'))return html;
 const lead=crewMember(sh,'Atuação');html=html.replace(/<select name="actor">[\s\S]*?<\/select>/,'<select name="actor">'+(hired('Atuação').length?hired('Atuação').map(t=>'<option value="'+t.id+'" '+(t.id===lead?.id?'selected':'')+'>'+esc(t.name)+' · '+technique(t,sh.genre,'Atuação')+' técnica · '+t.fame+' fama</option>').join(''):'<option value="">Elenco de apoio · técnica 38</option>')+'</select>');
 html=html.replace('<div class="formgrid"><div><label class="label">Investimento','<label class="label">Intenção desta gravação</label><textarea name="intent" maxlength="1200" placeholder="Por que este estilo faz sentido para a história?">'+esc(sh.intent)+'</textarea><div class="formgrid"><div><label class="label">Investimento');
 const credits=crewSnapshot(sh,''),fame=fameMultiplier(credits),impact='<div class="story-note" data-crew-preview="'+sh.id+'"><b>Impacto previsto da equipe</b><p>Fama: +'+Math.round((fame-1)*100)+'% no alcance potencial. Divulgação amplia o público; a qualidade depende principalmente da narrativa.</p><p>'+credits.map(c=>esc(c.role)+': <b>'+esc(c.name)+'</b> · '+c.technique+' técnica, '+c.fame+' fama').join('<br>')+'</p></div>';
 return impact+crewForm(sh)+html;
};
function betaTalentCard(t,employed=false){
 const odds=employed?null:marketChance(t)*100,role=employed?jobFor(t.id):t.role,specialties=(t.specialties||[t.genre]).join(' / ');
 return'<article class="card talent-card"><div class="between"><span class="tag">'+esc(role)+'</span>'+pill(t.trainee?'Novo talento':t.fame>=94?'Lendário':t.fame>=85?'Celebridade':'Especialista',t.fame>=94?'orange':'cyan')+'</div><h3 class="talent-name">'+esc(t.name)+'</h3><p>'+esc(t.career||'Profissional da produtora')+'</p><p><b>Especialidades:</b> '+esc(specialties)+'</p><div class="mini-grid"><div>Técnica<strong>'+t.skill+'/100</strong></div><div>Fama<strong>'+t.fame+'/100</strong></div><div>Salário semanal<strong>'+money(employed?salaryOf(t):t.salary)+'</strong></div><div>'+ (employed?'Cargo de origem':'Aparição nesta rodada')+'<strong>'+(employed?esc(t.role):odds.toFixed(1).replace('.',',')+'%')+'</strong></div></div><p class="scope-label">'+(employed?(role!==t.role?'Cargo fora da formação: técnica ×0,60. ':'')+'O vínculo continua depois que a agência muda.':'Probabilidade individual de entrar entre os quatro candidatos deste cargo; calculada para o conjunto atual de não contratados.')+'</p>'+
 (employed?'<form data-action="assignJob"><input type="hidden" name="talentId" value="'+esc(t.id)+'">'+optionSelect('Cargo de trabalho','role',BETA_ROLES,role)+'<button class="secondary" type="submit">Atribuir cargo</button></form><button class="ghost bad" data-fire="'+esc(t.id)+'" style="margin-top:12px">Dispensar profissional</button>':'<button class="secondary fullwidth" data-hire="'+esc(t.id)+'" '+(s.hired.length>=standardRosterCapacity()?'disabled':'')+'>Contratar · '+money(t.salary*2)+'</button>')+'</article>';
}
marketCards=function(){const cycle=marketCycle();return BETA_ROLES.filter(role=>agencyFilter==='all'||agencyFilter===role).map(role=>'<div class="role-heading"><h3>'+esc(ROLE_LABELS[role])+'</h3>'+pill('4 candidatos')+'</div><div class="beta-grid">'+cycle.entries.filter(t=>t.role===role).map(t=>betaTalentCard(t)).join('')+'</div>').join('');};
team=function(){
 if(subpage!=='agency')return pageHead('Sua equipe','Atribua um cargo a cada contratado. A formação, a especialidade e a fama afetam as próximas produções.',s.hired.length+'/'+rosterCapacity()+' vagas')+kpis([['Profissionais',s.hired.length],['Vagas nominais',standardRosterCapacity()],['Folha semanal',money(hiredCost())],['Fama média',hired().length?Math.round(hired().reduce((v,t)=>v+t.fame,0)/hired().length)+'/100':'—']])+'<div class="info">Especialista no gênero recebe +12 de técnica, até 100. Cargo fora da formação usa 60% da técnica. Escolha a equipe de cada obra no catálogo ou na produção.</div><div class="btnrow"><button class="primary" data-subpage="agency">Abrir agência de talentos</button>'+jump('Ampliar vagas','company')+'</div><div class="grid" style="margin-top:18px">'+hired().map(t=>betaTalentCard(t,true)).join('')+(s.hired.length?'':'<div class="empty">Sua equipe ainda não tem contratados. Apoio interno tem técnica 38 e fama 0.</div>')+'</div>'+closePage();
 return pageHead('Agência de talentos','Quatro profissionais em cada área por rodada: 24 candidatos. A lista permanece estável por cinco minutos reais.',s.hired.length+'/'+rosterCapacity()+' contratados')+'<div class="info between wrap"><span>Atualização de cinco em cinco minutos. A contratação preenche a vaga com outro candidato.</span><b data-market-timer></b></div><div class="chip-row">'+[['all','Todos']].concat(BETA_ROLES.map(r=>[r,ROLE_LABELS[r]])).map(x=>'<button class="filter-chip '+(agencyFilter===x[0]?'active':'')+'" data-agency-filter="'+esc(x[0])+'">'+esc(x[1])+'</button>').join('')+'</div><details><summary>Catálogo de 100 referências e chances atuais</summary><p class="scope-label">Nomes humorísticos, carreira de referência e atributos do universo do jogo. As probabilidades mudam quando o conjunto disponível muda; o sorteio garante quatro pessoas por cargo.</p><div class="beta-table"><table class="table"><thead><tr><th>Talento</th><th>Cargo</th><th>Especialidades</th><th>Técnica / fama</th><th>Chance atual</th></tr></thead><tbody>'+talents.filter(t=>!t.legacyOnly&&!t.trainee).map(t=>'<tr><td><b class="accent">'+esc(t.name)+'</b></td><td>'+esc(t.role)+'</td><td>'+esc(t.specialties.join(', '))+'</td><td>'+t.skill+' / '+t.fame+'</td><td>'+(s.hired.includes(t.id)?'Contratado':(marketChance(t)*100).toFixed(1).replace('.',',')+'%')+'</td></tr>').join('')+'</tbody></table></div></details><div id="market-list">'+marketCards()+'</div>'+closePage();
};
function networkMini(n){
 const rivals=s.world.filter(w=>w.networkId===n.id),ours=s.shows.filter(sh=>sh.networkId===n.id),difficulty=n.threshold>=84?'Muito exigente':n.threshold>=70?'Exigente':n.threshold>=55?'Intermediária':'Acessível';
 return'<article class="card"><div class="between"><div class="beta-brand"><span class="network-badge">'+esc(n.name.slice(0,2).toUpperCase())+'</span><div><h3>'+esc(n.name)+'</h3><span class="tag">'+esc(n.type)+'</span></div></div>'+pill(difficulty,n.threshold>=84?'orange':'cyan')+'</div><p>'+esc(n.focus.join(' / '))+'</p><div class="mini-grid"><div>Alcance relativo<strong>×'+n.reach.toFixed(2)+'</strong></div><div>Exigência<strong>'+n.threshold+'/100</strong></div><div>Licença base / episódio<strong>'+money(n.fee)+'</strong></div><div>Suas obras<strong>'+ours.length+'</strong></div></div><details><summary>Programação e perfil comercial</summary><p class="scope-label">Alcance relativo multiplica visualizações. O valor do contrato depende da qualidade da proposta; filmes usam licença ×3,8. Redes maiores exigem mais evidência, salvo propostas excelentes.</p>'+rivals.map(w=>'<div class="world-item"><b>'+esc(w.name)+'</b><p>'+esc(w.studio)+' · '+(w.kind==='film'?'Filme':'T'+w.season+'E'+w.episode)+' · '+esc(w.genre)+'</p><p>Crítica '+w.quality+'/100 · '+compact(w.viewers)+' visualizações na última semana.</p></div>').join('')+ours.map(sh=>'<div class="world-item"><b>'+esc(sh.name)+'</b><p>Sua produtora · '+showStatus(sh)+'</p></div>').join('')+'</details></article>';
}
function worldPage(){return pageHead('O universo está no ar','Outras produtoras disputam a atenção do público. Suas temporadas e resultados avançam com a semana do jogo.',s.world.length+' obras fictícias')+'<div class="grid">'+s.world.slice().sort((a,b)=>b.viewers-a.viewers).map(w=>'<div class="card"><span class="tag">'+esc(w.studio)+'</span><h3>'+esc(w.name)+'</h3><p>'+esc(networkBy(w.networkId).name)+' · '+esc(w.genre)+' · '+(w.kind==='film'?'Filme':'T'+w.season+'E'+w.episode)+'</p><div class="mini-grid"><div>Visualizações da semana<strong>'+compact(w.viewers)+'</strong></div><div>Crítica<strong>'+w.quality+'/100</strong></div></div></div>').join('')+'</div>'+closePage();}
networksPage=function(){
 if(subpage==='owned')return ownedNetworksPage();if(subpage==='world')return worldPage();
 const filtered=networks.filter(n=>networkFilter==='all'||n.type===networkFilter);
 return pageHead('Emissoras e plataformas','Consulte os distribuidores e as produções que estão em exibição. Apresente sua obra no catálogo.',networks.length+' redes do mercado')+'<p class="scope-label">Este é um mercado fictício: nomes conhecidos convivem com redes inventadas. Alcances, contratos, programas e exigências são dados da simulação.</p><div class="chip-row">'+[['all','Todas'],['Aberta','TV aberta'],['Cabo','Cabo'],['Streaming','Streaming']].map(x=>'<button class="filter-chip '+(networkFilter===x[0]?'active':'')+'" data-network-filter="'+x[0]+'">'+x[1]+'</button>').join('')+'</div><div class="btnrow"><button class="primary" data-subpage="owned">Minhas emissoras</button><button class="secondary" data-subpage="world">Produções do mercado</button></div><div class="grid" style="margin-top:18px">'+filtered.map(networkMini).join('')+'</div>'+closePage();
};
function ownedNetworksPage(){
 return pageHead('Minhas emissoras','Administre identidade, público, programação, licenças, receita e despesas. O fechamento acontece a cada semana simulada.',s.networks.length+'/'+ownNetworkLimit()+' emissoras')+'<div class="card"><h3>Abrir uma emissora</h3><p>TV aberta: publicidade por visualização. Streaming: publicidade leve e assinaturas. A manutenção continua mesmo sem estreias; pausada custa R$ 1.800/semana.</p><div class="btnrow"><button class="primary" data-open-network="TV">TV aberta · R$ 220.000</button><button class="secondary" data-open-network="Streaming">Streaming · R$ 350.000</button></div><p class="scope-label">Uma vaga inicial, mais uma a cada três níveis, até seis emissoras. A abertura é um investimento registrado no resultado acumulado.</p></div><div class="rows" style="margin-top:18px">'+s.networks.map(ownedNetworkCard).join('')+'</div>'+closePage();
}
function ownedNetworkCard(n){
 const week=n.lastWeekly,shows=networkShows(n),licenses=n.licensed.filter(l=>l.until>=s.week),ratio=n.metrics.expenses?n.metrics.profit/n.metrics.expenses*100:0;
 return'<article class="card network-config"><div class="between wrap"><div><span class="tag">'+esc(n.type)+' · SUA EMISSORA</span><h3>'+esc(n.name)+'</h3></div>'+pill(n.paused?'Pausada':'Ativa',n.paused?'orange':'green')+'</div><p>'+esc(n.slogan)+'</p>'+
 kpis([['Receitas acumuladas',money(n.metrics.revenue)],['Despesas e investimentos',money(n.metrics.expenses)],['Resultado acumulado',money(n.metrics.profit)],['Alcance', '×'+n.reach.toFixed(2)]])+
 '<div class="mini-grid"><div>Vagas de programação<strong>'+(shows.length+licenses.length)+'/'+networkSlotCapacity(n)+'</strong></div><div>Manutenção / semana<strong>'+money(networkWeeklyCost(n))+'</strong></div><div>Assinantes atuais<strong>'+compact(n.subscribers)+'</strong></div><div>Retorno sobre despesas<strong>'+ratio.toFixed(1).replace('.',',')+'%</strong></div></div>'+
 (week?'<div class="info"><b>Fechamento da semana '+week.week+'</b><p>'+compact(week.views)+' visualizações · receita '+money(week.revenue)+' · despesas '+money(week.expenses)+' · resultado '+money(week.profit)+'.</p><p>Assinaturas: '+money(week.subscriptions||0)+' · '+compact(week.newSubscribers||0)+' novos assinantes / '+compact(week.churn||0)+' saídas. Catálogo licenciado: '+money(week.licensedRevenue||0)+'.</p></div>':'<div class="info">Ainda não houve fechamento. Configure a emissora, monte a grade e avance a semana.</div>')+
 '<div class="btnrow"><button class="ghost" data-pause-network="'+n.id+'">'+(n.paused?'Retomar emissora':'Pausar emissora')+'</button></div>'+
 '<details><summary>Identidade, público e política comercial</summary><form data-action="configureNetwork"><input type="hidden" name="networkId" value="'+n.id+'">'+field('Nome da emissora','name',n.name,'text','required maxlength="60"')+field('Slogan','slogan',n.slogan,'text','maxlength="160"')+'<label class="label">Até três gêneros prioritários</label><div>'+genres.map(g=>'<label class="check-label"><input type="checkbox" name="focus" value="'+esc(g)+'" '+(n.focus.includes(g)?'checked':'')+'>'+esc(g)+'</label>').join('')+'</div>'+optionSelect('Carga de publicidade','adLoad',[[0,'Sem anúncios · R$ 0 / visualização'],[1,'Leve · R$ 0,034 / visualização'],[2,'Média · R$ 0,056 / visualização'],[3,'Alta · R$ 0,079 / visualização']],n.adLoad)+field('Mensalidade do streaming (R$)','subscriptionPrice',n.subscriptionPrice,'number','min="12" max="60" step="1"')+optionSelect('Divulgação semanal da emissora','promoBudget',[[0,'Nenhuma'],[5000,'R$ 5.000'],[10000,'R$ 10.000'],[20000,'R$ 20.000']],n.promoBudget)+'<p class="scope-label">TV: cada nível de anúncios reduz a nota dos fãs em 2 pontos. Streaming: anúncios fixos leves rendem R$ 0,015 por visualização inédita; mensalidade maior reduz conversão e aumenta cancelamentos. Uma semana representa ¼ do mês de assinatura. Divulgação +5% de alcance por R$ 10 mil/semana. As prioridades dão +8% de alcance ao catálogo licenciado compatível.</p><button class="secondary" type="submit">Salvar configuração da emissora</button></form></details>'+
 '<details><summary>Melhorias de transmissão e capacidade</summary><div class="rows">'+[['signal','Sinal e distribuição','+0,14 no alcance; manutenção +R$ 1.400/semana',65000],['technology','Tecnologia','+3 na qualidade percebida da grade; manutenção +R$ 1.100/semana',65000],['slots','Grade e catálogo','+2 vagas de obras; manutenção +R$ 700/semana',35000]].map(a=>'<div class="world-item"><div class="between wrap"><div><b>'+a[1]+' · '+n.levels[a[0]]+'/5</b><p>'+a[2]+'</p></div><button class="secondary" data-network-upgrade="'+n.id+'" data-key="'+a[0]+'" '+(n.levels[a[0]]>=5?'disabled':'')+'>'+ (n.levels[a[0]]>=5?'Máximo':money(Math.round(a[3]*Math.pow(1.6,n.levels[a[0]]))))+'</button></div></div>').join('')+'</div></details>'+
 '<details open><summary>Grade e janelas de lançamento</summary>'+shows.map(sh=>'<div class="world-item"><b>'+esc(sh.name)+'</b><p>'+esc(sh.genre)+' · '+showStatus(sh)+' · '+sh.duration+' min</p><form data-action="schedule"><input type="hidden" name="showId" value="'+sh.id+'"><div class="formgrid">'+optionSelect('Dia','day',['Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'],sh.day)+optionSelect(n.type==='Streaming'?'Janela':'Horário','slot',['16:00','18:00','20:00','22:00','00:00'],sh.slot)+'</div><button class="secondary" type="submit">Salvar grade</button></form></div>').join('')+(shows.length?'':'<p>Sem obras ativas. Negocie a distribuição de um projeto com esta rede no catálogo.</p>')+'<p class="scope-label">TV aberta: 20h ×1,18; 18h ×1,05; meia-noite ×0,64; outros horários ×0,92. Fim de semana ×1,05. Streaming não aplica bônus de horário. Produções prontas aguardam a retomada se a rede estiver pausada.</p></details>'+
 '<details><summary>Licenciar obras de outras produtoras</summary><p>Licenças duram seis semanas, usam uma vaga e rendem exibições de catálogo. O preço cobre todo o período. O alcance do catálogo é 32% da audiência de referência, ajustado pela rede.</p>'+licenses.map(l=>'<div class="world-item"><b>'+esc(l.name)+'</b><p>Semanas '+l.from+' a '+l.until+' · licença '+money(l.cost)+' · crítica '+l.quality+'/100</p></div>').join('')+'<form data-action="licenseWorld"><input type="hidden" name="networkId" value="'+n.id+'">'+optionSelect('Obra disponível','worldId',s.world.filter(w=>!licenses.some(l=>l.worldId===w.id)).map(w=>[w.id,w.name+' · '+w.genre+' · '+money(Math.round(8000+w.quality*140+(w.kind==='film'?3000:0)))]),'')+'<button class="secondary" type="submit" '+(n.paused?'disabled':'')+'>Comprar licença de seis semanas</button></form><p class="scope-label">Catálogo na TV: publicidade R$ 0 / 0,025 / 0,045 / 0,065 por visualização conforme a carga. Streaming: R$ 0,01 por visualização, mais conversão em assinaturas. O caixa da produtora recebe as receitas e paga os custos desta rede.</p></details>'+
 '<details><summary>Histórico financeiro da emissora</summary><div class="beta-table"><table class="table"><thead><tr><th>Semana</th><th>Visualizações</th><th>Receitas</th><th>Despesas</th><th>Resultado</th></tr></thead><tbody>'+n.history.slice().reverse().map(h=>'<tr><td>'+h.week+'</td><td>'+compact(h.views)+'</td><td>'+money(h.revenue)+'</td><td>'+money(h.expenses)+'</td><td>'+money(h.profit)+'</td></tr>').join('')+'</tbody></table></div><p class="scope-label">O fechamento semanal inclui operação e divulgação. Abertura, melhorias e licenças entram no resultado acumulado quando compradas.</p></details></article>';
}
goalsPage=function(){
 const completed=objectiveDefs.filter(o=>s.claimed.includes(o.id)).length,active=s.daily.active;
 let html=pageHead(subpage==='catalog'?'Catálogo de desafios':'Objetivos da produtora','Conclua os primeiros objetivos. Depois disso, seis desafios novos chegam a cada 24 horas reais.',completed+'/'+objectiveDefs.length+' iniciais');
 if(subpage==='catalog')return html+'<p class="scope-label">'+DAILY_OBJECTIVES.length+' desafios diários em seis dificuldades. As recompensas variam de R$ 6 mil a R$ 160 mil e de zero a três powerups. Real diretor recebe dinheiro e XP, sem powerups. O progresso diário conta ações feitas depois que a rodada começou.</p><div class="beta-table"><table class="table"><thead><tr><th>Objetivo</th><th>Meta</th><th>Dinheiro</th><th>Powerups</th></tr></thead><tbody>'+DAILY_OBJECTIVES.slice().sort((a,b)=>a.tier-b.tier).map(o=>'<tr><td>'+esc(o.title)+'</td><td>'+esc(o.desc)+'</td><td>'+money(o.cash)+'</td><td>'+(s.difficulty==='director'?0:o.boostCount)+'</td></tr>').join('')+'</tbody></table></div>'+closePage();
 html+='<h3>Primeiros passos</h3><div class="grid">'+objectiveDefs.map(o=>{const done=s.claimed.includes(o.id),value=goalValue(o),progress=clamp(value/o.goal*100,0,100);return'<div class="card"><div class="between"><h3>'+esc(o.title)+'</h3>'+pill(done?'Concluído':'+'+o.xp+' XP',done?'green':'cyan')+'</div><p>'+esc(o.desc)+'</p><div class="bar"><i style="width:'+progress+'%"></i></div><div class="progress-label"><span>'+ (o.id==='revenue'?money(value):value)+' / '+(o.id==='revenue'?money(o.goal):o.goal)+'</span><span>'+money(o.cash)+' · '+(s.difficulty==='director'?'Sem powerups':'1 powerup')+'</span></div><p class="scope-label">'+(done?'Recompensa já depositada.':'Recompensa automática ao concluir.')+'</p></div>';}).join('')+'</div><h3 style="margin-top:26px">Objetivos de 24 horas</h3>';
 if(!active)return html+'<div class="info">Complete todos os '+objectiveDefs.length+' primeiros objetivos para liberar a rotação diária. A semana do jogo e o relógio dos objetivos são independentes.</div>'+closePage();
 html+='<div class="info between wrap"><span>Rodada '+s.daily.cycle+' · seis desafios; recompensas únicas.</span><b data-daily-timer></b></div><div class="grid">'+s.daily.tasks.map(item=>{const o=DAILY_OBJECTIVES.find(o=>o.id===item.id),value=dailyValue(o),ready=value>=o.goal;return'<div class="card tier-'+o.tier+'"><div class="between"><span class="tag">'+TIER_NAMES[o.tier]+'</span>'+pill(item.claimed?'Resgatado':ready?'Pronto':'Em andamento',item.claimed||ready?'green':'orange')+'</div><h3>'+esc(o.title)+'</h3><p>'+esc(o.desc)+'</p><div class="bar"><i style="width:'+clamp(value/o.goal*100,0,100)+'%"></i></div><div class="progress-label"><span>'+compact(Math.min(value,o.goal))+' / '+compact(o.goal)+'</span><span>+'+o.xp+' XP</span></div><p><b>'+money(o.cash)+'</b>'+ (s.difficulty==='director'?' · sem powerups':' · '+o.boostCount+' powerup(s) de '+({inspiracao:'inspiração',audiencia:'audiência',desconto:'desconto'})[o.boost])+'</p><button class="'+(ready&&!item.claimed?'primary':'secondary')+' fullwidth" data-claim-daily="'+o.id+'" '+(!ready||item.claimed?'disabled':'')+'>'+(item.claimed?'Recompensa recebida':'Resgatar recompensa')+'</button></div>';}).join('')+'</div><p class="scope-label">A rodada começa ao concluir o tutorial e expira após 24 horas no relógio do dispositivo. Ao voltar após a expiração, começa uma nova rodada. Abrir a tela não muda as metas. Resgate antes que a rodada expire.</p>';
 return html+closePage();
};
function upgradesPage(){
 return pageHead('Melhorias da empresa','Investimentos permanentes na campanha. Compare o efeito, o nível e o custo antes de comprar.')+'<div class="grid">'+Object.keys(UPGRADE_NAMES).map(key=>'<div class="card"><span class="tag">NÍVEL '+s.upgrades[key]+' / 5</span><h3>'+UPGRADE_NAMES[key]+'</h3><p>'+UPGRADE_HELP[key]+'</p><div class="bar"><i style="width:'+(s.upgrades[key]*20)+'%"></i></div><p class="scope-label">'+(['roteiro','filmagem','edicao','marketing'].includes(key)?'Cada nível acrescenta R$ 700 à manutenção base, ajustada pela dificuldade.':'Esta melhoria não acrescenta manutenção semanal.')+'</p><button class="secondary fullwidth" data-upgrade="'+key+'" '+(s.upgrades[key]>=5?'disabled':'')+'>'+(s.upgrades[key]>=5?'Nível máximo':'Melhorar · '+money(upgradeCost(key)))+'</button></div>').join('')+'</div>'+kpis([['Vagas na equipe',rosterCapacity()],['Obras simultâneas',capacity()],['Manutenção da produtora',money(studioOverhead())],['Nível da empresa',s.level]])+closePage();
}
company=function(){
 if(subpage==='upgrades')return upgradesPage();
 const m=metricTotals(),f=s.finance,broadcasts=s.shows.flatMap(sh=>sh.episodes.filter(ep=>ep.status==='aired').map(ep=>({sh,ep}))),avgCritics=broadcasts.length?Math.round(broadcasts.reduce((v,x)=>v+x.ep.critics,0)/broadcasts.length):null;
 const balances=s.history.slice(-12),max=Math.max(1,...balances.map(x=>Math.abs(x.cash)));
 return pageHead('Empresa: desempenho e histórico','Acompanhe caixa, todas as receitas e despesas do beta, catálogo, equipe, público e exibições.','Semana '+s.week)+
 kpis([['Caixa',money(s.cash)],['Entradas acumuladas',money(f.income)],['Saídas acumuladas',money(f.expenses)],['Resultado de caixa',money(f.income-f.expenses)]])+
 '<p class="scope-label">Conciliação: saldo inicial '+money(f.opening)+' + entradas '+money(f.income)+' − saídas '+money(f.expenses)+' = '+money(s.cash)+'. Entradas incluem financiamentos, objetivos e prêmios; veja as categorias para separar o faturamento das obras.'+(f.partial?' Campanha anterior: a contabilidade completa começa na semana '+f.sinceWeek+'; o caixa e as exibições antigas foram preservados.':'')+'</p>'+
 kpis([['Obras criadas',s.shows.length],['Exibições inéditas',m.air],['Visualizações acumuladas',compact(m.views)],['Crítica média',fmtScore(avgCritics)],['Gostei',compact(m.likes)],['Favoritos',compact(m.favorites)],['Fãs conquistados',compact(s.fans)],['Prêmios',s.awards.wins]])+
 '<div class="beta-grid"><div class="card"><h3>Receitas e despesas por categoria</h3><div class="rows">'+Object.entries(f.byCategory).map(([name,amount])=>'<div class="between"><b>'+esc(name)+'</b><span class="'+(amount>=0?'good':'bad')+'">'+(amount>=0?'+':'−')+money(Math.abs(amount))+'</span></div>').join('')+(Object.keys(f.byCategory).length?'':'<p>Sem movimentos no beta.</p>')+'</div></div><div class="card"><h3>Evolução do caixa</h3><p>Últimas '+balances.length+' semanas registradas.</p><div style="display:flex;align-items:end;gap:6px;height:130px">'+balances.map(x=>'<div style="flex:1;min-width:0;background:'+(x.cash<0?'#de7686':'#74d6c3')+';height:'+Math.max(3,Math.abs(x.cash)/max*100)+'%;border-radius:5px" title="Semana '+x.week+': '+money(x.cash)+'"></div>').join('')+'</div><p class="scope-label">Barras mostram o valor absoluto do saldo; vermelho indica caixa negativo. O registro abaixo conserva os valores.</p>'+kpis([['Equipe / semana',money(hiredCost())],['Custos fixos previstos',money(hiredCost()+overhead())]])+'</div></div>'+
 '<div class="card" style="margin-top:18px"><h3>Registro financeiro</h3><p class="scope-label">Os totais acumulados conservam todos os movimentos. A tabela mostra os últimos 1.000 para manter a navegação leve.</p><div class="beta-table"><table class="table"><thead><tr><th>Semana</th><th>Categoria</th><th>Movimento</th><th>Valor</th></tr></thead><tbody>'+s.ledger.map(x=>'<tr><td>'+x.week+'</td><td>'+esc(x.category)+'</td><td>'+esc(x.label)+'</td><td class="'+(x.amount>=0?'good':'bad')+'">'+money(x.amount)+'</td></tr>').join('')+'</tbody></table></div>'+
 (s.ledgerPrior?.length?'<details><summary>Movimentos conhecidos da versão anterior</summary><p class="scope-label">Registros importados; a versão anterior não conservava o histórico financeiro inteiro.</p><div class="beta-table"><table class="table"><tbody>'+s.ledgerPrior.map(x=>'<tr><td>'+x.week+'</td><td>'+esc(x.label)+'</td><td>'+money(x.amount)+'</td></tr>').join('')+'</tbody></table></div></details>':'')+'</div>'+
 '<div class="card" style="margin-top:18px"><h3>Histórico completo das exibições</h3><div class="beta-table"><table class="table"><thead><tr><th>Semana</th><th>Obra / produção</th><th>Emissora</th><th>Visualizações</th><th>Público / crítica</th><th>Receita</th></tr></thead><tbody>'+broadcasts.sort((a,b)=>b.ep.airWeek-a.ep.airWeek).map(x=>'<tr><td>'+x.ep.airWeek+'</td><td>'+esc(x.sh.name)+' · '+unitLabel(x.sh,x.ep)+'</td><td>'+esc(x.ep.distribution?.networkName||networkBy(x.sh.networkId)?.name||'Não registrada')+'</td><td>'+compact(x.ep.viewership)+'</td><td>'+x.ep.viewers+' / '+x.ep.critics+'</td><td>'+(Number.isFinite(x.ep.revenue)?money(x.ep.revenue):'Não registrada')+'</td></tr>').join('')+'</tbody></table></div></div>'+closePage();
};
function socialPage(){
 const posts=s.social.posts.filter(p=>p.platform===socialNetwork),names={tuiter:'Tuiter',istagram:'Istagram',facibuk:'Facibuk'},most=s.shows.filter(sh=>sh.totalViewers>0).sort((a,b)=>b.totalViewers-a.totalViewers);
 return pageHead(names[socialNetwork],'Uma comunidade fictícia comenta suas estreias, equipe e escolhas. A conversa cresce com o público da obra.',posts.length+' destaques recentes')+'<div class="chip-row">'+Object.entries(names).map(([id,name])=>'<button class="filter-chip '+(id===socialNetwork?'active':'')+'" data-social-network="'+id+'">'+name+'</button>').join('')+'</div><div class="social-layout"><div>'+posts.slice(0,100).map(p=>'<article class="social-post '+(p.replyTo?'reply':'')+'"><div class="between"><b>@'+esc(p.user)+'</b>'+pill(p.voice,'cyan')+'</div><p>'+esc(p.text)+'</p><div class="post-meta"><span>Semana '+p.week+'</span><span>♡ '+compact(p.likes)+'</span>'+(p.showId?'<button class="mutedbutton" data-social-report="'+p.showId+'">Ver análise da obra</button>':'<span>Conversa do mercado</span>')+'</div></article>').join('')+(posts.length?'':'<div class="empty">As conversas sobre sua produtora começam nas estreias. Avance a semana para acompanhar também o mercado.</div>')+'</div><aside class="card"><h3>Obras em evidência</h3>'+most.slice(0,5).map(sh=>'<div class="world-item"><b>'+esc(sh.name)+'</b><p>'+compact(sh.totalViewers)+' visualizações · '+compact(sh.fanBase)+' fãs da obra.</p></div>').join('')+'<p class="scope-label">Jovens, adultos e senhores têm vozes diferentes. Os comentários usam fatos registrados na exibição, sem inventar cenas. No modo Real diretor, há respostas e menções. Cada texto publicado é verificado para evitar repetição na campanha.</p></aside></div>'+closePage();
}
function journalPage(){
 return pageHead('Jornal da Tela','Estreias, contratos, audiência, premiações e mudanças no mercado do Empire TV.')+'<div class="paper-head"><span class="eyebrow">EDIÇÃO '+s.week+' · MERCADO & CULTURA</span><h2>Jornal da Tela</h2><p>Histórias de um universo em movimento.</p></div><div class="rows">'+s.news.slice(0,80).map(n=>'<article class="news-card"><span class="tag">'+esc(n.topic)+' · SEMANA '+n.week+'</span><h3>'+esc(n.title)+'</h3><p>'+esc(n.text)+'</p>'+(n.showId?'<button class="mutedbutton" data-social-report="'+n.showId+'">Abrir obra e resultados →</button>':'')+'</article>').join('')+(s.news.length?'':'<div class="empty">Desenvolva uma obra ou avance a semana para começar o noticiário.</div>')+'</div>'+closePage();
}
function awardsPage(){
 if(subpage==='journal')return journalPage();const cycle=Math.floor(s.week/12)+1,next=cycle*12;
 return pageHead('Prêmios de cinema e televisão','Oscar do Império e Coroa de Ouro TV: premiações simuladas do universo do jogo.','Próxima gala: semana '+next)+
 kpis([['Prêmios conquistados',s.awards.wins],['Indicações',s.awards.nominations],['Edições registradas',s.awards.history.length],['Semanas até a gala',next-s.week]])+
 '<div class="story-note">A cada 12 semanas simuladas, as obras inéditas do período disputam com as outras produtoras. Inscrição automática, sem taxa. A fama traz público, mas a criatividade e a execução orientam o júri. Os valores são depositados uma única vez por categoria e edição.</div><div class="grid" style="margin-top:18px">'+AWARD_CATEGORIES.map(c=>'<article class="card"><div class="award-icon">♛</div><span class="tag">'+esc(c.event)+'</span><h3>'+esc(c.name)+'</h3><p>Prêmio de '+money(c.cash)+'</p><p class="scope-label">'+esc(({quality:'Qualidade 70% e crítica 30%.',story:'Média ponderada de premissa, motivação, conflito, consequência, desenvolvimento e criatividade.',direction:'Qualidade 80% e técnica da direção 20%.',acting:'Recepção do público 65% e técnica do ator 35%.',voice:'Qualidade 65% e técnica de dublagem 35%.',public:'Nota do público 80% e alcance até 20 pontos.'})[c.mode])+'</p></article>').join('')+'</div><h3 style="margin-top:25px">Histórico de premiações</h3><div class="rows">'+s.awards.history.map(h=>'<details><summary>Edição '+h.cycle+' · semana '+h.week+'</summary><p class="scope-label">Obras exibidas da semana '+h.start+' até '+h.end+'.</p>'+h.results.map(r=>'<div class="world-item"><b>'+esc(r.category)+': '+esc(r.winner.title)+'</b><p>'+esc(r.winner.studio)+' · júri '+r.winner.score+'/100'+(r.winner.player?' · '+money(r.reward)+' recebidos':'')+'</p><p class="scope-label">Indicados: '+r.nominees.map(n=>esc(n.title)+' ('+n.score+')').join(', ')+'.</p></div>').join('')+'</details>').join('')+(s.awards.history.length?'':'<div class="empty">Exiba uma produção para disputar as próximas premiações.</div>')+'</div>'+closePage();
}
function helpPage(){return pageHead('Como dirigir sua campanha','Cada ação mostra o custo e o efeito antes de você confirmar.')+'<div class="rows">'+[
 ['1. Escolha a dificuldade','Fácil começa com R$ 1 milhão e cinco de cada powerup; avaliações artificiais e custos menores. Médio tem R$ 800 mil e dois de cada. Difícil tem R$ 500 mil e um aleatório. Real diretor começa com zero, sem powerups: desenvolva um conceito gratuito e obtenha financiamento por mini roteiro.'],
 ['2. Escreva uma ideia concreta','Na página Obras, descreva a premissa, a motivação, o conflito, a consequência e a intenção. Repetir palavras não ajuda. A avaliação simulada considera os sinais que você escreve; não julga uma cena que não foi descrita.'],
 ['3. Organize a equipe','Contratar custa duas semanas de salário; depois há folha semanal. Cargos diferentes da formação usam 60% da técnica. Especialidades dão +12 de técnica, até 100. A fama amplia alcance e aparece nas conversas. Cada obra pode ter responsáveis específicos.'],
 ['4. Negocie a distribuição','Consulte as exigências das 40 redes. Propostas excelentes recebem vantagem mesmo sem fama. Recusas explicam o motivo; revise o argumento ou busque outra rede. As propostas da mesma versão não são sorteadas de novo na mesma semana.'],
 ['5. Produza e avance a semana','O orçamento escolhido é o equivalente a 45 minutos: um filme de 90 minutos dobra a filmagem. Divulgação é adicionada uma vez. Confira a estimativa, escreva a intenção da gravação e escolha as decisões. O dinheiro da produção sai na gravação; a estreia e os custos fixos ocorrem ao avançar a semana.'],
 ['6. Leia o resultado','Visualizações são a contagem simulada da exibição; público e crítica são notas de 0 a 100. Gostei e favoritos são contagens. O relatório registra equipe, custos e decisões da gravação. A narrativa tem o maior peso: um orçamento pequeno não condena uma ideia bem desenvolvida.'],
 ['7. Continue ou encontre outra casa','Depois de seis episódios, tente renovar a série. Se a rede recusar, apresente a próxima temporada a outra emissora. Obras finalizadas podem gerar continuações numeradas, com novo desenvolvimento e contrato.'],
 ['8. Administre sua emissora','Abra TV ou streaming, escolha política comercial, configure a grade e compre licenças. Streaming cobra ¼ da mensalidade por semana e registra novos assinantes e saídas. Pausar interrompe estreias, mas mantém custo de R$ 1.800 por semana.'],
 ['9. Objetivos e prêmios','Os primeiros objetivos pagam automaticamente. Depois, seis objetivos ficam ativos durante 24 horas reais; resgate antes de expirarem. Há 144 desafios diários. Premiações acontecem a cada 12 semanas do jogo; resultados e dinheiro ficam registrados.'],
 ['10. Proteja sua campanha','A conta local salva no aparelho, protegida pela senha. Exporte um backup antes de trocar o APK ou o celular. Nas configurações, novas campanhas arquivam a atual; você pode retomar até oito campanhas anteriores.']
 ].map(x=>'<div class="card"><h3>'+x[0]+'</h3><p>'+x[1]+'</p></div>').join('')+'</div>'+closePage();}
settings=function(){
 if(subpage==='help')return helpPage();
 return pageHead('Configurações','Conta, backups e campanhas.','Empire TV '+BETA_VERSION)+'<div class="rows"><div class="card"><h3>@'+esc(account.username)+'</h3><p>'+(account.type==='cloud'?'Conta online · sincronização '+(syncStatus==='cloud'?'ativa':'pendente')+'.':'Conta local · progresso protegido pela senha neste dispositivo.')+'</p><div class="btnrow">'+(account.type==='cloud'?'<button class="secondary" data-sync>Sincronizar progresso</button>':'')+'<button class="ghost" data-logout>Sair da conta</button></div></div><div class="card"><h3>Backup e restauração</h3><p>Guarde uma cópia antes de trocar de aparelho ou instalar outro APK. O arquivo exportado contém a campanha e os arquivos das campanhas anteriores.</p><div class="btnrow"><button class="primary" data-export>Exportar progresso</button><label class="secondary" style="cursor:pointer">Importar backup<input type="file" id="importSave" accept=".json,application/json" style="display:none"></label></div><p class="scope-label">O backup exportado é um JSON legível. Guarde em local privado. A importação substitui a campanha desta conta.</p></div><div class="card"><h3>Nova campanha</h3><p>A campanha atual fica arquivada. Escolha outra dificuldade e comece com uma nova produtora. A conta e os outros perfis permanecem.</p><button class="primary" data-reset>Começar nova campanha</button></div><div class="card"><h3>Campanhas arquivadas</h3><div class="rows">'+s.campaignArchive.map(c=>'<div class="between wrap"><div><b>'+esc(c.name)+'</b><p>'+(DIFFICULTIES[c.difficulty]?.name||'Médio')+' · semana '+c.week+' · '+money(c.cash)+'</p></div><button class="secondary" data-resume="'+esc(c.campaignId)+'">Retomar</button></div>').join('')+(s.campaignArchive.length?'':'<p>Nenhuma campanha arquivada.</p>')+'</div><p class="scope-label">Até oito campanhas anteriores. Quando o limite é excedido, a mais antiga sai da lista; exporte para conservar mais.</p></div>'+
 (getOldSave()?'<div class="card"><h3>Progresso antigo neste aparelho</h3><p>Importe o progresso anterior para esta conta. Exporte antes se quiser guardar a campanha atual.</p><button class="secondary" data-legacy>Importar progresso antigo</button></div>':'')+'<div class="card"><h3>Empire TV · V&amp;D Digital</h3><p>Produza séries e filmes, descubra talentos e construa seu lugar no mercado.</p><button class="secondary" data-subpage="help">Ler como jogar</button></div></div>'+closePage();
};
home=function(){
 const active=s.shows.filter(sh=>sh.status==='active'),pending=s.shows.flatMap(sh=>sh.episodes.filter(ep=>ep.status==='produced')),recent=s.shows.slice().sort((a,b)=>b.totalViewers-a.totalViewers).slice(0,3),next=s.daily.active?s.daily.tasks.filter(x=>!x.claimed).length:objectiveDefs.filter(o=>!s.claimed.includes(o.id)).length;
 return'<div class="hero-layout"><div class="banner"><span class="eyebrow">EMPIRE TV · SUA HISTÓRIA ESTÁ NO AR</span><h2>Uma boa ideia pode conquistar a tela.</h2><p>Escreva uma obra, monte a equipe e escolha onde lançar. As decisões criativas movem a recepção; os contratos sustentam a produtora.</p><div class="btnrow">'+jump('Desenvolver série ou filme','shows','primary')+jump('Produzir','production')+'</div></div><div class="hero-mini"><span class="eyebrow">CAMPANHA '+esc(policy().name.toUpperCase())+'</span><h3>'+esc(s.name)+'</h3><p>'+ (s.difficulty==='director'&&!s.grantTaken?'Crie um conceito gratuito e apresente um mini roteiro para obter verba.':esc(policy().desc))+'</p>'+pill('Semana '+s.week,'green')+'</div></div>'+
 kpis([['Obras no ar',active.length,capacity()+' vagas simultâneas'],['Aguardando estreia',pending.length,'Avance a semana'],['Equipe contratada',s.hired.length,rosterCapacity()+' vagas'],['Fãs da produtora',compact(s.fans),'Reputação '+Math.round(s.reputation)+'/100']])+
 '<div class="beta-grid"><div class="card"><h3>Próximos passos</h3><div class="rows"><div class="between"><span>'+next+' objetivos disponíveis</span>'+jump('Objetivos','goals')+'</div><div class="between"><span>'+s.networks.length+' emissoras próprias</span>'+jump('Emissoras','networks')+'</div><div class="between"><span>'+s.awards.wins+' prêmios conquistados</span>'+jump('Prêmios','awards')+'</div></div></div><div class="card"><h3>Notícias da produtora</h3>'+s.news.slice(0,3).map(n=>'<div class="world-item"><span class="tag">'+esc(n.topic)+' · SEMANA '+n.week+'</span><b style="display:block">'+esc(n.title)+'</b><p>'+esc(n.text)+'</p></div>').join('')+(s.news.length?'':'<p>Sua primeira obra abre o noticiário.</p>')+'</div></div>'+
 '<section class="section"><h3>Seu catálogo em evidência</h3><div class="grid">'+recent.map(sh=>'<div class="card"><h3>'+esc(sh.name)+'</h3><p>'+showStatus(sh)+' · '+compact(sh.totalViewers)+' visualizações</p><button class="secondary" data-social-report="'+sh.id+'">Abrir obra</button></div>').join('')+(recent.length?'':'<div class="empty">Comece pelo conceito e pela intenção criativa.</div>')+'</div></section>';
};
const betaReportBase=episodeReport;
episodeReport=function(sh,ep){
 let html=betaReportBase(sh,ep);const detail='<details><summary>Equipe, fama e cálculo do alcance</summary><div class="beta-table"><table class="table"><thead><tr><th>Função</th><th>Profissional</th><th>Técnica</th><th>Fama</th></tr></thead><tbody>'+(ep.credits||[]).map(c=>'<tr><td>'+esc(c.role)+'</td><td><b class="accent">'+esc(c.name)+'</b></td><td>'+c.technique+'</td><td>'+c.fame+'</td></tr>').join('')+'</tbody></table></div><p>'+esc(ep.distribution?.networkName||'Emissora não registrada')+' · fama da equipe ×'+(ep.distribution?.starMultiplier||1).toFixed(2)+' · marketing ×'+(ep.distribution?.marketingMultiplier||1).toFixed(2)+' · concorrência ×'+(ep.distribution?.competition||1).toFixed(2)+'.</p><p>'+esc(ep.distribution?.revenuePolicy||'Política anterior à versão beta.')+'</p><p class="scope-label">Créditos, especialidades e fama são uma fotografia da gravação. Dispensar ou mudar o cargo depois não altera este relatório.</p></details>';
 html=html.replace('</article>',detail+'</article>').replace('Receita parceira: licença contratada, com bônus de 16% para nota dos fãs ≥75. Rede própria: publicidade proporcional ao alcance.','Receita parceira: licença contratada com bônus de 16% para nota dos fãs ≥75. Na rede própria, confira a política comercial registrada no bloco Equipe, fama e cálculo do alcance.');
 return html;
};
endPage=function(){
 const e=currentEnd;return pageHead('Fechamento da semana '+s.week,'Confira o que mudou no caixa e na recepção das obras.')+kpis([['Caixa inicial da semana',money(e?.startCash||0)],['Caixa atual',money(s.cash)],['Variação do caixa',money(e?.net||0)],['Custos fixos e divulgação',money(e?.expense||0)]])+'<p class="scope-label">A variação inclui todas as receitas e despesas deste avanço: exibições, assinaturas, operação, recompensas e prêmios. A produção foi paga na gravação.</p><div class="rows">'+(e?.networkReports||[]).map((n,i)=>'<div class="card"><h3>'+esc(n.name||s.networks[i]?.name||'Emissora')+'</h3><p>'+compact(n.views)+' visualizações · receita '+money(n.revenue)+' · despesas '+money(n.expenses)+' · resultado '+money(n.profit)+'.</p></div>').join('')+(e?.reports||[]).map(r=>{const sh=showBy(r.showId),ep=sh?.episodes.find(ep=>ep.id===r.episodeId);return sh&&ep?episodeReport(sh,ep):'';}).join('')+(!e?.reports.length?'<div class="info">Nenhuma produção inédita estreou. Consulte a sala de produção e a situação da grade.</div>':'')+'</div><div class="btnrow">'+jump('Voltar ao estúdio','home','primary')+jump('Todos os relatórios','reports')+'</div>'+closePage();
};
const betaIntroBase=intro,betaAuthBase=authPage;
intro=function(){return betaIntroBase().replace(/<span class="tvicon">[^<]*<\/span>/g,'<div class="beta-logo">'+TV_LOGO+'</div>').replace('IMPÉRIO DA TV','EMPIRE TV').replace('Carreira de diretor · 3.0','Cinema e televisão · Beta').replace('Estúdio Prime','Meu Estúdio')+rightsFooter();};
authPage=function(){return betaAuthBase().replace(/<div class="tvicon">[^<]*<\/div>/g,'<div class="beta-logo">'+TV_LOGO+'</div>').replace('IMPÉRIO DA TV','EMPIRE TV').replace('PREMIUM STUDIO · v2.0','V&amp;D DIGITAL · BETA').replace('V&D DIGITAL · v2.0','V&amp;D DIGITAL · BETA').replace('Produza séries, negocie','Produza séries e filmes, negocie').replace('<div>Jogo independente · Sem anúncios · Desenvolvido para Android</div>','')+rightsFooter();};
function updateBetaTimers(){
 const m=root.querySelector('[data-market-timer]'),d=root.querySelector('[data-daily-timer]'),remaining=300-Math.floor(Date.now()/1000)%300;
 if(m)m.textContent='Renova em '+Math.floor(remaining/60)+':'+String(remaining%60).padStart(2,'0');
 if(d){const seconds=Math.max(0,Math.floor((s.daily.expiresAt-Math.max(Date.now(),s.daily.lastNow))/1000));d.textContent='Troca em '+Math.floor(seconds/3600)+'h '+Math.floor(seconds%3600/60)+'min';}
}
render=function(){
 if(!account){root.innerHTML=authPage();return;}
 if(!s||campaignSetup){menuOpen=false;root.innerHTML=intro();return;}
 migrateBeta(s);const rolled=ensureDaily();if(rolled)save();
 const sections={home,shows,production,team,networks:networksPage,goals:goalsPage,company,social:socialPage,awards:awardsPage,end:endPage,reports:reportsPage,settings};
 if(!sections[tab])tab='home';
 root.innerHTML='<div class="app">'+betaHeader()+kpis([['Caixa da produtora',money(s.cash)],['Semana do jogo',s.week],['Fãs',compact(s.fans)],['Nível / reputação',s.level+' / '+Math.round(s.reputation)]])+'<div class="beta-topbar"><p class="small">'+esc(NAV_ITEMS.find(x=>x[0]===tab)?.[2]||'Fechamento')+' · Campanha '+esc(policy().name)+'</p><button class="primary" data-next-week>Avançar semana →</button></div>'+sections[tab]()+pageSubnav()+rightsFooter()+'</div>';
 updateBetaTimers();
};

/* Empire TV 1.0.0.1 BETA — campaign mechanics; purchased currency is disabled. */
const EMPIRE_VERSION='1.0.0.1 BETA';
const BASE_NETWORK_META=networks.map(n=>({...n,focus:n.focus.slice()}));
let chosenShow=null,chosenReport=null,workPanel='overview',reportPanel='overview',aiBusy=false;
const MF_PRICES={agency:8,mission:3};
const MF_EXCHANGES=[{mf:5,cash:10000},{mf:20,cash:45000},{mf:50,cash:120000}];
const MF_PACKS=[{id:'starter',mf:60,name:'Primeira estrela'},{id:'studio',mf:180,name:'Estúdio em ascensão'},{id:'empire',mf:450,name:'Império da fama'}];
function walletKey(){return 'empire-mf-'+(account?.id||'guest');}
function savedWallet(){try{return JSON.parse(localStorage.getItem(walletKey())||'null');}catch{return null;}}
function validWallet(w){return w&&Number.isSafeInteger(w.balance)&&w.balance>=0&&Array.isArray(w.ledger)&&w.rewarded&&typeof w.rewarded==='object';}
function persistWallet(){try{localStorage.setItem(walletKey(),JSON.stringify(s.fameWallet));}catch{}}
function migrateFinal(state){
 if(!state)return state;migrateBeta(state);
 if(!validWallet(state.fameWallet)){const cached=savedWallet();state.fameWallet=validWallet(cached)?cached:{balance:25,ledger:[{id:'welcome',amount:25,label:'Boas-vindas ao Empire TV',at:Date.now()}],rewarded:{welcome:true},serial:1};}
 state.schema=5;state.build=EMPIRE_VERSION;
 state.agency=state.agency||{ticket:0,nextAt:Math.floor(Date.now()/300000)*300000+300000,baseEpoch:Math.floor(Date.now()/300000)};
 state.agency.baseEpoch=Number.isSafeInteger(state.agency.baseEpoch)?state.agency.baseEpoch:Math.floor(Date.now()/300000);
 state.vant=state.vant||{index:0,touring:!objectiveDefs.every(o=>state.claimed.includes(o.id)),completed:false,collapsed:false};
 state.market=state.market||{lastWeek:0,networks:{},history:[]};
 state.live=state.live||{lastLocalAt:Date.now(),lastSyncAt:0,serverCursor:0,importedWorks:[],mode:'local',error:'',worldSerial:0};
 state.shows.forEach(sh=>{sh.aiConcept=sh.aiConcept||null;sh.aiPrepared=sh.aiPrepared||null;sh.episodes.forEach(ep=>{if(ep.status==='produced'&&!ep.production)ep.production={weeks:Math.max(1,Math.min(6,ep.airWeek-ep.producedWeek)),startedWeek:ep.producedWeek,releaseWeek:ep.airWeek,legacy:true};});});
 applyNetworkState(state);
 return state;
}
function applyNetworkState(state){
 BASE_NETWORK_META.forEach(base=>{const n=networks.find(n=>n.id===base.id),saved=state.market.networks[base.id];Object.assign(n,base,saved||{});n.focus=base.focus.slice();});
}
const finalFreshBase=fresh;
fresh=function(name,difficulty){BASE_NETWORK_META.forEach(base=>Object.assign(networks.find(n=>n.id===base.id),base));return migrateFinal(finalFreshBase(name,difficulty));};
const finalStartBase=startGame,finalResumeBase=resumeCampaign;
startGame=function(name,difficulty){const wallet=s?.fameWallet?JSON.parse(JSON.stringify(s.fameWallet)):savedWallet();finalStartBase(name,difficulty);if(!s)return;migrateFinal(s);if(validWallet(wallet))s.fameWallet=wallet;persistWallet();chosenShow=null;chosenReport=null;subpage='';save();render();};
resumeCampaign=function(cid){const wallet=JSON.parse(JSON.stringify(s.fameWallet));finalResumeBase(cid);migrateFinal(s);s.fameWallet=wallet;persistWallet();chosenShow=null;chosenReport=null;subpage='';save();render();};
function walletChange(amount,label,receipt){
 if(!Number.isSafeInteger(amount)||!amount)return false;
 migrateFinal(s);if(receipt&&s.fameWallet.rewarded[receipt])return false;
 if(s.fameWallet.balance+amount<0)return false;
 s.fameWallet.balance+=amount;s.fameWallet.serial=(s.fameWallet.serial||0)+1;
 s.fameWallet.ledger.unshift({id:s.fameWallet.serial,amount,label,at:Date.now(),receipt:receipt||null});s.fameWallet.ledger=s.fameWallet.ledger.slice(0,500);
 if(receipt)s.fameWallet.rewarded[receipt]=true;persistWallet();return true;
}
function mfSpend(cost,label){if(!Number.isSafeInteger(cost)||cost<=0)return false;if(!walletChange(-cost,label))return notice('Você precisa de '+cost+' MF para esta ação.',true),false;return true;}
function exchangeMF(index){if(s.difficulty==='director'&&!s.grantTaken)return notice('No Real diretor, obtenha o primeiro financiamento antes de trocar MF por verba.',true);const offer=MF_EXCHANGES[Number(index)];if(!offer||!mfSpend(offer.mf,'Troca por '+money(offer.cash)))return;changeCash(offer.cash,'Troca de Moeda da Fama','Moeda da Fama');update();notice(money(offer.cash)+' adicionados ao caixa da produtora.');}
function mfPowerup(key){if(!POWERUPS.includes(key)||s.difficulty==='director')return notice('Real diretor não usa powerups.',true);if(!mfSpend(6,'Powerup: '+key))return;s.boosts[key]++;update();notice('Powerup adicionado ao inventário.');}
const finalMarketEpochBase=marketEpoch;
marketEpoch=function(now=Date.now()){
 if(!s?.agency)return finalMarketEpochBase(now);
 if(now>=s.agency.nextAt){const steps=Math.floor((now-s.agency.nextAt)/300000)+1;s.agency.nextAt+=steps*300000;s.agency.baseEpoch+=steps;}
 return s.agency.baseEpoch+(s.agency.ticket||0)*1000003;
};
function refreshAgency(){if(!mfSpend(MF_PRICES.agency,'Renovação imediata da agência'))return;s.agency.ticket++;s.agency.nextAt=Date.now()+300000;marketCache=null;update();notice('Nova rodada: quatro candidatos por profissão.');}
const finalDailyValueBase=dailyValue;
dailyValue=function(o){
 const task=s.daily.tasks?.find(t=>t.id===o.id);
 if(!task?.baseline)return finalDailyValueBase(o);
 if(o.metric==='genres'){const before=new Set(task.genres||[]);return new Set(s.shows.flatMap(sh=>sh.episodes.some(e=>e.status==='aired'&&e.airWeek>=task.fromWeek)?[sh.genre]:[]).filter(g=>!before.has(g))).size;}
 return Math.max(0,(metricTotals()[o.metric]||0)-(task.baseline[o.metric]||0));
};
function rerollMission(oid){
 ensureDaily();const task=s.daily.tasks.find(t=>t.id===oid),old=DAILY_OBJECTIVES.find(o=>o.id===oid);
 if(!task||task.claimed||!old||dailyValue(old)>=old.goal)return notice('Somente missões diárias em andamento podem ser trocadas.',true);
 const others=new Set(s.daily.tasks.map(t=>t.id)),pool=DAILY_OBJECTIVES.filter(o=>o.tier===old.tier&&!others.has(o.id)&&dailyEligible(o));
 if(!pool.length)return notice('Nenhuma missão equivalente está disponível.',true);
 if(!mfSpend(MF_PRICES.mission,'Troca de missão diária'))return;
 const serial=(s.daily.rerolls||0)+1;s.daily.rerolls=serial;
 const rng=seeded(s.campaignId+'mission'+s.daily.cycle+serial),replacement=pick(rng,pool);
 Object.assign(task,{id:replacement.id,claimed:false,baseline:metricTotals(),genres:[...new Set(s.shows.filter(sh=>sh.episodes.some(e=>e.status==='aired')).map(sh=>sh.genre))],fromWeek:s.week+1,rerolls:(task.rerolls||0)+1});
 update();notice('Nova missão de dificuldade equivalente. O progresso dela começa agora.');
}
const finalClaimDailyBase=claimDaily;
claimDaily=function(oid){const cycle=s.daily.cycle;finalClaimDailyBase(oid);const item=s.daily.tasks.find(t=>t.id===oid);if(item?.claimed&&walletChange(1,'Missão diária concluída',s.campaignId+':daily:'+cycle+':'+oid)){save();render();}};
function checkVant(){
 if(!s?.vant)return;
 const completed=objectiveDefs.every(o=>s.claimed.includes(o.id));
 if(completed&&!s.vant.completed){s.vant.completed=true;s.vant.touring=false;const granted=walletChange(30,'Tutorial de Vant concluído','vant-primary-complete');save();notice('Tutorial concluído! Vant continua disponível.'+(granted?' +30 MF.':' A recompensa em MF desta conta já foi recebida.'));}
}
function projectFingerprint(sh,script='',intent=sh.intent){return String(hashText(JSON.stringify({title:sh.name,kind:sh.kind,genre:sh.genre,duration:sh.duration,concept:sh.concept,story:sh.story,intent,script})));}
function currentConceptAI(sh){return sh.aiConcept?.fingerprint===projectFingerprint(sh)?sh.aiConcept:null;}
function aiNarrative(review){const q=review?.scores;if(!q)return null;return Math.round(q.originality*.28+q.coherence*.27+q.characters*.2+q.impact*.25);}
const finalPlotBase=plotFactors;
plotFactors=function(sh,script=''){
 const fs=finalPlotBase(sh,script),review=currentConceptAI(sh);if(!review)return fs;
 const q=review.scores,byKey={premise:q.impact,motivation:q.characters,conflict:q.coherence,payoff:q.impact,causality:q.coherence,development:q.coherence,originality:q.originality};
 return fs.map(f=>{const risk=review.risks.find(r=>norm(r.aspect).includes(norm(f.label).split(' ')[0]));return {...f,score:byKey[f.key]??f.score,evidence:review.summary+(risk?' '+risk.evidence:''),advice:risk?.advice||review.strengths[0]||f.advice};});
};
const finalCreativeBase=creativeQuality;
creativeQuality=function(sh,ep){
 const review=ep.aiReview;if(!review)return finalCreativeBase(sh,ep);
 const narrative=aiNarrative(review),technical=weighted(ep.analysis.filter(f=>['budget','crew','voice'].includes(f.key)));
 return Math.round(clamp(narrative*.68+technical*.2+review.scores.execution*.12+(s.upgrades.roteiro||0)+(s.upgrades.edicao||0)+ep.qualityBoost,5,100));
};
function productionPlan(sh,script='',intent=sh.intent,review=null){
 const chars=[sh.concept,...Object.values(sh.story||{}),script,intent].join(' ').length;
 const complexity=Math.min(2,Math.floor(chars/1800));
 const length=sh.duration>=120?2:sh.duration>=60?1:0;
 const demanding=['Ficção científica','Fantasia','Animação'].includes(sh.genre)?1:0;
 const local=2+complexity+length+demanding;
 const proposed=review?.productionWeeks||local;
 const support=s.upgrades.edicao>=3&&s.upgrades.filmagem>=3?1:0;
 const weeks=clamp(Math.round(Math.max(local-1,proposed)-support),1,6);
 return{weeks,chars,startedWeek:s.week,releaseWeek:s.week+weeks,stages:['Pré-produção','Gravação','Montagem','Som e acabamento','Revisão final','Estreia'].slice(0,weeks),reason:'Duração '+sh.duration+' min, '+chars+' caracteres de desenvolvimento'+(demanding?', gênero com maior execução técnica':'')+(support?', equipe de estúdio reduz uma semana':'')+'.'};
}
const finalProduceBase=produce;
produce=function(fd){
 const sh=showBy(fd.get('showId'));if(!sh)return;
 const script=String(fd.get('script')||'').trim().slice(0,3500),intent=String(fd.get('intent')||sh.intent||'').trim().slice(0,1200);
 const prepared=sh.aiPrepared?.fingerprint===projectFingerprint(sh,script,intent)?sh.aiPrepared:null;
 const before=sh.episodes.length;finalProduceBase(fd);if(sh.episodes.length===before)return;
 const ep=sh.episodes.at(-1);ep.aiReview=prepared;ep.production=productionPlan(sh,script,intent,prepared);ep.airWeek=ep.production.releaseWeek;
 if(prepared){ep.analysis=ep.analysis.map(f=>{const score={premise:prepared.scores.impact,motivation:prepared.scores.characters,conflict:prepared.scores.coherence,payoff:prepared.scores.impact,causality:prepared.scores.coherence,development:prepared.scores.coherence,originality:prepared.scores.originality}[f.key];return score===undefined?f:{...f,score,evidence:prepared.summary,advice:prepared.risks.find(r=>norm(r.aspect).includes(norm(f.label).split(' ')[0]))?.advice||prepared.strengths[0]||f.advice};});ep.quality=creativeQuality(sh,ep);}
 log(sh.name+': produção de '+ep.production.weeks+' semana(s), estreia prevista para a semana '+ep.airWeek+'.');save();render();notice('Produção iniciada. Estreia prevista: semana '+ep.airWeek+'.');
};
const finalAirBase=airEpisode;
airEpisode=function(sh,ep){if(ep.status==='produced'&&s.week<ep.airWeek)return null;return finalAirBase(sh,ep);};
const finalPitchPreviewBase=pitchPreview;
pitchPreview=function(sh,n){
 const p=finalPitchPreviewBase(sh,n),own=s.networks.some(x=>x.id===n.id),penalty=s.difficulty==='easy'?0:s.difficulty==='medium'?7:s.difficulty==='hard'?12:15;
 const chance=own?100:Math.round(clamp(p.chance-penalty,2,98));
 return {...p,chance,why:p.why+' '+(currentConceptAI(sh)?'Parecer de IA aplicado.':'Parecer local aplicado.')+' '+(own?'': 'Rigor da campanha: −'+penalty+' pontos na chance.')};
};
function updateNetworkRanks(){
 if(s.market.lastWeek===s.week)return;
 const aggregate=networks.map(n=>{const rivals=s.world.filter(w=>w.networkId===n.id&&w.status==='active'),ours=s.shows.filter(sh=>sh.networkId===n.id).flatMap(sh=>sh.episodes.filter(ep=>ep.status==='aired'&&ep.airWeek===s.week)),all=rivals.map(w=>({views:w.viewers,quality:w.quality})).concat(ours.map(ep=>({views:ep.viewership,quality:ep.quality})));return{n,views:all.reduce((v,x)=>v+x.views,0),quality:all.length?all.reduce((v,x)=>v+x.quality,0)/all.length:45,count:all.length};});
 const max=Math.max(1,...aggregate.map(x=>x.views));
 aggregate.forEach(x=>x.score=Math.round(x.views/max*45+x.quality*.5+Math.min(5,x.count)));
 aggregate.sort((a,b)=>b.score-a.score||b.n.reach-a.n.reach);
 aggregate.forEach((x,i)=>{const base=BASE_NETWORK_META.find(n=>n.id===x.n.id),prior=s.market.networks[x.n.id],movement=prior?clamp((x.score-prior.score)/700,-.04,.04):0,reach=Math.round(clamp((prior?.reach||base.reach)*(1+movement),base.reach*.7,base.reach*1.5)*100)/100;const snapshot={rank:i+1,previousRank:prior?.rank||i+1,score:x.score,reach,threshold:Math.round(clamp(base.threshold+(reach/base.reach-1)*12,30,98)),weeklyViews:x.views,quality:Math.round(x.quality),delta:Math.round((reach-(prior?.reach||base.reach))*100)/100};s.market.networks[x.n.id]=snapshot;Object.assign(x.n,snapshot);});
 s.market.lastWeek=s.week;s.market.history.unshift({week:s.week,top:aggregate.slice(0,5).map(x=>({id:x.n.id,name:x.n.name,score:x.score,reach:x.n.reach}))});s.market.history=s.market.history.slice(0,100);
}
const LOCAL_WORLD_WORDS=[['A Cidade','O Arquivo','A Última','O Retrato','A Casa','Os Filhos','O Jardim','A Ponte','O Código','As Vozes'],['de Sal','do Amanhã','da Lua','das Marés','Sem Nome','de Outubro','dos Ecos','de Vidro','da Noite','do Norte']];
function addProceduralRival(){
 const serial=++s.live.worldSerial,rng=seeded(s.campaignId+'newworld'+serial),n=pick(rng,networks),genre=pick(rng,n.focus);
 let title=pick(rng,LOCAL_WORLD_WORDS[0])+' '+pick(rng,LOCAL_WORLD_WORDS[1]);
 if(s.world.some(w=>w.name===title))title+=': '+['Retorno','Segredo','Fronteira','Recomeço'][serial%4]+' '+serial;
 const weeks=2+Math.floor(rng()*5),quality=50+Math.floor(rng()*44),eligible=networks.filter(x=>x.threshold<=quality).sort((a,b)=>Number(b.focus.includes(genre))-Number(a.focus.includes(genre))||b.reach-a.reach),publisher=eligible[0]||n;
 s.world.push({id:'newworld'+s.campaignId+serial,name:title,kind:rng()>.55?'film':'series',genre,networkId:publisher.id,studio:pick(rng,WORLD_STUDIOS),quality,viewers:0,status:'production',season:1,episode:0,debutWeek:s.week+weeks,updatedWeek:s.week,history:[],productionWeeks:weeks,source:'procedural',premise:'Um novo projeto de '+genre+' anunciado por outra produtora.'});
 s.world=s.world.slice(-120);addNews('Nova produção no mercado',title+' começa uma produção de '+weeks+' semanas em '+publisher.name+'.','Mercado');
}
const finalAdvanceWorldBase=advanceWorld;
advanceWorld=function(){
 const pending=s.world.filter(w=>w.status==='production');s.world=s.world.filter(w=>w.status!=='production');finalAdvanceWorldBase();s.world=s.world.concat(pending);
 for(const w of pending)if(w.debutWeek<=s.week){w.status='active';w.episode=1;w.viewers=Math.round((200000+w.quality*8500)*networkBy(w.networkId).reach);addNews('Estreia concorrente',w.name+' estreou em '+networkBy(w.networkId).name+'.','Mercado');}
 if(s.week%3===0)addProceduralRival();
};
const finalAwardsBase=runAwards;
runAwards=function(){const all=s.world;s.world=all.filter(w=>w.status==='active'&&w.debutWeek<=s.week);try{return finalAwardsBase();}finally{s.world=all;}};
const finalNextWeekBase=nextWeek;
nextWeek=function(){if(aiBusy)return notice('Aguarde o parecer em andamento.',true);const before=s.week;finalNextWeekBase();if(s.week===before)return;updateNetworkRanks();checkVant();save();render();queueUniverseSync();};
const finalCommentBase=commentThread;
commentThread=function(sh,ep,fs,rng){
 const narrative=fs.filter(f=>f.key==='conflict'||f.key==='payoff'||f.key==='originality'),comments=[];
 const reviews=ep.aiReview?.comments||[],lead=ep.actorName||'o elenco',detail=shortText(sh.story.conflict,145),consequence=shortText(sh.story.payoff,145),strong=ep.viewers>=80;
 const opinions=strong?[
 ['Jovem','EU FIQUEI EM PÉ NO FINAL. '+sh.name+' me ganhou pela ideia de '+shortText(sh.concept,100)+'.'],
 ['Adulto','O conflito de '+sh.name+' funciona porque existe um custo para a escolha: '+detail],
 ['Senhor','Assisti a '+sh.name+' com calma. Gostei de como o projeto coloca a decisão do personagem antes do espetáculo. '+consequence],
 ['Jovem','CARACA, '+lead+' em '+sh.name+'! Entrei pelo elenco e fiquei pela história. Já tô indicando.'],
 ['Adulto','A equipe encontrou uma identidade nesta produção: '+shortText(ep.intent||sh.intent,150)+'.'],
 ['Senhor','Não vejo motivo para esconder meu entusiasmo com '+sh.name+'. Esta proposta de '+sh.genre+' tem personalidade.']
 ]:[
 ['Jovem','Queria MUITO gostar de '+sh.name+', mas travei nesta parte do conflito: '+detail+'. Faltou conectar isso ao objetivo.'],
 ['Adulto','A ideia de '+sh.name+' tem potencial. Minha dificuldade foi entender o preço da escolha: '+consequence+'.'],
 ['Senhor','Eu daria outra chance a '+sh.name+'. O ponto de partida chama a atenção; o desenvolvimento poderia explicar melhor as decisões.'],
 ['Jovem',lead+' me trouxe pra '+sh.name+', só que elenco sozinho não resolve um conflito mal explicado.'],
 ['Adulto','Vale revisar a execução de '+sh.name+' junto desta intenção: '+shortText(ep.intent||sh.intent,130)+'.'],
 ['Senhor','Prefiro uma história pequena e clara a uma produção que corre demais. '+sh.name+' pode encontrar esse equilíbrio.']
 ];
 reviews.forEach((c,i)=>comments.push({id:'ai'+ep.id+'_'+i,name:c.name,role:c.role||'Fã',voice:c.ageGroup,parent:c.replyTo>=0&&c.replyTo<i?'ai'+ep.id+'_'+c.replyTo:null,text:c.text,source:'ai'}));
 opinions.forEach((p,i)=>comments.push({id:'local'+ep.id+'_'+i,name:SOCIAL_NAMES[(i+ep.number*3)%SOCIAL_NAMES.length],role:i===1?'Crítico':'Fã',voice:p[0],parent:null,text:p[1],source:'local'}));
 narrative.forEach((f,i)=>comments.push({id:'craft'+ep.id+'_'+i,name:['Lara no Cinema','Seu Artur','Marina Debate'][i],role:'Crítico',voice:['Adulto','Senhor','Jovem'][i],parent:null,text:sh.name+' · '+f.label+': '+shortText(f.evidence,190)+' Minha sugestão: '+f.advice,source:'local'}));
 if(s.difficulty==='director')for(let i=0;i<6;i++){const parent=comments[i%comments.length];comments.push({id:'reply'+ep.id+'_'+i,name:SOCIAL_NAMES[(i+11)%SOCIAL_NAMES.length],role:'Fã',voice:SOCIAL_VOICES[i%3],parent:parent.id,text:'@'+parent.name+' '+(i%2?'Eu entendi diferente: ':'Concordo no ponto da execução. ')+shortText(narrative[i%Math.max(1,narrative.length)]?.advice||sh.intent,170)+' '+sh.name+' merece uma discussão com esses detalhes.',source:'local'});}
 const used=new Set();return comments.filter(c=>{if(used.has(c.text))return false;used.add(c.text);return true;});
};
function addAmbientLocal(now=Date.now(),force=false){
 if(!s)return false;const elapsed=Math.max(0,now-s.live.lastLocalAt),count=force?1:Math.min(24,Math.floor(elapsed/300000));if(!count)return false;
 for(let i=0;i<count;i++){
  const serial=++s.social.serial,at=force?now:s.live.lastLocalAt+(i+1)*300000,rng=seeded(s.campaignId+'ambient'+serial),own=s.shows.filter(sh=>sh.episodes.some(ep=>ep.status==='aired'));
  const sh=own.length&&rng()>.35?pick(rng,own):null,w=sh?null:pick(rng,s.world.filter(w=>w.status==='active'));
  if(!sh&&!w)continue;const ep=sh?.episodes.filter(e=>e.status==='aired').at(-1),title=sh?.name||w.name,voice=SOCIAL_VOICES[serial%3],famous=ep?.actorName;
  const text=sh?pick(rng,[
    title+' voltou na conversa aqui em casa. '+shortText(sh.story.conflict,155)+'. Essa escolha ainda rende assunto.',
    (famous?'Fui assistir por '+famous+'. ':'')+'Agora tô pensando na ideia de '+title+': '+shortText(sh.concept,145)+'.',
    'Quero ler outras interpretações de '+title+'. '+shortText(sh.intent,150)+'. Alguém entendeu essa intenção de outro jeito?',
    'Meu debate de hoje sobre '+title+': '+shortText(sh.story.payoff,155)+'. O que vocês mudariam nessa consequência?',
    'Reassistindo '+title+' e pensando no comentário da galera sobre '+sh.genre+'. Público '+ep.viewers+'/100, mas minha opinião tem nuances.'
  ]):pick(rng,[
    'Alguém tá acompanhando '+title+' na '+networkBy(w.networkId).name+'? O catálogo de '+w.genre+' chamou minha atenção.',
    title+' entrou no meu radar: '+w.quality+'/100 na crítica do mercado. Vou comparar com os próximos lançamentos.',
    'A próxima disputa de prêmios vai ter '+title+'? Quero ver o que '+w.studio+' preparou.'
  ]);
  const key=hashText(text);if(s.social.used[key])continue;s.social.used[key]=true;
  s.social.posts.unshift({id:'ambient'+serial,platform:['tuiter','istagram','facibuk'][serial%3],user:pick(rng,SOCIAL_NAMES).replace(/\s/g,'_'),voice,week:s.week,title,text,likes:Math.round(rng()*(sh?Math.max(25,sh.fanBase*.015):250)),replyTo:null,showId:sh?.id||null,at,source:'local'});
 }
 s.live.lastLocalAt=now;s.social.posts=s.social.posts.slice(0,600);return true;
}

/* Online AI is opt-in. No provider secret is stored or requested in the APK. */
function serviceKey(){return 'empire-universe-'+(account?.id||'guest');}
function serviceConfig(){try{const c=JSON.parse(localStorage.getItem(serviceKey())||'null');return c&&typeof c.url==='string'&&typeof c.token==='string'?c:null;}catch{return null;}}
function validServiceURL(raw){try{const u=new URL(raw);if(u.username||u.password||u.search||u.hash)return null;if(u.protocol!=='https:'&&!(['localhost','127.0.0.1'].includes(u.hostname)&&u.protocol==='http:'))return null;return u.origin+u.pathname.replace(/\/$/,'');}catch{return null;}}
async function serviceJSON(route,body={},override=null){
 const c=override||serviceConfig();if(!c)throw Error('Conecte um servidor do universo em Configurações.');
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),100000);
 try{const response=await fetch(c.url+route,{method:'POST',headers:{'Content-Type':'application/json',...(c.token?{Authorization:'Bearer '+c.token}:{})},body:JSON.stringify(body),signal:controller.signal});
  let data;try{data=await response.json();}catch{throw Error('O servidor não devolveu uma resposta válida.');}
  if(!response.ok)throw Error(String(data.error||'Servidor indisponível.').slice(0,240));return data;
 }catch(e){if(e.name==='AbortError')throw Error('A análise demorou além do limite. Tente novamente; o progresso foi preservado.');throw e;}finally{clearTimeout(timer);}
}
function validAIReview(r){
 const string=v=>typeof v==='string'&&v.length<=2400;
 return r&&string(r.summary)&&string(r.verdict)&&string(r.hook)&&r.scores&&['originality','coherence','characters','impact','execution'].every(k=>Number.isInteger(r.scores[k])&&r.scores[k]>=0&&r.scores[k]<=100)&&Number.isInteger(r.productionWeeks)&&r.productionWeeks>=1&&r.productionWeeks<=6&&Array.isArray(r.strengths)&&r.strengths.length<=8&&r.strengths.every(string)&&Array.isArray(r.risks)&&r.risks.length<=8&&r.risks.every(x=>['aspect','evidence','impact','advice'].every(k=>string(x[k])))&&Array.isArray(r.comments)&&r.comments.length<=24&&r.comments.every(c=>string(c.name)&&string(c.text)&&['Jovem','Adulto','Senhor'].includes(c.ageGroup)&&['tuiter','istagram','facibuk'].includes(c.platform)&&Number.isInteger(c.replyTo));
}
async function connectService(fd){
 const url=validServiceURL(String(fd.get('url')||'')),name=String(fd.get('username')||'').trim(),password=String(fd.get('password')||''),register=fd.get('mode')==='register';
 if(!url)throw Error('Use a URL HTTPS do servidor. Localhost HTTP é aceito apenas para desenvolvimento.');
 const owner=account.id,configuration={url,token:''};
 showSceneLoading('Conectando seu universo',25);
 try{const result=await serviceJSON('/v1/auth/'+(register?'register':'login'),{username:name,password},configuration);
  if(account?.id!==owner)return;localStorage.setItem(serviceKey(),JSON.stringify({url,token:result.token,username:name}));s.live.serverCursor=0;s.live.lastSyncAt=0;s.live.error='';s.live.mode=result.aiAvailable?'online':'connected';save();await syncUniverse(true);notice(result.aiAvailable?'Universo conectado. IA online disponível.':'Servidor conectado; o responsável ainda precisa ativar a IA.');
 }finally{hideSceneLoading();render();}
}
function disconnectService(){try{localStorage.removeItem(serviceKey());}catch{}if(s){s.live.mode='local';s.live.error='';save();render();}notice('Modo local ativo. Seu progresso continua.');}
async function analyseWork(showId,script='',intent=null,production=false){
 const sh=showBy(showId);if(!sh)throw Error('Obra não encontrada.');
 const actualIntent=intent??sh.intent,key=projectFingerprint(sh,script,actualIntent),prior=production?sh.aiPrepared:sh.aiConcept;
 if(prior?.fingerprint===key)return prior;
 if(!serviceConfig())return null;
 const owner=account.id,campaign=s.campaignId;aiBusy=true;showSceneLoading('Analisando a identidade de '+sh.name,35);
 try{
  const payload={campaignId:campaign,project:{id:sh.id,title:sh.name,kind:sh.kind,genre:sh.genre,duration:sh.duration,concept:sh.concept,story:sh.story,intent:actualIntent,script},context:{difficulty:s.difficulty,reputation:s.reputation,crew:crewSnapshot(sh,''),networks:networks.map(n=>({id:n.id,name:n.name,threshold:n.threshold,reach:n.reach,focus:n.focus})),competition:s.world.filter(w=>w.status==='active').slice(-12).map(w=>({title:w.name,genre:w.genre,quality:w.quality}))}};
  const result=await serviceJSON('/v1/analyse',payload);if(!validAIReview(result.review))throw Error('O parecer da IA veio incompleto. Nenhum custo de produção foi aplicado.');
  if(account?.id!==owner||s?.campaignId!==campaign||!showBy(showId)||projectFingerprint(showBy(showId),script,actualIntent)!==key)throw Error('A obra mudou durante a análise. Analise a revisão atual.');
  const review={...result.review,fingerprint:key,source:'ai',at:Date.now(),provider:result.provider||'Servidor do universo',cached:Boolean(result.cached)};
  if(production)sh.aiPrepared=review;else{sh.aiConcept=review;sh.appeal=Math.round(25+aiNarrative(review)*.65);}
  s.live.mode='online';s.live.error='';save();showSceneLoading('Parecer concluído',100);return review;
 }catch(e){if(s?.campaignId===campaign){s.live.error=e.message;save();}throw e;}finally{aiBusy=false;hideSceneLoading();render();}
}
function universeSummary(){
 return {campaignId:s.campaignId,studio:s.name,week:s.week,difficulty:s.difficulty,projects:s.shows.slice(-16).map(sh=>{const ep=sh.episodes.filter(e=>e.status==='aired').at(-1);return{id:sh.id,title:sh.name,kind:sh.kind,genre:sh.genre,concept:sh.concept,story:sh.story,intent:sh.intent,status:sh.status,fame:sh.fanBase,lastEpisode:ep?{id:ep.id,title:ep.title,number:ep.number,season:ep.season,quality:ep.quality,critics:ep.critics,public:ep.viewers,views:ep.viewership,likes:ep.likes,favorites:ep.favorites,actor:ep.actorName,intent:ep.intent,script:ep.script,credits:(ep.credits||[]).map(c=>({role:c.role,name:c.name,fame:c.fame}))}:null};}),cursor:s.live.serverCursor,networks:networks.map(n=>({id:n.id,name:n.name,focus:n.focus,threshold:n.threshold,reach:n.reach})),recentTexts:s.social.posts.slice(0,45).map(p=>p.text)};
}
let universeInFlight=false,universeQueued=false;
async function syncUniverse(force=false){
 if(!account||!s||!serviceConfig()||universeInFlight||(!force&&Date.now()-s.live.lastSyncAt<60000))return false;
 const owner=account.id,campaign=s.campaignId;universeInFlight=true;
 try{const result=await serviceJSON('/v1/sync',universeSummary());if(account?.id!==owner||s?.campaignId!==campaign)return false;
  if(!Array.isArray(result.posts)||!Array.isArray(result.works)||!Number.isSafeInteger(result.cursor))throw Error('Sincronização do universo inválida.');
  for(const post of result.posts.slice(0,100)){
   if(!['tuiter','istagram','facibuk'].includes(post.platform)||typeof post.text!=='string'||post.text.length>2400||typeof post.name!=='string'||!['Jovem','Adulto','Senhor'].includes(post.ageGroup))continue;
   const key=hashText(post.text);if(s.social.used[key])continue;s.social.used[key]=true;
   const sh=s.shows.find(x=>String(x.id)===String(post.projectId)),id='online'+post.id;
   s.social.posts.unshift({id,platform:post.platform,user:post.name,voice:post.ageGroup,week:s.week,title:sh?.name||post.title||'Mercado',text:post.text,likes:Number.isFinite(post.likes)?Math.max(0,Math.round(post.likes)):0,replyTo:post.replyTo?'online'+post.replyTo:null,showId:sh?.id||null,at:post.at,source:'ai'});
   if(sh){const ep=sh.episodes.find(e=>String(e.id)===String(post.episodeId)&&e.status==='aired');if(ep&&!ep.comments.some(c=>c.text===post.text))ep.comments.push({id,name:post.name,voice:post.ageGroup,role:post.role==='Crítico'?'Crítico':'Fã',parent:null,text:post.text,source:'ai'});}
  }
  for(const w of result.works.slice(0,60)){
   if(s.live.importedWorks.includes(w.id)||!genres.includes(w.genre)||!networks.some(n=>n.id===w.networkId)||!Number.isInteger(w.productionWeeks)||w.productionWeeks<1||w.productionWeeks>6||!Number.isFinite(w.quality)||typeof w.title!=='string'||typeof w.premise!=='string')continue;
   s.live.importedWorks.push(w.id);s.world.push({id:'online-'+w.id,name:w.title.slice(0,80),kind:w.kind==='film'?'film':'series',genre:w.genre,networkId:w.networkId,studio:String(w.studio).slice(0,80),quality:clamp(Math.round(w.quality),5,100),viewers:0,status:'production',season:1,episode:0,debutWeek:s.week+w.productionWeeks,updatedWeek:s.week,history:[],productionWeeks:w.productionWeeks,source:'ai',premise:w.premise.slice(0,1800),story:w.story||{},intent:String(w.intent||'').slice(0,1200)});
   addNews('Projeto concorrente anunciado',w.title+' entra em produção na '+networkBy(w.networkId).name+'; estreia em '+w.productionWeeks+' semanas.','Mercado');
  }
  s.world=s.world.slice(-120);s.live.importedWorks=s.live.importedWorks.slice(-500);s.social.posts=s.social.posts.slice(0,600);s.live.serverCursor=result.cursor;s.live.lastSyncAt=Date.now();s.live.mode=result.aiAvailable?'online':'connected';s.live.error='';save();
  const editing=['INPUT','SELECT','TEXTAREA'].includes(document.activeElement?.tagName);
  if(!editing&&(tab==='social'||(tab==='networks'&&subpage!=='owned')||(tab==='settings'&&subpage==='connection')))render();return true;
 }catch(e){if(account?.id===owner&&s?.campaignId===campaign){s.live.error=e.message;s.live.lastSyncAt=Date.now();save();if(force)notice(e.message,true);}return false;}finally{universeInFlight=false;}
}
function queueUniverseSync(){if(universeQueued||!serviceConfig())return;universeQueued=true;setTimeout(()=>{universeQueued=false;syncUniverse(true);},500);}
setInterval(()=>{if(!account||!s||campaignSetup||aiBusy)return;const changed=addAmbientLocal();if(changed){save();if(tab==='social')render();}syncUniverse();},30000);

/* Empire TV — compact task screens, local subnavigation and progressive detail. */
const ICON_PATHS={
 menu:'M4 6h16M4 12h16M4 18h16',home:'m3 10 9-7 9 7M5 9v12h14V9M9 21v-8h6v8',
 film:'M3 4h18v16H3zM7 4v16M17 4v16M3 8h4M3 16h4M17 8h4M17 16h4',
 production:'m4 8 16-4 1 5L5 13zM5 13h16v8H5zM9 7l2 4M15 5l2 4',
 chart:'M4 3v18h17M8 17v-5M13 17V8M18 17V5',team:'M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M2 21v-3a7 7 0 0 1 14 0v3M17 5a4 4 0 0 1 0 7M19 15a5 5 0 0 1 3 5',
 network:'M5 12a7 7 0 0 1 14 0M2 12a10 10 0 0 1 20 0M9 12a3 3 0 0 1 6 0M12 14v7M8 21h8',
 goal:'M12 3a9 9 0 1 0 9 9M12 7a5 5 0 1 0 5 5M12 12l9-9M16 3h5v5',
 company:'M4 21V7l8-4v18M12 9h8v12M7 8v1M7 12v1M7 16v1M16 12v1M16 16v1M2 21h20',
 social:'M3 4h18v13H8l-5 4zM7 8h10M7 12h7',award:'M8 3h8v8a4 4 0 0 1-8 0zM8 5H4v3a4 4 0 0 0 4 4M16 5h4v3a4 4 0 0 1-4 4M12 15v5M8 21h8',
 store:'M4 7h16l-1 14H5zM8 7V5a4 4 0 0 1 8 0v2',settings:'M9 3h6l1 4 4 1 2 5-3 3 1 4-5 2-3-3-4 1-3-5 3-3-1-4 4-2zM9 12a3 3 0 1 0 6 0 3 3 0 0 0-6 0',
 arrow:'M4 12h16m-6-6 6 6-6 6',clock:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18M12 7v6l4 2',
 check:'m5 12 4 4L19 6',close:'m5 5 14 14M19 5 5 19',star:'m12 3 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z',
 heart:'M12 21 3 12A5 5 0 0 1 12 5a5 5 0 0 1 9 7z',money:'M2 6h20v12H2zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6M5 10v4M19 10v4',
 refresh:'M20 8a9 9 0 0 0-16-2M4 6V2M4 6h4M4 16a9 9 0 0 0 16 2M20 18v4M20 18h-4',
 spark:'m12 2 3 7 7 3-7 3-3 7-3-7-7-3 7-3z',eye:'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12M9 12a3 3 0 1 0 6 0 3 3 0 0 0-6 0',
 info:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18M12 11v6M12 7v1',
 paper:'M5 3h14v18H5zM8 7h8M8 11h8M8 15h8M8 18h5',calendar:'M4 5h16v16H4zM8 3v4M16 3v4M4 10h16M8 14h2M14 14h2',
 play:'m8 4 12 8-12 8z',pause:'M7 4h3v16H7zM14 4h3v16h-3z',bolt:'m13 2-8 12h6l-1 8 9-13h-6z',
 crown:'m3 6 5 4 4-7 4 7 5-4-2 13H5z',sound:'M4 9h4l5-4v14l-5-4H4zM17 8a6 6 0 0 1 0 8M20 5a10 10 0 0 1 0 14'
};
function icon(name){return '<svg class="em-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="'+(ICON_PATHS[name]||ICON_PATHS.info)+'"/></svg>';}
const MF_ICON='<svg class="mf-icon" viewBox="0 0 48 48" role="img" aria-label="Moeda da Fama"><circle cx="24" cy="24" r="22" fill="#9d651b"/><circle cx="24" cy="23" r="21" fill="#e8b953"/><path d="M5 23a19 19 0 0 1 38 0" fill="#f8d982"/><circle cx="24" cy="24" r="16" fill="none" stroke="#704511" stroke-width="1.5"/><path d="M11 15h3l3 6 3-6h3v16h-3V20l-3 6-3-6v11h-3zm15 0h11v3h-8v4h7v3h-7v6h-3z" fill="#624113"/><path d="M9 11a20 20 0 0 1 30 0" stroke="#fff8ce" stroke-width="2" fill="none"/></svg>';
const VANT_AVATAR='<svg viewBox="0 0 80 80" role="img" aria-label="Vant, o assistente"><path d="m40 4 5 12" stroke="#67e7d3" stroke-width="3"/><circle cx="40" cy="5" r="4" fill="#efc768"/><rect x="12" y="20" width="56" height="46" rx="16" fill="#142e39" stroke="#67e7d3" stroke-width="2"/><rect x="20" y="29" width="40" height="24" rx="9" fill="#09222b"/><path d="m26 40 5-5 5 5m8 0 5-5 5 5M31 48h18" stroke="#76ffe3" fill="none" stroke-width="3" stroke-linecap="round"/><path d="M8 35v13m64-13v13M23 68v7m34-7v7" stroke="#f3c569" stroke-width="5" stroke-linecap="round"/></svg>';
const EM_MENU=[['home','home','Estúdio'],['shows','film','Catálogo'],['production','production','Produção'],['reports','chart','Análises'],['team','team','Equipe'],['networks','network','Emissoras'],['goals','goal','Objetivos'],['company','company','Empresa'],['social','social','Redes'],['awards','award','Prêmios'],['store','store','Loja'],['settings','settings','Configurações']];
const EM_TABS={home:[['','Visão geral'],['agenda','Agenda']],shows:[['','Minhas obras'],['new','Criar obra'],['franchises','Franquias']],production:[['','Cronogramas'],['studio','Sala de produção']],reports:[['','Resultados']],team:[['','Contratados'],['agency','Agência']],networks:[['','Ranking'],['owned','Minhas emissoras'],['world','Concorrência']],goals:[['','Missões iniciais'],['daily','Missões diárias'],['catalog','Todos os desafios']],company:[['','Estatísticas'],['finance','Financeiro'],['upgrades','Melhorias']],social:[['tuiter','Tuiter'],['istagram','Istagram'],['facibuk','Facibuk']],awards:[['','Premiações'],['journal','Jornal']],store:[['','Moedas da Fama'],['exchange','Trocas'],['history','Histórico']],settings:[['','Conta e campanhas'],['connection','Universo online'],['assistant','Vant'],['help','Como jogar']]};
const VANT_STEPS=[
 ['home','home','Olá! Eu sou Vant.','Sua produtora começa aqui. O caixa paga projetos e equipe; a semana controla a produção. O menu abre as áreas, e as abas de baixo ficam na área atual.'],
 ['shows','film','Dê forma à sua ideia.','No catálogo você cria um filme ou uma série. Escreva quem age, o que deseja, qual é o conflito e o custo da decisão. A intenção explica suas escolhas criativas.'],
 ['team','team','Monte uma equipe.','Cada cargo tem uma formação. Especialidade melhora a execução; fama aumenta o público potencial. O salário é pago toda semana.'],
 ['team','clock','A agência tem ritmo próprio.','Na agência chegam quatro pessoas por profissão, a cada cinco minutos reais. MF pode renovar a rodada imediatamente. Contratados permanecem na equipe.'],
 ['networks','network','Escolha a tela certa.','As emissoras têm ranking, alcance e exigência. O parecer da proposta mostra a qualidade, a compatibilidade e a chance de aprovação. Uma ideia forte pode vencer a falta de fama.'],
 ['production','production','Produzir leva tempo.','Na sala de produção você escolhe equipe, roteiro, estilo, investimento e divulgação. O cronograma leva de uma a seis semanas; o investimento é pago ao iniciar.'],
 ['production','calendar','Acompanhe cada etapa.','A fila mostra prazo e progresso. Avançar a semana paga salários e manutenção. Uma obra só estreia no prazo, e emissora própria pausada adia a publicação.'],
 ['reports','chart','Leia o que funcionou.','Os relatórios explicam criatividade, execução, visualizações, críticas, gostei, favoritos e resultado financeiro. Use evidências e sugestões para melhorar a próxima obra.'],
 ['goals','goal','Sua jornada começa nas missões.','Conclua todas as missões iniciais para terminar meu tutorial. Depois, missões diárias mudam a cada 24 horas reais e podem ser trocadas com MF.'],
 ['company','company','Cuide da empresa.','Você acompanha receitas, despesas, investimentos e histórico. Melhorias ampliam a equipe e a produção. Verba sem controle acaba antes da estreia.'],
 ['social','social','O público continua conversando.','As redes mostram vozes diferentes e debates sobre as obras. Com universo online conectado, o servidor guarda novas conversas mesmo com o jogo fechado.'],
 ['awards','award','Dispute com outras produtoras.','As galas acontecem a cada 12 semanas. Obras concorrentes também têm cronograma, qualidade e público. Criatividade e execução contam no júri.'],
 ['store','store','Esta é a Moeda da Fama.','MF renova a agência, troca missões e compra recursos. A loja mostra os futuros pacotes premium; compras com dinheiro real ainda estão desativadas.'],
 ['settings','settings','Guarde sua carreira.','Aqui você exporta o progresso, administra campanhas, conecta o universo e me chama de novo. Faça backup antes de trocar de aparelho.'],
 ['home','check','Agora é com você.','A apresentação terminou, mas eu continuo acompanhando as missões iniciais. O tutorial só será concluído quando todas estiverem completas.']
];
function emButton(label,attribute,style='secondary',ic=''){return '<button type="button" class="'+style+'" '+attribute+'>'+ (ic?icon(ic):'')+'<span>'+esc(label)+'</span></button>';}
let emFieldSerial=0;
field=function(label,name,value='',type='text',attrs=''){const uid='em-field-'+(++emFieldSerial);return '<div class="em-field"><label class="label" for="'+uid+'">'+esc(label)+'</label><input id="'+uid+'" type="'+type+'" name="'+esc(name)+'" value="'+esc(value)+'" '+attrs+'></div>';};
optionSelect=function(label,name,values,current,attrs=''){const uid='em-field-'+(++emFieldSerial);return '<div class="em-field"><label class="label" for="'+uid+'">'+esc(label)+'</label><select id="'+uid+'" name="'+esc(name)+'" '+attrs+'>'+values.map(v=>'<option value="'+esc(Array.isArray(v)?v[0]:v)+'" '+(String(Array.isArray(v)?v[0]:v)===String(current)?'selected':'')+'>'+esc(Array.isArray(v)?v[1]:v)+'</option>').join('')+'</select></div>';};
function emPage(title,description,content,badge=''){return '<section class="em-page"><div class="em-page-head"><div><h2>'+esc(title)+'</h2><p>'+esc(description)+'</p></div>'+(badge?pill(badge,'cyan'):'')+'</div>'+content+'</section>';}
function emEmpty(title,text){return '<div class="em-empty">'+icon('film')+'<h3>'+esc(title)+'</h3><p>'+esc(text)+'</p></div>';}
function emNote(text,ic='info'){return '<div class="em-note">'+icon(ic)+'<span>'+esc(text)+'</span></div>';}
function emNavigation(){return '<nav id="empire-menu" class="em-menu '+(menuOpen?'open':'')+'" aria-label="Menu principal"><div class="em-menu-brand"><div class="beta-logo">'+TV_LOGO+'</div><b>EMPIRE TV</b></div>'+EM_MENU.map(m=>'<button type="button" data-em-nav="'+m[0]+'" class="'+(tab===m[0]?'active':'')+'">'+icon(m[1])+'<span>'+m[2]+'</span></button>').join('')+'<div class="em-menu-bottom"><span>V&amp;D Digital</span><small>'+EMPIRE_VERSION+'</small></div></nav>';}
pageSubnav=function(){const items=EM_TABS[tab]||EM_TABS.home;return '<nav class="em-subnav" aria-label="Abas desta página">'+items.map(t=>'<button type="button" data-em-sub="'+t[0]+'" class="'+((tab==='social'?socialNetwork:subpage)===t[0]?'active':'')+'">'+esc(t[1])+'</button>').join('')+'</nav>';};
function emHeader(){return '<header class="em-header"><button type="button" class="em-icon-button mobile-menu" data-em-menu aria-label="Abrir menu" aria-expanded="'+menuOpen+'" aria-controls="empire-menu">'+icon('menu')+'</button><div class="em-brand"><div class="beta-logo">'+TV_LOGO+'</div><div><h1>EMPIRE TV</h1><small>'+esc(s.name)+'</small></div></div><div class="em-wallet"><span>'+icon('money')+'<b>'+money(s.cash)+'</b></span><button type="button" data-em-nav="store" aria-label="Abrir loja, saldo '+s.fameWallet.balance+' MF">'+MF_ICON+'<b>'+s.fameWallet.balance+' MF</b></button></div><button type="button" class="em-icon-button" data-em-nav="settings" aria-label="Configurações">'+icon('settings')+'</button></header>';}
function emWeekbar(){const pending=s.shows.flatMap(sh=>sh.episodes.filter(e=>e.status==='produced')),next=Math.min(Infinity,...pending.map(e=>e.airWeek));return '<div class="em-weekbar"><div>'+icon('calendar')+'<b>Semana '+s.week+'</b><span>'+esc(policy().name)+' · '+(Number.isFinite(next)?'Próxima estreia: semana '+next:'Sem estreia agendada')+'</span></div><button type="button" class="primary" data-next-week '+(aiBusy?'disabled':'')+'>Avançar semana '+icon('arrow')+'</button></div>';}
home=function(){
 if(subpage==='agenda'){const queued=s.shows.flatMap(sh=>sh.episodes.filter(e=>e.status==='produced').map(ep=>({sh,ep}))).sort((a,b)=>a.ep.airWeek-b.ep.airWeek);return emPage('Agenda da produtora','Prazos, programação e próximos acontecimentos.',queued.map(x=>pipelineCard(x.sh,x.ep)).join('')+emNote('Próxima premiação: semana '+((Math.floor(s.week/12)+1)*12)+'. Agência e missões usam o relógio real.','calendar')+'<details><summary>Notícias recentes</summary>'+s.news.slice(0,8).map(n=>'<article class="em-news"><span>'+esc(n.topic)+' · S'+n.week+'</span><h3>'+esc(n.title)+'</h3><p>'+esc(n.text)+'</p></article>').join('')+'</details>');}
 const pending=s.shows.flatMap(sh=>sh.episodes.filter(e=>e.status==='produced')),next=objectiveDefs.find(o=>!s.claimed.includes(o.id)),top=s.shows.slice().sort((a,b)=>b.totalViewers-a.totalViewers)[0];
 return emPage('Seu próximo grande lançamento','Uma ideia, uma equipe e decisões que deixam marca.',
 '<div class="em-hero"><div><span class="eyebrow">V&amp;D DIGITAL · ESTÚDIO '+esc(s.name.toUpperCase())+'</span><h2>Sua visão.<br>O mundo assistindo.</h2><p>'+(s.difficulty==='director'&&!s.grantTaken?'Seu primeiro desafio é convencer um estúdio a financiar a ideia.':'Transforme criatividade em histórias, e histórias em uma produtora sustentável.')+'</p>'+emButton('Abrir catálogo','data-em-nav="shows"','primary','film')+'</div><div class="em-hero-art">'+TV_LOGO+'<span>'+s.awards.wins+' prêmios · '+compact(s.fans)+' fãs</span></div></div>'+
 kpis([['Obras no catálogo',s.shows.length],['Em produção',pending.length],['Reputação',Math.round(s.reputation)+'/100'],['Equipe',s.hired.length+'/'+rosterCapacity()]])+
 '<div class="em-two"><article class="card"><span class="eyebrow">FOCO DA CAMPANHA</span><h3>'+(next?esc(next.title):'Missões iniciais concluídas')+'</h3><p>'+(next?esc(next.desc):'Acompanhe as tarefas diárias e prepare sua próxima estreia.')+'</p><div class="bar"><i style="width:'+(objectiveDefs.filter(o=>s.claimed.includes(o.id)).length/objectiveDefs.length*100)+'%"></i></div><small>'+objectiveDefs.filter(o=>s.claimed.includes(o.id)).length+'/'+objectiveDefs.length+' missões iniciais</small></article><article class="card"><span class="eyebrow">EM EVIDÊNCIA</span><h3>'+esc(top?.name||'Seu primeiro projeto')+'</h3><p>'+(top?compact(top.totalViewers)+' visualizações · '+compact(top.fanBase)+' fãs da obra.':'O catálogo começa com uma ideia sua. Nenhum estilo é obrigatório.')+'</p>'+emNote(serviceConfig()?'Universo online conectado.':'Modo local ativo. IA online configurável.','spark')+'</article></div>');
};
function newWorkScreen(){
 const cost=s.difficulty==='director'?0:Math.round(12000*policy().cost);
 return emPage('Criar uma obra','A ideia vem primeiro. Os detalhes ficam organizados em etapas.','<article class="card em-form-card"><form data-action="createShow"><div class="em-field-title">'+field('Título','name','','text','required minlength="3" maxlength="65" placeholder="O nome da sua obra"')+'</div><div class="formgrid">'+optionSelect('Formato','kind',[['series','Série'],['film','Filme']],'series','data-em-kind')+optionSelect('Gênero','genre',genres.filter(genreUnlocked),'Drama')+optionSelect('Duração por produção','duration',[[20,'20 minutos'],[30,'30 minutos'],[45,'45 minutos'],[60,'60 minutos']],45,'data-em-duration')+'</div>'+storyInputs()+'<div class="em-form-footer"><span>Desenvolvimento: <b>'+money(cost)+'</b></span><button type="submit" class="primary">'+icon('film')+' Criar projeto</button></div></form></article>');
}
function selectedWork(){return s.shows.find(sh=>sh.id===Number(chosenShow))||null;}
function workList(filter=s.shows){
 return '<div class="em-work-list">'+filter.slice().reverse().map(sh=>'<button type="button" class="em-work-row '+(sh.id===Number(chosenShow)?'selected':'')+'" data-em-work="'+sh.id+'"><div class="em-cover">'+icon(isFilm(sh)?'film':'production')+'</div><div><b>'+esc(sh.name)+'</b><span>'+ (isFilm(sh)?'Filme':'Série')+' · '+esc(sh.genre)+' · '+sh.duration+' min</span></div><div class="em-work-status">'+pill(showStatus(sh),sh.status==='active'?'green':'cyan')+'<small>'+compact(sh.totalViewers)+' views</small></div>'+icon('arrow')+'</button>').join('')+'</div>';
}
function aiReviewCard(sh){
 const r=currentConceptAI(sh);if(!r)return '<article class="card"><h3>'+icon('spark')+' Parecer criativo</h3><p>'+(serviceConfig()?'Analise esta versão da ideia para receber evidências e sugestões da IA.':'Este parecer local considera o argumento informado. A avaliação semântica de IA fica disponível ao conectar o universo online.')+'</p>'+(serviceConfig()?emButton('Analisar ideia com IA','data-em-analyse="'+sh.id+'"','secondary','spark'):plotFactors(sh).map(f=>'<details><summary>'+esc(f.label)+' · '+f.score+'/100</summary><p>'+esc(f.evidence)+'</p><p>'+esc(f.advice)+'</p></details>').join(''))+'</article>';
 return '<article class="card"><div class="between"><h3>'+icon('spark')+' Parecer da ideia</h3>'+pill(aiNarrative(r)+'/100','green')+'</div><p>'+esc(r.summary)+'</p>'+kpis([['Originalidade',r.scores.originality],['Coerência',r.scores.coherence],['Personagens',r.scores.characters],['Impacto',r.scores.impact]])+'<h4>O que sustenta a obra</h4><ul>'+r.strengths.map(t=>'<li>'+esc(t)+'</li>').join('')+'</ul>'+r.risks.map(x=>'<details><summary>'+esc(x.aspect)+'</summary><p><b>Evidência:</b> '+esc(x.evidence)+'</p><p><b>Efeito:</b> '+esc(x.impact)+'</p><p><b>Como melhorar:</b> '+esc(x.advice)+'</p></details>').join('')+'<p class="scope-label">'+esc(r.verdict)+' Prazo estimado: '+r.productionWeeks+' semanas.</p></article>';
}
function workDetail(sh){
 const tabs=[['overview','Visão geral'],['writing','Argumento'],['team','Equipe'],['distribution','Distribuição'],['analysis','Parecer']];
 let content='';
 if(workPanel==='writing')content=sh.episodes.some(ep=>ep.status==='produced')?emNote('A obra está em produção. Aguarde a publicação para revisar o argumento; os dados da gravação estão preservados.','clock'):'<article class="card"><form data-action="editStory"><input type="hidden" name="showId" value="'+sh.id+'">'+storyInputs(sh)+'<button type="submit" class="primary">Salvar revisão</button></form></article>';
 else if(workPanel==='team')content='<article class="card">'+crewForm(sh)+'</article>';
 else if(workPanel==='distribution')content='<article class="card">'+fundingPanel(sh)+(['development','cancelled'].includes(sh.status)?pitchPanel(sh):emNote('Distribuição: '+(networkBy(sh.networkId)?.name||'Sem contrato')+'. Licença '+money(sh.fee)+(isFilm(sh)?' por filme.':' por episódio.')))+(sh.status==='between'?emButton('Tentar renovar temporada','data-renew="'+sh.id+'"','primary','refresh'):'')+'<details><summary>Negociações anteriores</summary>'+sh.pitchHistory.map(p=>'<p><b>'+esc(p.network)+'</b> · '+(p.result==='accepted'?'Aprovada':'Recusada')+' · S'+p.week+'<br>'+esc(p.why)+'</p>').join('')+'</details></article>';
 else if(workPanel==='analysis')content=aiReviewCard(sh);
 else content='<article class="card"><p>'+esc(sh.concept)+'</p>'+kpis([['Visualizações',compact(sh.totalViewers)],['Crítica média',sh.avgCritics?sh.avgCritics+'/100':'—'],['Fãs da obra',compact(sh.fanBase)],['Produções',sh.episodes.length]])+'<p><b>Intenção:</b> '+esc(sh.intent||'Ainda não registrada.')+'</p>'+(sh.parentId?emNote('Continuação de '+(showBy(sh.parentId)?.name||sh.franchiseRoot)+'.','film'):'')+'<div class="btnrow">'+(sh.status==='active'?emButton('Abrir sala desta obra','data-em-produce="'+sh.id+'"','primary','production'):'')+(sh.status==='ended'?emButton('Desenvolver continuação','data-sequel="'+sh.id+'"','secondary','film'):'')+(['active','between','cancelled'].includes(sh.status)?emButton('Finalizar obra','data-end="'+sh.id+'"','ghost','check'):'')+'</div><details><summary>Exibições e cronogramas</summary>'+sh.episodes.map(ep=>'<div class="em-ledger-row"><div><b>'+esc(ep.title)+'</b><small>'+(ep.status==='aired'?'Estreou na semana '+ep.airWeek:'Estreia prevista: semana '+ep.airWeek)+'</small></div><span>'+ (ep.status==='aired'?compact(ep.viewership)+' views':ep.production.weeks+' semanas')+'</span></div>').join('')+'</details></article>';
 return '<div class="em-detail-head"><div><span class="eyebrow">'+(isFilm(sh)?'FILME':'SÉRIE')+' · '+esc(sh.genre)+'</span><h3>'+esc(sh.name)+'</h3></div>'+emButton('Fechar detalhes','data-em-work-close','ghost','close')+'</div><nav class="em-detail-tabs" aria-label="Detalhes da obra">'+tabs.map(t=>'<button type="button" data-em-work-panel="'+t[0]+'" class="'+(workPanel===t[0]?'active':'')+'">'+t[1]+'</button>').join('')+'</nav>'+content;
}
shows=function(){
 if(subpage==='new')return newWorkScreen();
 const sh=selectedWork();if(sh)return emPage('Catálogo','Tudo sobre uma obra, em um lugar só.',workDetail(sh));
 if(subpage==='franchises'){const groups={};s.shows.forEach(sh=>(groups[sh.franchiseRoot]??=[]).push(sh));return emPage('Franquias','Continuações preservam a identidade e negociam um novo contrato.',Object.entries(groups).filter(([,v])=>v.length>1||v.some(sh=>sh.status==='ended')).map(([name,group])=>'<article class="card"><h3>'+esc(name)+'</h3>'+workList(group)+'</article>').join('')||emEmpty('Suas franquias aparecerão aqui','Encerre uma obra para desenvolver sua continuação.'));}
 return emPage('Minhas obras','Selecione uma obra para editar, montar a equipe, analisar e negociar.',s.shows.length?workList():emEmpty('Seu catálogo está em branco','Abra Criar obra na barra inferior para desenvolver sua primeira ideia.'),s.shows.length+' projetos');
};
function pipelineCard(sh,ep){
 const plan=ep.production||{weeks:1,startedWeek:ep.producedWeek,releaseWeek:ep.airWeek},elapsed=clamp(s.week-plan.startedWeek,0,plan.weeks),paused=s.networks.find(n=>n.id===sh.networkId)?.paused,remaining=Math.max(0,ep.airWeek-s.week),phase=paused?'Aguardando retomada da emissora':remaining<=0?'Aguardando publicação':['Pré-produção','Gravação','Montagem','Som e acabamento','Revisão final','Publicação'][Math.min(5,Math.floor(elapsed/plan.weeks*6))];
 return '<article class="card em-pipeline"><div class="between wrap"><div><span class="eyebrow">'+esc(unitLabel(sh,ep))+'</span><h3>'+esc(sh.name)+'</h3><p>'+esc(ep.title)+'</p></div>'+pill('Estreia: S'+ep.airWeek,paused?'orange':'cyan')+'</div><div class="em-timeline"><div class="bar"><i style="width:'+(elapsed/plan.weeks*100)+'%"></i></div><span>'+esc(phase)+'</span><b>'+elapsed+'/'+plan.weeks+' semanas</b></div><p class="scope-label">'+esc(plan.reason||'Prazo preservado da campanha anterior.')+' '+(paused?'Retome a emissora para publicar.':remaining+' semana(s) até a estreia.')+'</p></article>';
}
const finalProductionFormBase=productionForm;
productionForm=function(sh){const pending=sh.episodes.find(ep=>ep.status==='produced');if(pending)return pipelineCard(sh,pending);let html=finalProductionFormBase(sh);if(!html.includes('data-action="produce"'))return html;const plan=productionPlan(sh);return emNote('Estimativa atual: '+plan.weeks+' semanas. O cronograma definitivo considera o roteiro informado e o parecer criativo.','clock')+html.replace('Impacto previsto da equipe','Equipe desta produção');};
production=function(){
 const active=s.shows.filter(sh=>sh.status==='active'),pending=s.shows.flatMap(sh=>sh.episodes.filter(ep=>ep.status==='produced').map(ep=>({sh,ep})));
 if(subpage!=='studio')return emPage('Cronogramas','Cada produção estreia quando seu prazo termina.',pending.length?pending.map(x=>pipelineCard(x.sh,x.ep)).join(''):emEmpty('Nenhuma obra na fila','Abra Sala de produção para iniciar uma obra já aprovada.'));
 const chosen=active.find(sh=>sh.id===Number(chosenShow))||active[0];
 if(!chosen)return emPage('Sala de produção','Roteiro, equipe e orçamento antes da gravação.',emEmpty('Nenhum projeto aprovado','Negocie a distribuição de uma obra no catálogo para abrir sua sala.'));
 return emPage('Sala de produção','Concentre as escolhas de uma obra antes de iniciar o cronograma.','<div class="card em-selector">'+optionSelect('Obra em produção','selectedWork',active.map(sh=>[sh.id,sh.name]),chosen.id,'data-em-production-select')+'</div><article class="card"><h3>'+esc(chosen.name)+'</h3><p>'+esc(chosen.genre)+' · '+esc(networkBy(chosen.networkId)?.name||'Independente')+'</p>'+productionForm(chosen)+'</article>');
};
function analysisScreen(sh,ep){
 const buttons=[['overview','Resultado'],['creative','Criatividade'],['audience','Alcance'],['comments','Comentários'],['credits','Equipe']];
 let body='';
 if(reportPanel==='creative')body=(ep.aiReview?'<article class="card"><h3>'+icon('spark')+' Parecer registrado na produção</h3><p>'+esc(ep.aiReview.summary)+'</p>'+ep.aiReview.risks.map(r=>'<details><summary>'+esc(r.aspect)+'</summary><p>'+esc(r.evidence)+'</p><p>'+esc(r.impact)+'</p><p><b>Sugestão:</b> '+esc(r.advice)+'</p></details>').join('')+'</article>':'')+'<div class="rows">'+ep.analysis.map(f=>'<details><summary>'+esc(f.label)+' · '+f.score+'/100</summary><p>'+esc(f.evidence)+'</p><p><b>Como melhorar:</b> '+esc(f.advice)+'</p></details>').join('')+'</div>';
 else if(reportPanel==='audience'){const d=ep.distribution||{};body='<article class="card"><h3>Como o alcance foi formado</h3>'+kpis([['Distribuidor',d.networkName||'—'],['Alcance da rede','×'+(d.reach||1).toFixed(2)],['Fama do elenco','×'+(d.starMultiplier||1).toFixed(2)],['Concorrência','×'+(d.competition||1).toFixed(2)]])+'<p>'+esc(d.why||distribution(sh).why)+'</p><p>'+esc(d.revenuePolicy||'Contrato anterior à atualização.')+'</p>'+emNote('Divulgação amplia a descoberta; a ideia e a execução sustentam a recepção.','eye')+'</article>';}
 else if(reportPanel==='comments')body='<div class="em-comments">'+(ep.comments||[]).map(c=>'<article class="social-post '+(c.parent?'reply':'')+'"><div class="between wrap"><b>@'+esc(c.name)+'</b>'+pill(c.voice||c.role,'cyan')+'</div><p>'+esc(c.text)+'</p><small>'+esc(c.role)+' · '+(c.source==='ai'?'Universo online':'Universo local')+'</small></article>').join('')+'</div>';
 else if(reportPanel==='credits')body='<article class="card"><h3>Créditos preservados</h3>'+emNote('Trocar os cargos depois da gravação não muda este registro.','team')+'<div class="beta-table"><table class="table"><thead><tr><th>Função</th><th>Profissional</th><th>Técnica</th><th>Fama</th></tr></thead><tbody>'+(ep.credits||[]).map(c=>'<tr><td>'+esc(c.role)+'</td><td><b>'+esc(c.name)+'</b></td><td>'+c.technique+'</td><td>'+c.fame+'</td></tr>').join('')+'</tbody></table></div></article>';
 else body=kpis([['Visualizações',compact(ep.viewership)],['Público',ep.viewers+'/100'],['Crítica',ep.critics+'/100'],['Gostei',compact(ep.likes)],['Favoritos',compact(ep.favorites)],['Avaliações',compact(ep.reviewCount)],['Críticas negativas',compact(ep.negativeReviews)],['Novos fãs',compact(ep.newFans)]])+'<article class="card"><h3>Resultado financeiro desta produção</h3>'+kpis([['Receita da estreia',money(ep.revenue)],['Investimento',money(ep.budget)],['Resultado da produção',money(ep.netProduction)],['Prazo registrado',(ep.production?.weeks||1)+' semana(s)']])+'<p class="scope-label">Folha salarial e manutenção aparecem no financeiro da empresa. Estes custos não são debitados novamente no relatório.</p></article>';
 return '<div class="em-detail-head"><div><span class="eyebrow">'+esc(unitLabel(sh,ep))+' · ESTREIA S'+ep.airWeek+'</span><h3>'+esc(ep.title)+'</h3></div>'+emButton('Voltar aos resultados','data-em-report-close','ghost','close')+'</div><nav class="em-detail-tabs" aria-label="Partes da análise">'+buttons.map(t=>'<button type="button" class="'+(reportPanel===t[0]?'active':'')+'" data-em-report-panel="'+t[0]+'">'+t[1]+'</button>').join('')+'</nav>'+body;
}
reportsPage=function(){
 const rows=s.shows.flatMap(sh=>sh.episodes.filter(ep=>ep.status==='aired').map(ep=>({sh,ep}))).sort((a,b)=>b.ep.airWeek-a.ep.airWeek),selected=rows.find(x=>x.ep.id===Number(chosenReport));
 return emPage('Análises','Números e evidências para melhorar a próxima produção.',selected?analysisScreen(selected.sh,selected.ep):rows.length?'<div class="em-work-list">'+rows.map(x=>'<button type="button" class="em-work-row" data-em-report="'+x.ep.id+'"><div class="em-cover">'+icon('chart')+'</div><div><b>'+esc(x.sh.name)+'</b><span>'+esc(x.ep.title)+' · S'+x.ep.airWeek+'</span></div><div class="em-work-status"><b>'+compact(x.ep.viewership)+'</b><small>Público '+x.ep.viewers+'/100</small></div>'+icon('arrow')+'</button>').join('')+'</div>':emEmpty('Seu primeiro relatório vem na estreia','Acompanhe o prazo da produção. Quando ela for ao ar, os resultados aparecerão aqui.'));
};
const finalTeamBase=team;
team=function(){
 if(subpage==='agency')return emPage('Agência de talentos','Quatro pessoas por profissão; cada rodada dura cinco minutos.', '<div class="em-agency-toolbar"><div>'+icon('clock')+'<b data-market-timer></b></div>'+emButton('Renovar agora · '+MF_PRICES.agency+' MF','data-em-refresh-agency','secondary','refresh')+'</div><div class="chip-row">'+[['all','Todos']].concat(BETA_ROLES.map(r=>[r,ROLE_LABELS[r]])).map(x=>'<button type="button" class="filter-chip '+(agencyFilter===x[0]?'active':'')+'" data-agency-filter="'+esc(x[0])+'">'+esc(x[1])+'</button>').join('')+'</div><div id="market-list">'+marketCards()+'</div><details><summary>Probabilidades do catálogo</summary><p class="scope-label">A chance individual muda conforme os talentos disponíveis. O sorteio sempre preenche quatro vagas de cada profissão. Contratados permanecem na equipe.</p><div class="beta-table"><table class="table"><thead><tr><th>Talento</th><th>Formação</th><th>Chance atual</th></tr></thead><tbody>'+talents.filter(t=>!t.legacyOnly&&!t.trainee).map(t=>'<tr><td><b>'+esc(t.name)+'</b></td><td>'+esc(t.role)+'</td><td>'+(s.hired.includes(t.id)?'Contratado':(marketChance(t)*100).toFixed(1)+'%')+'</td></tr>').join('')+'</tbody></table></div></details>',s.hired.length+'/'+rosterCapacity()+' vagas');
 return emPage('Sua equipe','Cargos, especialidades e salários visíveis antes da próxima gravação.',kpis([['Contratados',s.hired.length],['Vagas',rosterCapacity()],['Folha por semana',money(hiredCost())],['Fama média',hired().length?Math.round(hired().reduce((v,t)=>v+t.fame,0)/hired().length):0]])+'<details><summary>Como cada contratado afeta a obra</summary><p>Especialidade no gênero: +12 de técnica, até 100. Cargo fora da formação: técnica ×0,60. Fama aumenta o alcance potencial; salários são pagos toda semana. Escolha a equipe de cada obra no catálogo.</p></details><div class="em-card-grid">'+hired().map(t=>betaTalentCard(t,true)).join('')+'</div>'+(s.hired.length?'':emEmpty('Sua equipe ainda está vazia','A agência está na aba inferior. O apoio interno tem técnica 38 e fama 0.')));
};
const finalOwnedScreenBase=ownedNetworksPage,finalWorldPageBase=worldPage;
function rankingScreen(){
 const ranked=networks.slice().sort((a,b)=>(a.rank||100)-(b.rank||100)||b.reach-a.reach);
 return emPage('Ranking de emissoras','Audiência e qualidade da programação mudam alcance e posição a cada semana.', '<div class="em-ranking">'+ranked.map((n,i)=>'<details class="em-network-row"><summary><span class="em-rank">'+(n.rank||i+1)+'</span><div><b>'+esc(n.name)+'</b><small>'+esc(n.type)+' · '+esc(n.focus.join(' / '))+'</small></div><span><b>×'+n.reach.toFixed(2)+'</b><small>Exigência '+n.threshold+'/100</small></span><span class="'+((n.delta||0)>=0?'up':'down')+'">'+((n.delta||0)>0?'+':'')+(n.delta||0).toFixed(2)+'</span></summary><div class="em-network-details">'+kpis([['Pontuação',n.score||'—'],['Audiência semanal',compact(n.weeklyViews||0)],['Qualidade da grade',n.quality||'—'],['Licença base',money(n.fee)]])+'<p>Alcance é um multiplicador; exigência define o nível do projeto. O parecer e a reputação influenciam a negociação. Contratos já assinados preservam a licença.</p>'+s.world.filter(w=>w.networkId===n.id).slice(-5).map(w=>'<p><b>'+esc(w.name)+'</b> · '+(w.status==='production'?'Estreia S'+w.debutWeek:w.quality+'/100 · '+compact(w.viewers)+' views')+'</p>').join('')+'</div></details>').join('')+'</div>');
}
networksPage=function(){
 if(subpage==='owned')return finalOwnedScreenBase();
 if(subpage==='world')return emPage('Outras produtoras','Novas obras entram em produção e disputam público e prêmios.', '<div class="em-card-grid">'+s.world.slice().reverse().map(w=>'<article class="card"><span class="eyebrow">'+esc(w.studio)+' · '+(w.source==='ai'?'IA online':'Universo local')+'</span><h3>'+esc(w.name)+'</h3><p>'+esc(w.genre)+' · '+esc(networkBy(w.networkId)?.name||'Distribuidor')+'</p>'+pill(w.status==='production'?'Em produção · estreia S'+w.debutWeek:w.quality+'/100','cyan')+'<p>'+esc(w.premise||'Produção do catálogo desta emissora.')+'</p>'+(w.status==='production'?'<p class="scope-label">Cronograma: '+w.productionWeeks+' semanas. Só disputa prêmios após estrear.</p>':'<p class="scope-label">'+compact(w.viewers)+' visualizações na última semana.</p>')+'</article>').join('')+'</div>',s.world.length+' obras');
 return rankingScreen();
};
const finalGoalsScreenBase=goalsPage;
goalsPage=function(){
 if(subpage==='catalog')return finalGoalsScreenBase();
 if(subpage==='daily'){ensureDaily();if(!s.daily.active)return emPage('Missões diárias','Rodadas de 24 horas reais.',emEmpty('Termine primeiro a jornada inicial','Conclua todas as missões da aba Missões iniciais para liberar os desafios diários.'));
  return emPage('Missões diárias','Cada recompensa é resgatada uma vez. Trocas preservam a dificuldade.','<div class="em-agency-toolbar"><span>Rodada '+s.daily.cycle+'</span><b data-daily-timer></b></div><div class="em-card-grid">'+s.daily.tasks.map(task=>{const o=DAILY_OBJECTIVES.find(x=>x.id===task.id),value=dailyValue(o),ready=value>=o.goal;return '<article class="card"><div class="between">'+pill(TIER_NAMES[o.tier],'cyan')+pill(task.claimed?'Resgatada':ready?'Pronta':'Em andamento',ready?'green':'')+'</div><h3>'+esc(o.title)+'</h3><p>'+esc(o.desc)+'</p><div class="bar"><i style="width:'+clamp(value/o.goal*100,0,100)+'%"></i></div><p class="scope-label">'+compact(Math.min(value,o.goal))+' / '+compact(o.goal)+' · '+money(o.cash)+' · +1 MF'+(s.difficulty!=='director'?' · '+o.boostCount+' powerups':'')+'</p><div class="btnrow"><button type="button" class="primary" data-claim-daily="'+o.id+'" '+(task.claimed||!ready?'disabled':'')+'>Resgatar</button><button type="button" class="ghost" data-em-reroll="'+o.id+'" '+(task.claimed||ready?'disabled':'')+'>'+icon('refresh')+' Trocar · '+MF_PRICES.mission+' MF</button></div></article>';}).join('')+'</div>');
 }
 const done=objectiveDefs.filter(o=>s.claimed.includes(o.id)).length;
 return emPage('Missões iniciais','A jornada com Vant só termina quando todas estiverem concluídas.',kpis([['Concluídas',done+'/'+objectiveDefs.length],['Ao terminar',s.fameWallet.rewarded['vant-primary-complete']?'MF já recebidas':'+30 MF'],['Recompensas','Dinheiro e XP'],['Próxima etapa','Desafios diários']])+'<div class="em-card-grid">'+objectiveDefs.map(o=>{const completed=s.claimed.includes(o.id),value=goalValue(o);return '<article class="card"><div class="between"><h3>'+esc(o.title)+'</h3>'+icon(completed?'check':'goal')+'</div><p>'+esc(o.desc)+'</p><div class="bar"><i style="width:'+clamp(value/o.goal*100,0,100)+'%"></i></div><p class="scope-label">'+(o.id==='revenue'?money(value):value)+' / '+(o.id==='revenue'?money(o.goal):o.goal)+' · '+money(o.cash)+' · '+o.xp+' XP</p>'+pill(completed?'Recompensa recebida':'Recompensa automática',completed?'green':'cyan')+'</article>';}).join('')+'</div>');
};
const finalCompanyBase=company;
company=function(){
 if(subpage==='finance')return emPage('Financeiro','As entradas e saídas conciliam com o caixa da produtora.',kpis([['Saldo inicial',money(s.finance.opening)],['Entradas',money(s.finance.income)],['Saídas',money(s.finance.expenses)],['Caixa atual',money(s.cash)]])+emNote(s.finance.partial?'O histórico anterior tinha registros parciais. O beta concilia todos os movimentos novos.':'Saldo inicial + entradas − saídas = caixa atual.','money')+'<article class="card"><h3>Movimentações</h3>'+s.ledger.slice(0,120).map(l=>'<div class="em-ledger-row"><div><b>'+esc(l.label)+'</b><small>Semana '+l.week+' · '+esc(l.category)+'</small></div><b class="'+(l.amount>0?'up':'down')+'">'+(l.amount>0?'+':'')+money(l.amount)+'</b></div>').join('')+'</article>');
 return finalCompanyBase();
};
socialPage=function(){
 const posts=s.social.posts.filter(p=>p.platform===socialNetwork),labels={tuiter:'Tuiter',istagram:'Istagram',facibuk:'Facibuk'};
 return emPage(labels[socialNetwork],'Vozes fictícias, opiniões diferentes e conversas que continuam.', '<div class="em-live-status"><span class="em-live-dot '+(s.live.mode==='online'?'online':'')+'"></span><span>'+(s.live.mode==='online'?'Universo online · servidor mantém as conversas':'Universo local · atualizado enquanto você joga e ao retornar')+'</span>'+emButton('Atualizar conversa','data-em-sync','ghost','refresh')+'</div>'+(s.live.error?emNote(s.live.error):'')+'<div class="em-social-feed">'+posts.slice(0,75).map(p=>'<article class="social-post '+(p.replyTo?'reply':'')+'"><div class="em-post-head"><span class="em-avatar">'+esc(p.user.slice(0,1).toUpperCase())+'</span><div><b>@'+esc(p.user)+'</b><small>'+esc(p.voice)+' · '+(p.at?new Date(p.at).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'Semana '+p.week)+'</small></div>'+icon(p.platform==='tuiter'?'social':p.platform==='istagram'?'eye':'team')+'</div><p>'+esc(p.text)+'</p><div class="em-post-foot"><span>'+icon('heart')+' '+compact(p.likes)+'</span><span>'+esc(p.title||'Mercado')+'</span><small>'+(p.source==='ai'?'Universo online':'Universo local')+'</small></div></article>').join('')+'</div>'+(posts.length?'':emEmpty('A conversa está começando','Estreias movimentam as redes. O universo online também cria conversas entre as sessões.')));
};
const finalJournalBase=journalPage;
journalPage=function(){return finalJournalBase().replace(/<button[^>]*data-social-report[\s\S]*?<\/button>/g,'');};
const finalAwardsScreenBase=awardsPage;
awardsPage=function(){if(subpage==='journal')return journalPage();const next=(Math.floor(s.week/12)+1)*12;return emPage('Premiações','A criatividade disputa espaço com outras produtoras.',kpis([['Troféus',s.awards.wins],['Indicações',s.awards.nominations],['Próxima gala','S'+next],['Semanas restantes',next-s.week]])+'<article class="card"><h3>'+icon('award')+' Categorias e critérios</h3>'+AWARD_CATEGORIES.map(c=>'<details><summary>'+esc(c.name)+' · '+money(c.cash)+'</summary><p>'+esc(c.event)+'</p><p>'+esc(({quality:'Qualidade 70%, crítica 30%.',story:'Criatividade, coerência e desenvolvimento do argumento.',direction:'Qualidade e técnica da direção.',acting:'Recepção do público e técnica da atuação.',voice:'Qualidade e técnica de dublagem.',public:'Recepção e alcance do público.'})[c.mode])+'</p></details>').join('')+'</article><article class="card"><h3>Histórico de galas</h3>'+s.awards.history.map(h=>'<details><summary>Edição '+h.cycle+' · semana '+h.week+'</summary>'+h.results.map(r=>'<div class="em-news"><span>'+esc(r.category)+'</span><h4>'+esc(r.winner.title)+'</h4><p>'+esc(r.winner.studio)+' · '+r.winner.score+'/100'+(r.winner.player?' · '+money(r.reward)+' recebidos':'')+'</p><small>Indicados: '+r.nominees.map(x=>esc(x.title)+' ('+x.score+')').join(', ')+'</small></div>').join('')+'</details>').join('')+(s.awards.history.length?'':emNote('Exiba uma obra para disputar a próxima edição.','award'))+'</article>');};
function storePage(){
 if(subpage==='history')return emPage('Histórico de MF','Saldo e movimentos desta conta.',kpis([['Saldo disponível',s.fameWallet.balance+' MF']])+'<article class="card">'+s.fameWallet.ledger.map(l=>'<div class="em-ledger-row"><div><b>'+esc(l.label)+'</b><small>'+new Date(l.at).toLocaleDateString('pt-BR')+'</small></div><b class="'+(l.amount>0?'up':'down')+'">'+(l.amount>0?'+':'')+l.amount+' MF</b></div>').join('')+'</article>');
 if(subpage==='exchange')return emPage('Trocas da loja','Você vê o custo antes de confirmar cada recurso.', '<div class="em-card-grid">'+MF_EXCHANGES.map((o,i)=>'<article class="card em-shop-card">'+icon('money')+'<h3>'+money(o.cash)+'</h3><p>Dinheiro da produtora</p>'+emButton('Trocar '+o.mf+' MF','data-em-exchange="'+i+'"','primary')+'</article>').join('')+'</div><h3>Powerups</h3><div class="em-card-grid">'+POWERUPS.map(key=>'<article class="card"><h3>'+esc({inspiracao:'Inspiração',audiencia:'Audiência',desconto:'Desconto'}[key])+'</h3><p>'+esc({inspiracao:'+15 pontos de qualidade na produção.',audiencia:'+40% no alcance da estreia.',desconto:'Reduz o custo conforme as regras da produção.'}[key])+'</p><button type="button" class="secondary" data-em-powerup="'+key+'" '+(s.difficulty==='director'?'disabled':'')+'>1 unidade · 6 MF</button></article>').join('')+'</div>'+(s.difficulty==='director'?emNote('Real diretor continua sem powerups.','info'):''));
 return emPage('Moeda da Fama','Um recurso especial para decisões pontuais da sua carreira.', '<div class="em-mf-hero">'+MF_ICON+'<div><span class="eyebrow">SEU SALDO</span><h2>'+s.fameWallet.balance+' <small>MF</small></h2><p>Renove a agência, troque missões ou escolha recursos.</p></div></div>'+emNote('Compras com dinheiro real estão desativadas nesta versão. Nenhuma cobrança ou compra premium pode ser concluída.','store')+'<div class="em-card-grid">'+MF_PACKS.map(p=>'<article class="card em-shop-card">'+MF_ICON+'<span class="eyebrow">'+esc(p.name)+'</span><h3>'+p.mf+' MF</h3><p>Preço e pagamento em breve</p><button type="button" class="secondary" disabled>Compra indisponível</button></article>').join('')+'</div><details><summary>Como usar e conquistar MF</summary><p>Boas-vindas: 25 MF uma vez nesta conta. Todas as missões iniciais concluídas: +30 MF uma vez. Missão diária concluída: +1 MF. Renovar a agência: '+MF_PRICES.agency+' MF. Trocar missão diária: '+MF_PRICES.mission+' MF.</p><p>As trocas de dinheiro e powerups estão na aba Trocas. O saldo acompanha a conta ao mudar de campanha.</p></details>');
}
const finalSettingsBase=settings;
settings=function(){
 if(subpage==='connection'){const c=serviceConfig();return emPage('Universo online','Conecte o servidor do jogo para análises de IA e conversas entre sessões.',c?'<article class="card"><h3>'+icon('spark')+' Conexão do universo</h3><p>Conta: '+esc(c.username)+'</p><p>Servidor: '+esc(c.url)+'</p>'+emNote(s.live.mode==='online'?'IA online disponível.':'O servidor ainda não está fornecendo IA.','spark')+'<div class="btnrow">'+emButton('Sincronizar universo','data-em-sync','primary','refresh')+emButton('Desconectar','data-em-disconnect','ghost','close')+'</div>'+(s.live.error?emNote(s.live.error):'')+'</article>':'<article class="card"><h3>Conectar sua conta do universo</h3><p>O responsável pelo jogo fornece a URL do servidor. A análise envia apenas os textos e dados criativos necessários; sua senha local e os outros perfis não são enviados.</p><form data-action="connectUniverse">'+field('Servidor do jogo','url','','url','required placeholder="https://seu-servidor"')+field('Usuário no universo','username',account.username,'text','required minlength="3" maxlength="22"')+field('Senha do universo','password','','password','required minlength="8" maxlength="128" autocomplete="current-password"')+optionSelect('Sua conta no universo','mode',[['login','Já tenho conta'],['register','Criar conta']], 'login')+'<button type="submit" class="primary">'+icon('spark')+' Conectar</button></form></article>'+emNote('Sem servidor conectado, o jogo continua no modo local. IA online e atividade com o app fechado começam após a configuração pelo responsável.','info'));}
 if(subpage==='assistant')return emPage('Vant, o assistente','Aprenda as páginas e acompanhe a sua jornada.','<article class="card em-vant-settings"><div class="vant-avatar">'+VANT_AVATAR+'</div><h3>Seu parceiro de estúdio</h3><p>'+(s.vant.completed?'Você concluiu todas as missões iniciais. Posso revisar as páginas quando quiser.':'A apresentação explica a interface; o tutorial termina depois de concluir todas as missões iniciais.')+'</p>'+emButton('Rever apresentação de Vant','data-em-vant-restart','primary','play')+'</article>');
 if(subpage==='help')return emPage('Como jogar','Regras que explicam custos, prazos e escolhas.','<article class="card">'+[
 ['Produção e tempo','A produção demora de 1 a 6 semanas pelo escopo, duração e desenvolvimento. Você paga investimento ao iniciar e salários a cada semana. Agência: 5 minutos reais; objetivos diários: 24 horas reais.'],
 ['Criatividade','No modo local há sinais do argumento e da execução. Com IA conectada, o parecer considera coerência, personagens, intenção e originalidade, com evidências. Fama ajuda no alcance, sem substituir a qualidade.'],
 ['Emissoras e concorrência','O ranking e o alcance mudam toda semana segundo audiência e qualidade. Obras ainda em produção não disputam os prêmios. Contratos assinados preservam a licença negociada.'],
 ['MF e loja','MF tem saldo próprio. Custos aparecem nos botões e no histórico. Compras com dinheiro real estão desativadas; o backend não aceita cobrança nem crédito premium.'],
 ['Universo online','O servidor guarda os resumos necessários, cria conversas periódicas e prepara novos concorrentes. Ele precisa permanecer hospedado e ter IA configurada. O jogo sincroniza ao retornar.'],
 ['Campanhas e backups','Exportar gera um JSON com sua campanha. O saldo MF permanece ao alternar campanhas; as redes e as avaliações preservam os fatos da época. Contas locais continuam isoladas por senha.']
 ].map(x=>'<details><summary>'+x[0]+'</summary><p>'+x[1]+'</p></details>').join('')+'</article>');
 return finalSettingsBase().replace('Empire TV','Empire TV').replace('1.0.0.1 BETA',EMPIRE_VERSION).replace('<button class="secondary" data-subpage="help">Ler como jogar</button>','');
};
endPage=function(){const e=currentEnd;return emPage('Fechamento da semana','A publicação respeita os cronogramas. Confira o efeito no caixa.',kpis([['Semana',s.week],['Variação do caixa',money(e?.net||0)],['Custos desta semana',money(e?.expense||0)],['Estreias',e?.reports.length||0]])+'<div class="rows">'+(e?.reports||[]).map(r=>'<article class="card"><h3>'+esc(r.show)+'</h3><p>'+compact(r.audience)+' visualizações · público '+r.viewers+'/100 · crítica '+r.critics+'/100</p>'+emButton('Abrir resultado desta produção','data-em-open-report="'+r.episodeId+'"','secondary','chart')+'</article>').join('')+'</div>'+s.shows.flatMap(sh=>sh.episodes.filter(ep=>ep.status==='produced').map(ep=>pipelineCard(sh,ep))).join('')+emNote('O investimento de produção foi pago antes. As receitas, salários, manutenção, assinaturas e recompensas deste avanço aparecem no financeiro.','money'));};
function vantOverlay(){
 if(!s.vant.touring)return '';
 const index=clamp(s.vant.index,0,VANT_STEPS.length-1),step=VANT_STEPS[index];
 return '<div class="vant-scrim" role="presentation" data-em-vant-next><div class="vant-tour" role="dialog" aria-modal="true" aria-labelledby="vant-title"><div class="vant-avatar">'+VANT_AVATAR+'</div><div class="vant-tour-text"><span class="eyebrow">VANT, O ASSISTENTE · '+(index+1)+'/'+VANT_STEPS.length+'</span><h2 id="vant-title">'+esc(step[2])+'</h2><p>'+esc(step[3])+'</p><div class="vant-tour-footer"><span>Toque para continuar</span><button type="button" class="primary" data-em-vant-next>'+(index===VANT_STEPS.length-1?'Começar minha jornada':'Próximo')+icon('arrow')+'</button></div></div></div></div>';
}
function vantDock(){if(s.vant.touring||s.vant.collapsed)return '';const next=objectiveDefs.find(o=>!s.claimed.includes(o.id));return '<aside class="vant-dock"><div class="vant-avatar">'+VANT_AVATAR+'</div><div><b>Vant</b><span>'+(next?esc(next.title)+' · '+esc(next.desc):'Missões iniciais concluídas. Vamos preparar a próxima estreia?')+'</span></div><button type="button" class="em-icon-button" data-em-vant-hide aria-label="Recolher Vant">'+icon('close')+'</button></aside>';}
const finalIntroBase=intro,finalAuthBase=authPage;
intro=function(){return finalIntroBase().replace(/EMPIRE TV/g,'EMPIRE TV').replace('Cinema e televisão · Beta',EMPIRE_VERSION);};
authPage=function(){return finalAuthBase().replace(/EMPIRE TV/g,'EMPIRE TV').replace('V&amp;D DIGITAL · BETA','V&amp;D DIGITAL · '+EMPIRE_VERSION);};
render=function(){
 if(!account){root.innerHTML=authPage();return;}
 if(!s||campaignSetup){root.innerHTML=intro();return;}
 migrateFinal(s);persistWallet();emFieldSerial=0;const rolled=ensureDaily();if(rolled)save();checkVant();if(!s.market.lastWeek)updateNetworkRanks();
 const screens={home,shows,production,reports:reportsPage,team,networks:networksPage,goals:goalsPage,company,social:socialPage,awards:awardsPage,store:storePage,settings,end:endPage};
 if(!screens[tab])tab='home';const tabs=EM_TABS[tab]||EM_TABS.home;if(tab!=='social'&&!tabs.some(t=>t[0]===subpage))subpage='';
 root.innerHTML='<div class="em-shell">'+emNavigation()+(menuOpen?'<button type="button" class="em-menu-scrim" data-em-menu aria-label="Fechar menu"></button>':'')+'<div class="em-main">'+emHeader()+emWeekbar()+'<main class="em-stage" id="empire-stage">'+screens[tab]()+rightsFooter()+'</main>'+vantDock()+pageSubnav()+'</div>'+vantOverlay()+'</div>';
 updateBetaTimers();
};
updateBetaTimers=function(){
 if(!s)return;marketEpoch();const m=root.querySelector('[data-market-timer]'),d=root.querySelector('[data-daily-timer]');
 if(m){const seconds=Math.max(0,Math.ceil((s.agency.nextAt-Date.now())/1000));m.textContent='Renova em '+Math.floor(seconds/60)+':'+String(seconds%60).padStart(2,'0');}
 if(d){const secs=Math.max(0,Math.ceil((s.daily.expiresAt-Math.max(Date.now(),s.daily.lastNow))/1000));d.textContent=Math.floor(secs/3600)+'h '+Math.floor(secs%3600/60)+'min para trocar';}
};
function showSceneLoading(label,progress=35){const el=document.querySelector('#scene-loading');if(!el)return;el.hidden=false;el.innerHTML='<div class="em-loading-card"><div class="loading-orbit">'+TV_LOGO+'</div><h2>'+esc(label)+'</h2><div class="loading-progress '+(progress<100?'working':'')+'"><span style="width:'+progress+'%"></span></div><p>'+(progress===100?'Concluído':'Processando o conteúdo. Seu progresso está preservado.')+'</p></div>';}
function hideSceneLoading(){const el=document.querySelector('#scene-loading');if(el)el.hidden=true;}
function viewportHeight(){const height=window.visualViewport?.height||window.innerHeight;if(height&&document.documentElement)document.documentElement.style.setProperty('--app-height',Math.round(height)+'px');}
window.EmpireBoot={percent:10,progress(value){const v=Math.max(this.percent,Math.min(95,value));this.percent=v;const bar=document.querySelector('#boot-progress'),label=document.querySelector('#boot-label');if(bar)bar.style.width=v+'%';if(label)label.textContent=v+'% · Preparando seu estúdio';},finish(){this.percent=100;const bar=document.querySelector('#boot-progress'),label=document.querySelector('#boot-label');if(bar)bar.style.width='100%';if(label)label.textContent='Pronto para criar';setTimeout(()=>{const boot=document.querySelector('#boot-screen');if(boot)boot.hidden=true;if(window.EmpireStartup)window.EmpireStartup.ready();},1200);}};
if(window.addEventListener){window.addEventListener('resize',viewportHeight);window.visualViewport?.addEventListener('resize',viewportHeight);}
viewportHeight();

/* Single capture layer prevents an action from being handled by two navigation systems. */
function emGo(page){if(!EM_MENU.some(m=>m[0]===page))return;tab=page;subpage='';menuOpen=false;chosenShow=null;chosenReport=null;formDefaults={};render();}
function advanceVant(){
 if(!s.vant.touring)return;
 if(s.vant.index>=VANT_STEPS.length-1){s.vant.touring=false;tab='home';subpage='';save();render();return;}
 s.vant.index++;const step=VANT_STEPS[s.vant.index];tab=step[0];subpage=s.vant.index===3?'agency':s.vant.index===5?'studio':s.vant.index===13?'assistant':'';menuOpen=false;save();render();
}
function fireEmployee(tid){const t=talentBy(tid);if(!t||!s.hired.includes(tid))return;if(!confirm('Dispensar '+t.name+'? O salário deixa de ser pago nas próximas semanas. Produções gravadas mantêm os créditos.'))return;s.hired=s.hired.filter(x=>x!==tid);delete s.assignments[tid];delete s.contracts[tid];for(const sh of s.shows)for(const r of BETA_ROLES)if(sh.team[r]===tid)delete sh.team[r];marketCache=null;log(t.name+' foi dispensado.');update();notice('Contrato encerrado.');}
root.addEventListener('click',async e=>{
 const b=e.target.closest('[data-em-nav],[data-em-menu],[data-em-sub],[data-em-work],[data-em-work-close],[data-em-work-panel],[data-em-produce],[data-em-report],[data-em-open-report],[data-em-report-panel],[data-em-report-close],[data-em-refresh-agency],[data-em-reroll],[data-em-exchange],[data-em-powerup],[data-em-analyse],[data-em-sync],[data-em-disconnect],[data-em-vant-next],[data-em-vant-hide],[data-em-vant-restart],[data-fire]');
 if(!b||!account||!s)return;e.preventDefault();e.stopImmediatePropagation();if(aiBusy)return;
 try{
  if(b.hasAttribute('data-em-nav'))emGo(b.dataset.emNav);
  else if(b.hasAttribute('data-em-menu')){menuOpen=!menuOpen;render();}
  else if(b.hasAttribute('data-em-sub')){const allowed=EM_TABS[tab]||[];if(!allowed.some(t=>t[0]===b.dataset.emSub))return;if(tab==='social')socialNetwork=b.dataset.emSub;else subpage=b.dataset.emSub;chosenShow=null;chosenReport=null;render();}
  else if(b.hasAttribute('data-em-work')){chosenShow=Number(b.dataset.emWork);workPanel='overview';render();}
  else if(b.hasAttribute('data-em-work-close')){chosenShow=null;render();}
  else if(b.hasAttribute('data-em-work-panel')){if(!['overview','writing','team','distribution','analysis'].includes(b.dataset.emWorkPanel))return;workPanel=b.dataset.emWorkPanel;render();}
  else if(b.hasAttribute('data-em-produce')){tab='production';subpage='studio';chosenShow=Number(b.dataset.emProduce);render();}
  else if(b.hasAttribute('data-em-report')||b.hasAttribute('data-em-open-report')){if(b.hasAttribute('data-em-open-report')){tab='reports';subpage='';}chosenReport=Number(b.dataset.emReport||b.dataset.emOpenReport);reportPanel='overview';render();}
  else if(b.hasAttribute('data-em-report-close')){chosenReport=null;render();}
  else if(b.hasAttribute('data-em-report-panel')){if(!['overview','creative','audience','comments','credits'].includes(b.dataset.emReportPanel))return;reportPanel=b.dataset.emReportPanel;render();}
  else if(b.hasAttribute('data-em-refresh-agency'))refreshAgency();
  else if(b.hasAttribute('data-em-reroll'))rerollMission(b.dataset.emReroll);
  else if(b.hasAttribute('data-em-exchange'))exchangeMF(b.dataset.emExchange);
  else if(b.hasAttribute('data-em-powerup'))mfPowerup(b.dataset.emPowerup);
  else if(b.hasAttribute('data-em-analyse')){await analyseWork(Number(b.dataset.emAnalyse));workPanel='analysis';render();}
  else if(b.hasAttribute('data-em-sync')){if(serviceConfig())await syncUniverse(true);else{if(addAmbientLocal(Date.now(),true))save();render();notice('Conversa local atualizada.');}}
  else if(b.hasAttribute('data-em-disconnect'))disconnectService();
  else if(b.hasAttribute('data-em-vant-next'))advanceVant();
  else if(b.hasAttribute('data-em-vant-hide')){s.vant.collapsed=true;save();render();}
  else if(b.hasAttribute('data-em-vant-restart')){s.vant.index=0;s.vant.touring=true;s.vant.collapsed=false;tab='home';subpage='';save();render();}
  else if(b.hasAttribute('data-fire'))fireEmployee(b.dataset.fire);
 }catch(error){hideSceneLoading();notice(error.message||'Não foi possível concluir a ação.',true);}
},true);
root.addEventListener('submit',async e=>{
 const form=e.target.closest('form[data-action]');if(!form||!account||!s)return;const action=form.dataset.action;
 if(!['produce','pitch','connectUniverse'].includes(action))return;
 e.preventDefault();e.stopImmediatePropagation();if(aiBusy)return;const fd=new FormData(form);
 try{
  if(action==='connectUniverse'){await connectService(fd);return;}
  const sh=showBy(fd.get('showId'));if(!sh)return;
  if(action==='pitch'){if(serviceConfig())await analyseWork(sh.id);pitch(sh.id,String(fd.get('network')));}
  else{if(serviceConfig())await analyseWork(sh.id,String(fd.get('script')||'').trim().slice(0,3500),String(fd.get('intent')||sh.intent||'').trim().slice(0,1200),true);produce(fd);}
 }catch(error){notice(error.message||'Não foi possível concluir a ação.',true);}
},true);
root.addEventListener('change',e=>{
 if(e.target.matches?.('[data-em-kind]')){const select=e.target.closest('form')?.querySelector('[data-em-duration]'),film=e.target.value==='film';if(select)select.innerHTML=(film?[60,90,120,150]:[20,30,45,60]).map(n=>'<option value="'+n+'" '+(n===(film?90:45)?'selected':'')+'>'+n+' minutos</option>').join('');return;}
 if(e.target.matches?.('[data-em-production-select]')){chosenShow=Number(e.target.value);render();return;}
});
fireTalent=fireEmployee;
const finalSequelBase=makeSequel;
makeSequel=function(ident){const before=s.shows.length;finalSequelBase(ident);if(s.shows.length>before){chosenShow=s.shows.at(-1).id;workPanel='overview';subpage='';save();render();queueUniverseSync();}};
const finalFundingBase=evaluateFunding;
evaluateFunding=async function(fd){try{const sh=showBy(fd.get('showId'));if(serviceConfig()&&sh)await analyseWork(sh.id);finalFundingBase(fd);}catch(e){notice(e.message,true);}};
const finalCreateBase=createShow;
createShow=function(fd){const before=s.shows.length;finalCreateBase(fd);if(s.shows.length===before)return;chosenShow=s.shows.at(-1).id;workPanel='overview';tab='shows';subpage='';save();render();queueUniverseSync();};
const finalEditBase=editStory;
editStory=function(fd){const sh=showBy(fd.get('showId'));if(!sh)return;const before=projectFingerprint(sh);finalEditBase(fd);if(projectFingerprint(sh)!==before){sh.aiConcept=null;sh.aiPrepared=null;save();render();queueUniverseSync();}};
const finalSafeBase=safeState;
safeState=function(v){return finalSafeBase(v)&&(!v.fameWallet||validWallet(v.fameWallet))&&(!v.market||(typeof v.market==='object'&&v.market.networks&&typeof v.market.networks==='object'));};
window.EmpireNavigation={back(){
 if(aiBusy)return true;
 if(menuOpen){menuOpen=false;render();return true;}
 if(s?.vant.touring){s.vant.touring=false;save();render();return true;}
 if(chosenReport){chosenReport=null;render();return true;}
 if(chosenShow&&tab==='shows'){chosenShow=null;render();return true;}
 if(subpage&&tab!=='social'){subpage='';render();return true;}
 if(s&&tab!=='home'){emGo('home');return true;}
 return false;
}};
if(window.addEventListener)window.addEventListener('pageshow',()=>{if(s){migrateFinal(s);if(addAmbientLocal())save();queueUniverseSync();}});

/* Empire TV beta — delegated actions; legacy account and backup handlers stay compatible. */
root.addEventListener('submit',e=>{
 const form=e.target.closest('form[data-action]');if(!form||!account||!s)return;
 const action=form.dataset.action;if(!['assignJob','assignCrew','configureNetwork','licenseWorld','pitch'].includes(action))return;
 e.preventDefault();e.stopImmediatePropagation();const fd=new FormData(form);
 if(action==='assignJob')assignJob(fd);else if(action==='assignCrew')assignCrew(fd);else if(action==='configureNetwork')configureNetwork(fd);else if(action==='licenseWorld')licenseWorld(String(fd.get('networkId')),String(fd.get('worldId')));else pitch(fd.get('showId'),String(fd.get('network')));
},true);
root.addEventListener('click',e=>{
 const b=e.target.closest('[data-toggle-menu],[data-beta-nav],[data-tab],[data-subpage],[data-agency-filter],[data-network-filter],[data-social-network],[data-sequel],[data-claim-daily],[data-network-upgrade],[data-social-report]');
 if(!b||!account||!s)return;e.preventDefault();e.stopImmediatePropagation();
 if(b.hasAttribute('data-toggle-menu')){
  menuOpen=!menuOpen;const panel=root.querySelector('#beta-menu');if(panel)panel.hidden=!menuOpen;b.setAttribute('aria-expanded',String(menuOpen));return;
 }
 if(b.hasAttribute('data-beta-nav')||b.hasAttribute('data-tab')){tab=b.dataset.betaNav||b.dataset.tab;subpage='';menuOpen=false;formDefaults={};render();window.scrollTo(0,0);}
 else if(b.hasAttribute('data-subpage')){if(tab==='social')socialNetwork=b.dataset.subpage;else subpage=b.dataset.subpage;render();window.scrollTo(0,0);}
 else if(b.hasAttribute('data-agency-filter')){agencyFilter=b.dataset.agencyFilter;render();}
 else if(b.hasAttribute('data-network-filter')){networkFilter=b.dataset.networkFilter;render();}
 else if(b.hasAttribute('data-social-network')){socialNetwork=b.dataset.socialNetwork;render();window.scrollTo(0,0);}
 else if(b.dataset.sequel)makeSequel(b.dataset.sequel);
 else if(b.dataset.claimDaily)claimDaily(b.dataset.claimDaily);
 else if(b.dataset.networkUpgrade)upgradeNetwork(b.dataset.networkUpgrade,b.dataset.key);
 else if(b.dataset.socialReport){tab='shows';subpage='';formDefaults.history=+b.dataset.socialReport;render();const target=root.querySelector('#report-'+showBy(b.dataset.socialReport)?.episodes.filter(e=>e.status==='aired').at(-1)?.id);if(target)target.scrollIntoView({behavior:'smooth',block:'start'});else window.scrollTo(0,0);}
},true);
root.addEventListener('click',e=>{if(!menuOpen||e.target.closest('.beta-nav,.menu-trigger'))return;menuOpen=false;const panel=root.querySelector('#beta-menu'),button=root.querySelector('[data-toggle-menu]');if(panel)panel.hidden=true;if(button)button.setAttribute('aria-expanded','false');});
root.addEventListener('keydown',e=>{if(e.key!=='Escape'||!menuOpen)return;menuOpen=false;const panel=root.querySelector('#beta-menu'),button=root.querySelector('[data-toggle-menu]');if(panel)panel.hidden=true;if(button){button.setAttribute('aria-expanded','false');button.focus();}});
root.addEventListener('change',e=>{
 if(e.target.name==='actor'){const form=e.target.closest('form'),sh=showBy(form?.dataset.preview);if(sh){const credits=crewSnapshot(sh,e.target.value),panel=root.querySelector('[data-crew-preview="'+sh.id+'"]');if(panel)panel.innerHTML='<b>Impacto previsto da equipe</b><p>Fama: +'+Math.round((fameMultiplier(credits)-1)*100)+'% no alcance potencial.</p><p>'+credits.map(c=>esc(c.role)+': <b>'+esc(c.name)+'</b> · '+c.technique+' técnica, '+c.fame+' fama').join('<br>')+'</p>';}}
 if(!e.target.matches('[data-pitch-preview]'))return;const sh=showBy(e.target.dataset.pitchPreview),n=networkBy(e.target.value),form=e.target.closest('form');if(!sh||!n||!form)return;
 const p=pitchPreview(sh,n),info=form.querySelector('[data-pitch-info]');if(info)info.textContent=n.name+': '+p.why+' Chance '+p.chance+'%. Licença '+money(p.fee)+(isFilm(sh)?' pelo filme.':' por episódio.');
});
setInterval(()=>{
 if(!s||!account||campaignSetup)return;updateBetaTimers();if(tab==='goals'&&ensureDaily()){save();render();}
},1000);
const betaSafeStateBase=safeState;
safeState=function(v){return betaSafeStateBase(v)&&Number.isFinite(v.week)&&v.week>=1&&Number.isFinite(v.level)&&v.level>=1&&v.upgrades&&typeof v.upgrades==='object'&&Array.isArray(v.ledger)&&Array.isArray(v.feed)&&Array.isArray(v.history)&&v.boosts&&v.shows.every(sh=>sh&&typeof sh.name==='string'&&Number.isFinite(sh.id)&&genres.includes(sh.genre)&&Array.isArray(sh.episodes)&&sh.episodes.every(ep=>ep&&Number.isFinite(ep.id)&&Number.isFinite(ep.budget)&&['produced','aired'].includes(ep.status)));};
importBackup=function(file){if(!file)return;const reader=new FileReader();reader.onload=()=>{
 try{const state=JSON.parse(reader.result);if(!safeState(state))throw Error('Formato inválido');if(!confirm('Substituir a campanha desta conta pelo backup importado?'))return;
  migrateBeta(state);s=state;tab='home';subpage='';menuOpen=false;campaignSetup=false;currentEnd=null;save();render();notice('Backup importado. Patrimônio, equipe e exibições preservados.');
 }catch(error){notice('Arquivo inválido. Escolha um backup JSON exportado pelo jogo.',true);}
};reader.readAsText(file);};


root.addEventListener('submit',e=>{let form=e.target.closest('form[data-action]');if(!form)return;e.preventDefault();let data=new FormData(form),action=form.dataset.action;
if(action==='auth'){accountSubmit(data,authView);return}
if(action==='cloudConfig'){try{updateCloudConfig(data)}catch(e){notice(uiError(e),true)}return}
if(!account)return;
switch(action){case'start':startGame(String(data.get('name')||''));break;case'createShow':createShow(data);break;case'produce':produce(data);break;case'schedule':scheduleShow(data);break;case'boost':assignBoost(data);break;}});
root.addEventListener('click',async e=>{
const b=e.target.closest('button[data-auth-view],button[data-provider],button[data-visibility],[data-cloud-setup],[data-logout],[data-legacy],[data-sync],[data-tab],[data-next-week],[data-pitch],[data-hire],[data-renew],[data-end],[data-history],[data-produce-tab],[data-upgrade],[data-open-network],[data-pause-network],[data-export],[data-reset]');if(!b)return;
if(b.dataset.authView){authView=b.dataset.authView;render();return}
if(b.dataset.provider){authMode=b.dataset.provider;render();return}
if(b.hasAttribute('data-visibility')){let p=document.querySelector('#auth-pass');if(p){p.type=p.type==='password'?'text':'password';b.textContent=p.type==='password'?'Mostrar':'Ocultar'}return}
if(b.hasAttribute('data-cloud-setup')){cloudSetupOpen=!cloudSetupOpen;render();return}
if(b.hasAttribute('data-logout')){await signOut();return}
if(b.hasAttribute('data-legacy')){await importLegacy();return}
if(b.hasAttribute('data-sync')){save();await saveChain;render();notice(syncStatus==='cloud'?'Progresso sincronizado!':'Sincronização pendente. Verifique a internet.',syncStatus!=='cloud');return}
if(!account||!s)return;
if(b.dataset.tab){tab=b.dataset.tab;formDefaults={};render();window.scrollTo(0,0)}
else if(b.hasAttribute('data-next-week')){nextWeek();window.scrollTo(0,0)}
else if(b.dataset.pitch){pitch(b.dataset.pitch,b.dataset.network)}
else if(b.dataset.hire){hireTalent(b.dataset.hire)}
else if(b.dataset.renew){renew(b.dataset.renew)}
else if(b.dataset.end){if(confirm('Finalizar esta obra? Você poderá desenvolver uma continuação.'))endShow(b.dataset.end)}
else if(b.dataset.history){let ident=+b.dataset.history;formDefaults.history=formDefaults.history===ident?0:ident;render()}
else if(b.dataset.produceTab){tab='production';render();let target=document.querySelector('#production-'+b.dataset.produceTab);if(target)target.scrollIntoView({behavior:'smooth',block:'start'})}
else if(b.dataset.upgrade){upgrade(b.dataset.upgrade)}
else if(b.dataset.openNetwork){openNetwork(b.dataset.openNetwork)}
else if(b.dataset.pauseNetwork){toggleNetwork(b.dataset.pauseNetwork)}
else if(b.hasAttribute('data-export')){doExport()}
else if(b.hasAttribute('data-reset')){
 if(confirm('Apagar o progresso DESTA conta? Outros perfis não serão afetados. Faça um backup antes.')){
  await saveChain.catch(()=>{});
  if(account.type==='cloud')try{await cloudFetch('/rest/v1/game_saves?user_id=eq.'+encodeURIComponent(account.id),'DELETE')}catch(e){notice('Não foi possível apagar os dados na nuvem: '+uiError(e),true);return}
  try{localStorage.removeItem(STORAGE_PREFIX+(account.type==='cloud'?'cloud_':'')+account.id)}catch(e){}
  s=null;tab='home';currentEnd=null;render();notice('Seu jogo foi reiniciado. A conta permanece ativa.');
 }
}
});
root.addEventListener('change',e=>{if(e.target.id==='importSave'){importBackup(e.target.files?.[0])}});
render();
window.EmpireBoot.progress(70);
Promise.resolve(openPlayerDatabase()).then(()=>{window.EmpireBoot.progress(95);render();window.EmpireBoot.finish();if(s)queueUniverseSync();}).catch(()=>window.EmpireBoot.finish());

})();
