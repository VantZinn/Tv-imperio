/* Empire TV 1.0.0.1 BETA — campaign mechanics; purchased currency is disabled. */
const EMPIRE_VERSION='1.0.0.1 BETA';
const BASE_NETWORK_META=networks.map(n=>({...n,focus:n.focus.slice()}));
let chosenShow=null,chosenReport=null,workPanel='overview',reportPanel='overview',aiBusy=false;
const MF_PRICES={agency:8,mission:3};
const MF_EXCHANGES=[{mf:5,cash:10000},{mf:20,cash:45000},{mf:50,cash:120000}];
const MF_PACKS=[{id:'starter',mf:60,name:'Primeira estrela'},{id:'studio',mf:180,name:'Estúdio em ascensão'},{id:'empire',mf:450,name:'Império da fama'}];
function walletKey(){return 'empire-mf-'+(account?.id||'guest');}
function savedWallet(){try{return JSON.parse(localStorage.getItem(walletKey())||'null');}catch{return null;}}
function validWallet(w){return w&&Number.isSafeInteger(w.balance)&&w.balance>=0&&Array.isArray(w.ledger)&&w.rewarded&&typeof w.rewarded==='object';}
function persistWallet(){try{localStorage.setItem(walletKey(),JSON.stringify(s.fameWallet));}catch{}}
function migrateFinal(state){
 if(!state)return state;migrateBeta(state);
 if(!validWallet(state.fameWallet)){const cached=savedWallet();state.fameWallet=validWallet(cached)?cached:{balance:25,ledger:[{id:'welcome',amount:25,label:'Boas-vindas ao Empire TV',at:Date.now()}],rewarded:{welcome:true},serial:1};}
 state.schema=5;state.build=EMPIRE_VERSION;
 state.agency=state.agency||{ticket:0,nextAt:Math.floor(Date.now()/300000)*300000+300000,baseEpoch:Math.floor(Date.now()/300000)};
 state.agency.baseEpoch=Number.isSafeInteger(state.agency.baseEpoch)?state.agency.baseEpoch:Math.floor(Date.now()/300000);
 state.vant=state.vant||{index:0,touring:!objectiveDefs.every(o=>state.claimed.includes(o.id)),completed:false,collapsed:false};
 state.market=state.market||{lastWeek:0,networks:{},history:[]};
 state.live=state.live||{lastLocalAt:Date.now(),lastSyncAt:0,serverCursor:0,importedWorks:[],mode:'local',error:'',worldSerial:0};
 state.live.aiStatus=state.live.aiStatus||null;state.live.lastAIAt=Number.isFinite(state.live.lastAIAt)?state.live.lastAIAt:0;
 state.prestige=state.prestige&&typeof state.prestige==='object'?state.prestige:{claimed:{}};state.prestige.claimed=state.prestige.claimed&&typeof state.prestige.claimed==='object'?state.prestige.claimed:{};
 state.shows.forEach(sh=>{sh.aiConcept=sh.aiConcept||null;sh.aiPrepared=sh.aiPrepared||null;sh.episodes.forEach(ep=>{if(ep.status==='produced'&&!ep.production)ep.production={weeks:Math.max(1,Math.min(6,ep.airWeek-ep.producedWeek)),startedWeek:ep.producedWeek,releaseWeek:ep.airWeek,legacy:true};});});
 applyNetworkState(state);
 return state;
}
function applyNetworkState(state){
 BASE_NETWORK_META.forEach(base=>{const n=networks.find(n=>n.id===base.id),saved=state.market.networks[base.id];Object.assign(n,base,saved||{});n.focus=base.focus.slice();});
}
const finalFreshBase=fresh;
fresh=function(name,difficulty){BASE_NETWORK_META.forEach(base=>Object.assign(networks.find(n=>n.id===base.id),base));return migrateFinal(finalFreshBase(name,difficulty));};
const finalStartBase=startGame,finalResumeBase=resumeCampaign;
startGame=function(name,difficulty){const wallet=s?.fameWallet?JSON.parse(JSON.stringify(s.fameWallet)):savedWallet();finalStartBase(name,difficulty);if(!s)return;migrateFinal(s);if(validWallet(wallet))s.fameWallet=wallet;persistWallet();chosenShow=null;chosenReport=null;subpage='';save();render();};
resumeCampaign=function(cid){const wallet=JSON.parse(JSON.stringify(s.fameWallet));finalResumeBase(cid);migrateFinal(s);s.fameWallet=wallet;persistWallet();chosenShow=null;chosenReport=null;subpage='';save();render();};
function walletChange(amount,label,receipt){
 if(!Number.isSafeInteger(amount)||!amount)return false;
 migrateFinal(s);if(receipt&&s.fameWallet.rewarded[receipt])return false;
 if(s.fameWallet.balance+amount<0)return false;
 s.fameWallet.balance+=amount;s.fameWallet.serial=(s.fameWallet.serial||0)+1;
 s.fameWallet.ledger.unshift({id:s.fameWallet.serial,amount,label,at:Date.now(),receipt:receipt||null});s.fameWallet.ledger=s.fameWallet.ledger.slice(0,500);
 if(receipt)s.fameWallet.rewarded[receipt]=true;persistWallet();return true;
}
function mfSpend(cost,label){if(!Number.isSafeInteger(cost)||cost<=0)return false;if(!walletChange(-cost,label))return notice('Você precisa de '+cost+' MF para esta ação.',true),false;return true;}
function exchangeMF(index){if(s.difficulty==='director'&&!s.grantTaken)return notice('No Real diretor, obtenha o primeiro financiamento antes de trocar MF por verba.',true);const offer=MF_EXCHANGES[Number(index)];if(!offer||!mfSpend(offer.mf,'Troca por '+money(offer.cash)))return;changeCash(offer.cash,'Troca de Moeda da Fama','Moeda da Fama');update();notice(money(offer.cash)+' adicionados ao caixa da produtora.');}
function mfPowerup(key){if(!POWERUPS.includes(key)||s.difficulty==='director')return notice('Real diretor não usa powerups.',true);if(!mfSpend(6,'Powerup: '+key))return;s.boosts[key]++;update();notice('Powerup adicionado ao inventário.');}
const finalMarketEpochBase=marketEpoch;
marketEpoch=function(now=Date.now()){
 if(!s?.agency)return finalMarketEpochBase(now);
 if(now>=s.agency.nextAt){const steps=Math.floor((now-s.agency.nextAt)/300000)+1;s.agency.nextAt+=steps*300000;s.agency.baseEpoch+=steps;}
 return s.agency.baseEpoch+(s.agency.ticket||0)*1000003;
};
function refreshAgency(){if(!mfSpend(MF_PRICES.agency,'Renovação imediata da agência'))return;s.agency.ticket++;s.agency.nextAt=Date.now()+300000;marketCache=null;update();notice('Nova rodada: quatro candidatos por profissão.');}
const finalDailyValueBase=dailyValue;
dailyValue=function(o){
 const task=s.daily.tasks?.find(t=>t.id===o.id);
 if(!task?.baseline)return finalDailyValueBase(o);
 if(o.metric==='genres'){const before=new Set(task.genres||[]);return new Set(s.shows.flatMap(sh=>sh.episodes.some(e=>e.status==='aired'&&e.airWeek>=task.fromWeek)?[sh.genre]:[]).filter(g=>!before.has(g))).size;}
 return Math.max(0,(metricTotals()[o.metric]||0)-(task.baseline[o.metric]||0));
};
function rerollMission(oid){
 ensureDaily();const task=s.daily.tasks.find(t=>t.id===oid),old=DAILY_OBJECTIVES.find(o=>o.id===oid);
 if(!task||task.claimed||!old||dailyValue(old)>=old.goal)return notice('Somente missões diárias em andamento podem ser trocadas.',true);
 const others=new Set(s.daily.tasks.map(t=>t.id)),pool=DAILY_OBJECTIVES.filter(o=>o.tier===old.tier&&!others.has(o.id)&&dailyEligible(o));
 if(!pool.length)return notice('Nenhuma missão equivalente está disponível.',true);
 if(!mfSpend(MF_PRICES.mission,'Troca de missão diária'))return;
 const serial=(s.daily.rerolls||0)+1;s.daily.rerolls=serial;
 const rng=seeded(s.campaignId+'mission'+s.daily.cycle+serial),replacement=pick(rng,pool);
 Object.assign(task,{id:replacement.id,claimed:false,baseline:metricTotals(),genres:[...new Set(s.shows.filter(sh=>sh.episodes.some(e=>e.status==='aired')).map(sh=>sh.genre))],fromWeek:s.week+1,rerolls:(task.rerolls||0)+1});
 update();notice('Nova missão de dificuldade equivalente. O progresso dela começa agora.');
}
const finalClaimDailyBase=claimDaily;
claimDaily=function(oid){const cycle=s.daily.cycle;finalClaimDailyBase(oid);const item=s.daily.tasks.find(t=>t.id===oid),o=DAILY_OBJECTIVES.find(o=>o.id===oid);if(item?.claimed&&walletChange(dailyMF(o),'Missão diária concluída',s.campaignId+':daily:'+cycle+':'+oid)){save();render();rewardBurst(dailyMF(o),s.difficulty==='director'?0:o.boostCount,o.title);}};
function checkVant(){
 if(!s?.vant)return;
 const completed=objectiveDefs.every(o=>s.claimed.includes(o.id));
 if(completed&&!s.vant.completed){s.vant.completed=true;s.vant.touring=false;const granted=walletChange(30,'Tutorial de Vant concluído','vant-primary-complete');save();notice('Tutorial concluído! Vant continua disponível.'+(granted?' +30 MF.':' A recompensa em MF desta conta já foi recebida.'));}
}
function projectFingerprint(sh,script='',intent=sh.intent){return String(hashText(JSON.stringify({title:sh.name,kind:sh.kind,genre:sh.genre,duration:sh.duration,concept:sh.concept,story:sh.story,intent,script})));}
function currentConceptAI(sh){return sh.aiConcept?.fingerprint===projectFingerprint(sh)&&validAIReview(sh.aiConcept)?sh.aiConcept:null;}
function aiNarrative(review){const q=review?.scores;if(!q)return null;return Math.round(q.originality*.28+q.coherence*.27+q.characters*.2+q.impact*.25);}
const finalPlotBase=plotFactors;
plotFactors=function(sh,script=''){
 const fs=finalPlotBase(sh,script),review=currentConceptAI(sh);if(!review)return fs;
 const q=review.scores,byKey={premise:q.impact,motivation:q.characters,conflict:q.coherence,payoff:q.impact,causality:q.coherence,development:q.coherence,originality:q.originality};
 return fs.map(f=>{const risk=review.risks.find(r=>norm(r.aspect).includes(norm(f.label).split(' ')[0]));return {...f,score:byKey[f.key]??f.score,evidence:review.summary+(risk?' '+risk.evidence:''),advice:risk?.advice||review.strengths[0]||f.advice};});
};
const finalCreativeBase=creativeQuality;
creativeQuality=function(sh,ep){
 const review=ep.aiReview;if(!review)return finalCreativeBase(sh,ep);
 const narrative=aiNarrative(review),technical=weighted(ep.analysis.filter(f=>['budget','crew','voice'].includes(f.key)));
 return Math.round(clamp(narrative*.68+technical*.2+review.scores.execution*.12+(s.upgrades.roteiro||0)+(s.upgrades.edicao||0)+ep.qualityBoost,5,100));
};
function productionPlan(sh,script='',intent=sh.intent,review=null){
 const chars=[sh.concept,...Object.values(sh.story||{}),script,intent].join(' ').length;
 const complexity=Math.min(2,Math.floor(chars/1800));
 const length=sh.duration>=120?2:sh.duration>=60?1:0;
 const demanding=['Ficção científica','Fantasia','Animação'].includes(sh.genre)?1:0;
 const local=2+complexity+length+demanding;
 const proposed=review?.productionWeeks||local;
 const support=s.upgrades.edicao>=3&&s.upgrades.filmagem>=3?1:0;
 const weeks=clamp(Math.round(Math.max(local-1,proposed)-support),1,6);
 return{weeks,chars,startedWeek:s.week,releaseWeek:s.week+weeks,stages:['Pré-produção','Gravação','Montagem','Som e acabamento','Revisão final','Estreia'].slice(0,weeks),reason:'Duração '+sh.duration+' min, '+chars+' caracteres de desenvolvimento'+(demanding?', gênero com maior execução técnica':'')+(support?', equipe de estúdio reduz uma semana':'')+'.'};
}
const finalProduceBase=produce;
produce=function(fd){
 const sh=showBy(fd.get('showId'));if(!sh)return;
 const script=String(fd.get('script')||'').trim().slice(0,3500),intent=String(fd.get('intent')||sh.intent||'').trim().slice(0,1200);
 const prepared=sh.aiPrepared?.fingerprint===projectFingerprint(sh,script,intent)&&validAIReview(sh.aiPrepared)?sh.aiPrepared:null;
 const before=sh.episodes.length;finalProduceBase(fd);if(sh.episodes.length===before)return;
 const ep=sh.episodes.at(-1);ep.aiReview=prepared;ep.production=productionPlan(sh,script,intent,prepared);ep.airWeek=ep.production.releaseWeek;
 if(prepared){ep.analysis=ep.analysis.map(f=>{const score={premise:prepared.scores.impact,motivation:prepared.scores.characters,conflict:prepared.scores.coherence,payoff:prepared.scores.impact,causality:prepared.scores.coherence,development:prepared.scores.coherence,originality:prepared.scores.originality}[f.key];return score===undefined?f:{...f,score,evidence:prepared.summary,advice:prepared.risks.find(r=>norm(r.aspect).includes(norm(f.label).split(' ')[0]))?.advice||prepared.strengths[0]||f.advice};});ep.quality=creativeQuality(sh,ep);}
 log(sh.name+': produção de '+ep.production.weeks+' semana(s), estreia prevista para a semana '+ep.airWeek+'.');save();render();notice('Produção iniciada. Estreia prevista: semana '+ep.airWeek+'.');
};
const finalAirBase=airEpisode;
airEpisode=function(sh,ep){if(ep.status==='produced'&&s.week<ep.airWeek)return null;return finalAirBase(sh,ep);};
const finalPitchPreviewBase=pitchPreview;
pitchPreview=function(sh,n){
 const p=finalPitchPreviewBase(sh,n),own=s.networks.some(x=>x.id===n.id),penalty=s.difficulty==='easy'?0:s.difficulty==='medium'?7:s.difficulty==='hard'?12:15;
 const chance=own?100:Math.round(clamp(p.chance-penalty,2,98));
 return {...p,chance,why:p.why+' '+(currentConceptAI(sh)?'Parecer de IA aplicado.':'Parecer local aplicado.')+' '+(own?'': 'Rigor da campanha: −'+penalty+' pontos na chance.')};
};
function updateNetworkRanks(){
 if(s.market.lastWeek===s.week)return;
 const aggregate=networks.map(n=>{const rivals=s.world.filter(w=>w.networkId===n.id&&w.status==='active'),ours=s.shows.filter(sh=>sh.networkId===n.id).flatMap(sh=>sh.episodes.filter(ep=>ep.status==='aired'&&ep.airWeek===s.week)),all=rivals.map(w=>({views:w.viewers,quality:w.quality})).concat(ours.map(ep=>({views:ep.viewership,quality:ep.quality})));return{n,views:all.reduce((v,x)=>v+x.views,0),quality:all.length?all.reduce((v,x)=>v+x.quality,0)/all.length:45,count:all.length};});
 const max=Math.max(1,...aggregate.map(x=>x.views));
 aggregate.forEach(x=>x.score=Math.round(x.views/max*45+x.quality*.5+Math.min(5,x.count)));
 aggregate.sort((a,b)=>b.score-a.score||b.n.reach-a.n.reach);
 aggregate.forEach((x,i)=>{const base=BASE_NETWORK_META.find(n=>n.id===x.n.id),prior=s.market.networks[x.n.id],movement=prior?clamp((x.score-prior.score)/700,-.04,.04):0,reach=Math.round(clamp((prior?.reach||base.reach)*(1+movement),base.reach*.7,base.reach*1.5)*100)/100;const snapshot={rank:i+1,previousRank:prior?.rank||i+1,score:x.score,reach,threshold:Math.round(clamp(base.threshold+(reach/base.reach-1)*12,30,98)),weeklyViews:x.views,quality:Math.round(x.quality),delta:Math.round((reach-(prior?.reach||base.reach))*100)/100};s.market.networks[x.n.id]=snapshot;Object.assign(x.n,snapshot);});
 s.market.lastWeek=s.week;s.market.history.unshift({week:s.week,top:aggregate.slice(0,5).map(x=>({id:x.n.id,name:x.n.name,score:x.score,reach:x.n.reach}))});s.market.history=s.market.history.slice(0,100);
}
const LOCAL_WORLD_WORDS=[['A Cidade','O Arquivo','A Última','O Retrato','A Casa','Os Filhos','O Jardim','A Ponte','O Código','As Vozes'],['de Sal','do Amanhã','da Lua','das Marés','Sem Nome','de Outubro','dos Ecos','de Vidro','da Noite','do Norte']];
function addProceduralRival(){
 const serial=++s.live.worldSerial,rng=seeded(s.campaignId+'newworld'+serial),n=pick(rng,networks),genre=pick(rng,n.focus);
 let title=pick(rng,LOCAL_WORLD_WORDS[0])+' '+pick(rng,LOCAL_WORLD_WORDS[1]);
 if(s.world.some(w=>w.name===title))title+=': '+['Retorno','Segredo','Fronteira','Recomeço'][serial%4]+' '+serial;
 const weeks=2+Math.floor(rng()*5),quality=50+Math.floor(rng()*44),eligible=networks.filter(x=>x.threshold<=quality).sort((a,b)=>Number(b.focus.includes(genre))-Number(a.focus.includes(genre))||b.reach-a.reach),publisher=eligible[0]||n;
 s.world.push({id:'newworld'+s.campaignId+serial,name:title,kind:rng()>.55?'film':'series',genre,networkId:publisher.id,studio:pick(rng,WORLD_STUDIOS),quality,viewers:0,status:'production',season:1,episode:0,debutWeek:s.week+weeks,updatedWeek:s.week,history:[],productionWeeks:weeks,source:'procedural',premise:'Um novo projeto de '+genre+' anunciado por outra produtora.'});
 s.world=s.world.slice(-120);addNews('Nova produção no mercado',title+' começa uma produção de '+weeks+' semanas em '+publisher.name+'.','Mercado');
}
const finalAdvanceWorldBase=advanceWorld;
advanceWorld=function(){
 const pending=s.world.filter(w=>w.status==='production');s.world=s.world.filter(w=>w.status!=='production');finalAdvanceWorldBase();s.world=s.world.concat(pending);
 for(const w of pending)if(w.debutWeek<=s.week){w.status='active';w.episode=1;w.viewers=Math.round((200000+w.quality*8500)*networkBy(w.networkId).reach);addNews('Estreia concorrente',w.name+' estreou em '+networkBy(w.networkId).name+'.','Mercado');}
 if(s.week%3===0)addProceduralRival();
};
const finalAwardsBase=runAwards;
runAwards=function(){const all=s.world;s.world=all.filter(w=>w.status==='active'&&w.debutWeek<=s.week);try{return finalAwardsBase();}finally{s.world=all;}};
const finalNextWeekBase=nextWeek;
nextWeek=function(){if(aiBusy)return notice('Aguarde o parecer em andamento.',true);const before=s.week;finalNextWeekBase();if(s.week===before)return;updateNetworkRanks();checkVant();save();render();queueUniverseSync();};
const finalCommentBase=commentThread;
commentThread=function(sh,ep,fs,rng){
 const narrative=fs.filter(f=>f.key==='conflict'||f.key==='payoff'||f.key==='originality'),comments=[];
 const reviews=ep.aiReview?.comments||[],lead=ep.actorName||'o elenco',detail=shortText(sh.story.conflict,145),consequence=shortText(sh.story.payoff,145),strong=ep.viewers>=80;
 const opinions=strong?[
 ['Jovem','EU FIQUEI EM PÉ NO FINAL. '+sh.name+' me ganhou pela ideia de '+shortText(sh.concept,100)+'.'],
 ['Adulto','O conflito de '+sh.name+' funciona porque existe um custo para a escolha: '+detail],
 ['Senhor','Assisti a '+sh.name+' com calma. Gostei de como o projeto coloca a decisão do personagem antes do espetáculo. '+consequence],
 ['Jovem','CARACA, '+lead+' em '+sh.name+'! Entrei pelo elenco e fiquei pela história. Já tô indicando.'],
 ['Adulto','A equipe encontrou uma identidade nesta produção: '+shortText(ep.intent||sh.intent,150)+'.'],
 ['Senhor','Não vejo motivo para esconder meu entusiasmo com '+sh.name+'. Esta proposta de '+sh.genre+' tem personalidade.']
 ]:[
 ['Jovem','Queria MUITO gostar de '+sh.name+', mas travei nesta parte do conflito: '+detail+'. Faltou conectar isso ao objetivo.'],
 ['Adulto','A ideia de '+sh.name+' tem potencial. Minha dificuldade foi entender o preço da escolha: '+consequence+'.'],
 ['Senhor','Eu daria outra chance a '+sh.name+'. O ponto de partida chama a atenção; o desenvolvimento poderia explicar melhor as decisões.'],
 ['Jovem',lead+' me trouxe pra '+sh.name+', só que elenco sozinho não resolve um conflito mal explicado.'],
 ['Adulto','Vale revisar a execução de '+sh.name+' junto desta intenção: '+shortText(ep.intent||sh.intent,130)+'.'],
 ['Senhor','Prefiro uma história pequena e clara a uma produção que corre demais. '+sh.name+' pode encontrar esse equilíbrio.']
 ];
 reviews.forEach((c,i)=>comments.push({id:'ai'+ep.id+'_'+i,name:c.name,role:c.role||'Fã',voice:c.ageGroup,parent:c.replyTo>=0&&c.replyTo<i?'ai'+ep.id+'_'+c.replyTo:null,text:c.text,source:'ai'}));
 opinions.forEach((p,i)=>comments.push({id:'local'+ep.id+'_'+i,name:SOCIAL_NAMES[(i+ep.number*3)%SOCIAL_NAMES.length],role:i===1?'Crítico':'Fã',voice:p[0],parent:null,text:p[1],source:'local'}));
 narrative.forEach((f,i)=>comments.push({id:'craft'+ep.id+'_'+i,name:['Lara no Cinema','Seu Artur','Marina Debate'][i],role:'Crítico',voice:['Adulto','Senhor','Jovem'][i],parent:null,text:sh.name+' · '+f.label+': '+shortText(f.evidence,190)+' Minha sugestão: '+f.advice,source:'local'}));
 if(s.difficulty==='director')for(let i=0;i<6;i++){const parent=comments[i%comments.length];comments.push({id:'reply'+ep.id+'_'+i,name:SOCIAL_NAMES[(i+11)%SOCIAL_NAMES.length],role:'Fã',voice:SOCIAL_VOICES[i%3],parent:parent.id,text:'@'+parent.name+' '+(i%2?'Eu entendi diferente: ':'Concordo no ponto da execução. ')+shortText(narrative[i%Math.max(1,narrative.length)]?.advice||sh.intent,170)+' '+sh.name+' merece uma discussão com esses detalhes.',source:'local'});}
 const used=new Set();return comments.filter(c=>{if(used.has(c.text))return false;used.add(c.text);return true;});
};
function addAmbientLocal(now=Date.now(),force=false){
 if(!s)return false;const elapsed=Math.max(0,now-s.live.lastLocalAt),count=force?1:Math.min(24,Math.floor(elapsed/300000));if(!count)return false;
 for(let i=0;i<count;i++){
  const serial=++s.social.serial,at=force?now:s.live.lastLocalAt+(i+1)*300000,rng=seeded(s.campaignId+'ambient'+serial),own=s.shows.filter(sh=>sh.episodes.some(ep=>ep.status==='aired'));
  const sh=own.length&&rng()>.35?pick(rng,own):null,w=sh?null:pick(rng,s.world.filter(w=>w.status==='active'));
  if(!sh&&!w)continue;const ep=sh?.episodes.filter(e=>e.status==='aired').at(-1),title=sh?.name||w.name,voice=SOCIAL_VOICES[serial%3],famous=ep?.actorName;
  const text=sh?pick(rng,[
    title+' voltou na conversa aqui em casa. '+shortText(sh.story.conflict,155)+'. Essa escolha ainda rende assunto.',
    (famous?'Fui assistir por '+famous+'. ':'')+'Agora tô pensando na ideia de '+title+': '+shortText(sh.concept,145)+'.',
    'Quero ler outras interpretações de '+title+'. '+shortText(sh.intent,150)+'. Alguém entendeu essa intenção de outro jeito?',
    'Meu debate de hoje sobre '+title+': '+shortText(sh.story.payoff,155)+'. O que vocês mudariam nessa consequência?',
    'Reassistindo '+title+' e pensando no comentário da galera sobre '+sh.genre+'. Público '+ep.viewers+'/100, mas minha opinião tem nuances.'
  ]):pick(rng,[
    'Alguém tá acompanhando '+title+' na '+networkBy(w.networkId).name+'? O catálogo de '+w.genre+' chamou minha atenção.',
    title+' entrou no meu radar: '+w.quality+'/100 na crítica do mercado. Vou comparar com os próximos lançamentos.',
    'A próxima disputa de prêmios vai ter '+title+'? Quero ver o que '+w.studio+' preparou.'
  ]);
  const key=hashText(text);if(s.social.used[key])continue;s.social.used[key]=true;
  s.social.posts.unshift({id:'ambient'+serial,platform:['tuiter','istagram','facibuk'][serial%3],user:pick(rng,SOCIAL_NAMES).replace(/\s/g,'_'),voice,week:s.week,title,text,likes:Math.round(rng()*(sh?Math.max(25,sh.fanBase*.015):250)),replyTo:null,showId:sh?.id||null,at,source:'local'});
 }
 s.live.lastLocalAt=now;s.social.posts=s.social.posts.slice(0,600);return true;
}
