# TV Empire — beta 1.0.0

O jogo agora usa a marca TV Empire, com uma televisão e uma coroa no ícone. Cada página exibe somente os direitos da V&D Digital no rodapé institucional. O menu superior esquerdo abre as áreas do jogo; a barra inferior muda conforme a área escolhida.

## O que foi implementado

- **Equipe e Agência:** cargos editáveis, especialidades, salários e capacidade de contratação. A agência apresenta quatro candidatos de cada uma das seis formações, totalizando 24, e muda a cada cinco minutos reais. A chance exibida corresponde à probabilidade de inclusão no ciclo atual. Contratações permanecem na equipe. Os 100 talentos principais são personagens com nomes humorísticos; aprendizes entram quando faltam candidatos de uma formação.
- **Emissoras:** 40 redes, com público, alcance, exigência, remuneração e preferência de gêneros. A proposta considera a qualidade e o alcance; obras fortes conseguem superar parte da barreira de fama. O universo tem 40 obras concorrentes, que evoluem ao avançar as semanas do jogo.
- **Minhas emissoras:** abertura de TV ou streaming, nome, slogan, foco editorial, investimento em divulgação, anúncios, assinaturas, grade por duração, licenciamento de obras fictícias, melhorias, pausa e relatórios financeiros. Cada serviço explica custos e efeitos antes de confirmar.
- **Objetivos:** 11 objetivos iniciais liberam ciclos diários de seis tarefas. O catálogo tem 144 objetivos, em seis dificuldades. As recompensas chegam a R$ 160 mil e três powerups por tarefa. No Real diretor, recompensas continuam sem powerups.
- **Empresa e Melhorias:** caixa, receitas, despesas por categoria, folha salarial, audiência, produções, histórico de exibição e investimentos. A melhoria de elenco aumenta a capacidade de contratação.
- **Redes:** Tuiter, Istagram e Facibuk recebem mensagens de personagens jovens, adultos e senhores. A quantidade cresce com a audiência e a fama; as mensagens consideram roteiro, direção, equipe e acontecimentos da obra. O histórico bloqueia textos idênticos.
- **Prêmios e Jornal:** sete categorias, indicados, concorrentes, critérios, vencedores, recompensas e notícias. As edições acontecem a cada 12 semanas do jogo, com pagamento único por prêmio.
- **Obras:** filmes têm uma exibição remunerada por produção; séries têm episódios e temporadas. Obras canceladas ou não renovadas podem procurar outra emissora. Obras encerradas podem ganhar continuações numeradas, com novo desenvolvimento e contrato.
- **Análise:** roteiro, motivação, conflito, consequência, intenção criativa, direção, orçamento, divulgação e equipe ficam registrados na produção. Os relatórios mostram audiência, avaliações, críticas, gostei, favoritos, receita, custo e resultado. Créditos e escolhas ficam congelados no episódio para que alterações posteriores na equipe não modifiquem o histórico.
- **Campanhas:** as quatro dificuldades anteriores foram preservadas, junto às contas locais, migração de campanhas, exportação, importação, arquivo e retomada de campanhas.

## Regras importantes

**Tempo.** A agência usa ciclos de cinco minutos do relógio do dispositivo. Os objetivos diários começam após completar o tutorial e mudam a cada 24 horas reais; se o jogo ficou fechado, o ciclo é atualizado ao voltar. O relógio local não é um servidor. Produções, emissoras, concorrentes e prêmios avançam pelo botão de próxima semana.

**Criatividade.** O modelo combina sinais locais de variedade, desenvolvimento, motivação, conflito, consequências e intenção, em vez de impor um estilo ideal por gênero. Palavras repetidas para alongar um roteiro não melhoram a avaliação. Esta análise é uma heurística: não equivale à compreensão integral de um leitor humano ou de uma IA online. A intenção criativa ajuda a contextualizar escolhas de direção; não garante nota máxima para qualquer texto.

**Comentários.** As falas são geradas por composição de evidências da produção, opiniões, vozes e orientações de melhoria. No Real diretor há respostas e menções entre personagens. São personagens fictícios; não são redes sociais conectadas nem avaliações de espectadores reais.

**Fama e cargos.** Formação e gênero influenciam a técnica; atuar fora da formação reduz a eficiência. A fama aumenta o alcance. A contratação e a presença nos créditos têm custo e efeito identificáveis; o salário contratado permanece mesmo ao trocar de cargo. Celebridade não substitui roteiro.

**TV própria.** A grade impede sobreposição entre originais pelo horário e duração. Licenças reservam vagas por seis semanas. Anúncios elevam receita e interferem na recepção; assinaturas do streaming dependem de alcance, conteúdo, preço e cancelamentos. Custos de abertura, melhorias, licenças, operação e divulgação aparecem na empresa e na emissora. A pausa ainda custa manutenção.

**Saves anteriores.** O beta preserva caixa e progresso válidos. Registros antigos incompletos não são reconstruídos como se fossem dados exatos; os demonstrativos indicam essa limitação. As finanças do beta usam o caixa importado como saldo inicial e conciliam receitas e despesas novas.

## Verificação incluída

Execute `node tests/test-game.cjs` no projeto extraído. A suíte cobre as dificuldades, migração, financiamento, diversidade criativa, métricas, pagamento único de filmes, probabilidades da agência, cargos, salários, capacidade, créditos, comentários, continuações, mudança de emissora, programação, licenças, streaming, objetivos, prêmios, campanhas e contas criptografadas. Também renderiza as 19 combinações de área e subaba e verifica identidade e rodapé.

Os testes de lógica passaram no ambiente de criação. A compilação Android, a instalação e a navegação em um aparelho precisam ser verificadas antes do lançamento público. O workflow de compilação está em `.github/workflows/gerar-apk.yml`; siga `LEIA-ME-APK.txt`.

Os critérios de pesquisa e as fontes dos talentos estão em `PESQUISA-TALENTOS.md` e `TALENTOS-100.csv`. Atributos, salários e probabilidades são parâmetros fictícios do jogo, não avaliações reais de profissionais.

© V&D Digital. Todos os direitos reservados.
