# Ativar o universo online do Empire TV

O servidor já está implementado. Ele fornece autenticação do universo, análise criativa, comentários, geração de concorrentes, persistência e atualização periódica. A chave do provedor fica no servidor; não coloque essa chave no APK ou no repositório.

## 1. Preparar o serviço

Use Node.js 24. O diretório server não depende de pacotes npm externos.

1. Extraia os arquivos do diretório server, ou use o ZIP separado **Empire_TV_Servidor_IA.zip**.
2. Copie .env.example para .env em seu ambiente de execução privado.
3. Preencha OPENAI_API_KEY com sua chave do projeto OpenAI.
4. Se necessário, ajuste OPENAI_MODEL. O padrão preparado é gpt-6.1-sol.
5. Configure DATA_DIR para um diretório persistente. Ele guarda empire.sqlite, com usuários, sessões, pareceres, resumos e conversas.
6. Execute os testes e inicie:

~~~sh
npm test
npm start
~~~

Em hospedagem, configure as variáveis pelo painel de segredos do serviço. Não envie .env ao GitHub. Publique o serviço com uma URL HTTPS e mantenha o processo ativo; serviços que hibernam não geram conteúdo durante a suspensão.

O Dockerfile também está incluído:

~~~sh
docker build -t empire-tv-universe .
docker run --env-file .env -p 3000:3000 -v empire-data:/app/data empire-tv-universe
~~~

O volume mantém os dados após recriar o container. Exponha o serviço por HTTPS no seu domínio ou na hospedagem. O Android usa HTTPS; HTTP em localhost é somente para desenvolvimento da interface no navegador.

## 2. Conferir se está ativo

Abra https://SEU-SERVIDOR/health.

A resposta informa o nome, a versão, aiAvailable e paymentsEnabled. aiAvailable: false significa que falta configurar a chave, ou que a instância foi iniciada sem ela. paymentsEnabled permanece false.

## 3. Conectar no jogo

1. Entre na sua campanha.
2. Abra **Configurações → Universo online**.
3. Cole a URL HTTPS fornecida por você como responsável pelo jogo.
4. Escolha **Criar conta**, defina usuário e senha do universo e conecte.
5. Nos próximos acessos, escolha **Já tenho conta** com os mesmos dados.

A conta do universo é independente da conta local do aparelho. O app guarda uma sessão do servidor; ele não envia a senha local, as campanhas de outros perfis ou uma chave OpenAI.

Agora **Parecer**, no catálogo, analisa a versão da ideia. Ao apresentar a obra e ao iniciar uma produção, o app solicita o parecer necessário e reaproveita o resultado quando o texto não mudou. Se a análise falhar, a produção ou negociação não é executada silenciosamente como se tivesse recebido um parecer.

## 4. Entender a atualização contínua

- O aplicativo sincroniza o resumo criativo da campanha e busca conteúdo a cada minuto quando há conexão.
- O worker roda no serviço, com verificação a cada minuto.
- Por padrão, gera comentários de uma campanha a cada **60 minutos**, mesmo sem um novo acesso do app.
- Por padrão, cria novas propostas concorrentes a cada **360 minutos**.
- Usa a campanha mais recentemente sincronizada de cada conta. Campanhas arquivadas não continuam consumindo chamadas como se estivessem abertas.
- Uma campanha sem acesso por sete dias deixa de receber novos lotes personalizados até o jogador voltar. Seu histórico permanece no banco.
- O celular recebe o conteúdo guardado ao retornar. As semanas da campanha continuam avançando pelo botão do jogo; fechar o app não debita salários de semanas que você não jogou.

Os comentários têm nomes fictícios, vozes de idades diferentes, emoção e respostas. O modelo recebe fatos das produções e textos recentes para reduzir repetição; o banco bloqueia textos idênticos por audiência/campanha. A IA não pode modificar dinheiro, MF, pagamentos ou arquivos do jogador.

## 5. Ajustar uso de IA

Os padrões são **144 chamadas globais por dia** e **48 por conta por dia**, além de cache por revisão e agrupamento de solicitações iguais. Isso limita consumo e evita requisições repetidas pelo mesmo projeto.

Você pode ajustar AI_GLOBAL_DAILY_LIMIT, AI_USER_DAILY_LIMIT, SOCIAL_INTERVAL_MINUTES e WORLD_INTERVAL_MINUTES. Os limites devem acompanhar a quantidade de jogadores e o uso interativo. Quando são atingidos, o jogo informa a indisponibilidade; ele não inventa que fez uma chamada de IA.

A API precisa de acesso e saldo do projeto configurado. Esta implementação não usa automaticamente a assinatura ChatGPT do jogador. Não há pagamento configurado no jogo.

## Referências da integração

- [Responses API e autenticação](https://developers.openai.com/api/reference/overview): credenciais no servidor.
- [Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs?api-mode=responses): esquema estrito dos pareceres, comentários e concorrentes.
- [GPT-6.1 Sol](https://developers.openai.com/api/docs/models/gpt-6.1-sol): modelo padrão configurável.
- [SQLite no Node.js](https://nodejs.org/api/sqlite.html): banco persistente do serviço.

© V&D Digital. Todos os direitos reservados.
