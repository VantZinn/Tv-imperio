# Empire TV — servidor do universo

Node.js 24, SQLite persistente, API da OpenAI. Sem dependências npm externas.

~~~sh
npm test
cp .env.example .env
# Configure OPENAI_API_KEY e DATA_DIR no seu ambiente privado.
npm start
~~~

Use uma URL HTTPS, mantenha o processo ativo e preserve o volume de dados. GET /health informa se a IA está configurada. Sem chave, o serviço permanece disponível, mas não finge gerar conteúdo.

O guia completo está em ATIVAR-IA.md, na entrega principal e no ZIP separado do servidor.

| Rota | Uso |
|---|---|
| POST /v1/auth/register | Criar conta do universo |
| POST /v1/auth/login | Obter sessão |
| POST /v1/analyse | Parecer criativo com cache por versão |
| POST /v1/sync | Sincronizar resumo e receber conversas/concorrentes |
| POST /v1/wallet | Consultar carteira premium comprada, ainda zerada |
| POST /v1/shop/purchase | Desativada; não cobra nem credita MF |

Use Authorization: Bearer ... nas rotas da campanha. A chave OpenAI só vai ao provedor, no servidor. O APK recebe uma sessão da conta do universo.

Os testes cobrem protocolo, conteúdo inválido, cache, chamadas concorrentes, limites persistidos, comentários privados, novos concorrentes, reinício, ausência de chave, autenticação e pagamento bloqueado. A geração com uma chave real deve ser verificada depois da configuração.

© V&D Digital. Todos os direitos reservados.
