"""Build the offline Android asset from the included sources; no packages required."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parent
base=(ROOT/'src/base.html').read_text(encoding='utf-8')
base=base.replace("const first=state.schema!==4;","const first=!(state.schema>=4);")
base=re.sub(r'let displayedMarketEpoch=marketEpoch\(\);setInterval\(\(\)=>\{.*?\},1000\);','',base)
extension='\n'.join((ROOT/'src'/f).read_text(encoding='utf-8') for f in ('final-core.js','final-motion.js','final-prestige.js','final-ai.js','final-ui.js','final-events.js'))
marker='/* Empire TV beta — delegated actions; legacy account and backup handlers stay compatible. */'
assert base.count(marker)==1, 'Unexpected base script'
base=base.replace(marker,extension+'\n'+marker)
base=base.replace('</head>','<style>\n'+(ROOT/'src/final.css').read_text(encoding='utf-8')+'\n</style>\n</head>')
base=base.replace('</head>','<style>\n'+(ROOT/'src/motion.css').read_text(encoding='utf-8')+'\n</style>\n</head>')
base=base.replace('</head>','<script src="startup.js"></script>\n</head>')
logo=re.search(r"const TV_LOGO='([^']+)';",base).group(1)
boot='<div id="boot-screen" role="status" aria-live="polite"><video class="em-cinematic-media" autoplay loop muted playsinline preload="auto" poster="media/studio-poster.webp" aria-hidden="true"><source src="media/studio.mp4" type="video/mp4"></video><div class="em-film-grain"></div><div class="em-stage-beam left"></div><div class="em-stage-beam right"></div><div class="em-studio-grid"></div><div class="em-loading-card em-boot-card"><span class="eyebrow">V&D DIGITAL APRESENTA</span><div class="em-crown-scene"><div class="em-crown-halo"></div><div class="em-crown-halo outer"></div><div class="em-crown-logo">'+logo+'</div><div class="em-orbit-stars"><i></i><i></i><i></i><i></i></div></div><h1>EMPIRE <span>TV</span></h1><p class="em-boot-tagline">Sua criatividade. Seu império.</p><div class="em-boot-operation"><span id="boot-stage">Carregando estúdio</span><b id="boot-label">0%</b></div><div class="loading-progress" role="progressbar" aria-label="Preparando o estúdio" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><span id="boot-progress" style="width:0%"></span></div><p id="boot-detail">Preparando os recursos do jogo.</p><div class="em-boot-checks" aria-hidden="true"><i data-boot-check="0"></i><i data-boot-check="1"></i><i data-boot-check="2"></i><i data-boot-check="3"></i><i data-boot-check="4"></i></div><small>1.0.0.1 BETA</small></div></div><div id="scene-loading" class="em-loading-overlay" role="status" aria-live="polite" hidden></div>'
base=base.replace('<body>','<body>'+boot,1)
assert base.count('\nrender();\n')==1
base=base.replace('\nrender();\n','\nrender();\nwindow.EmpireBoot.progress(70);\nPromise.resolve(openPlayerDatabase()).then(()=>{window.EmpireBoot.progress(95);render();window.EmpireBoot.finish();if(s)queueUniverseSync();}).catch(()=>window.EmpireBoot.finish());\n')
base=base.replace('TV Empire','Empire TV').replace('TV EMPIRE','EMPIRE TV').replace('TV-Empire','Empire-TV').replace('1.0.0-beta','1.0.0.1 BETA')
base=base.replace('Não contém arquivos, código, arte ou dados proprietários','Produção original')
target=ROOT/'app/src/main/assets/index.html'
target.write_text(base,encoding='utf-8')
(ROOT/'tests/script-check.cjs').write_text(base.split('<script>')[1].split('</script>')[0],encoding='utf-8')
(ROOT/'Empire-TV-logo.svg').write_text(logo.replace('TV Empire','Empire TV')+'\n',encoding='utf-8')
for symbol,filename in [('MF_ICON','Moeda-da-Fama.svg'),('VANT_AVATAR','Vant-assistente.svg')]:
    svg=re.search(r"const "+symbol+r"='([^']+)';",extension).group(1)
    (ROOT/filename).write_text(svg+'\n',encoding='utf-8')
print('Empire TV built:',len(base.encode('utf-8')),'bytes.')
