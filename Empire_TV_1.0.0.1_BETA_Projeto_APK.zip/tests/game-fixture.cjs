const vm=require('node:vm'),fs=require('node:fs'),path=require('node:path'),{webcrypto}=require('node:crypto');
module.exports=function createGame(){
 let clock=Date.now();class GameDate extends Date{constructor(...args){super(...(args.length?args:[clock]));}static now(){return clock;}}
 const storage=new Map(),handlers={},root={innerHTML:'',addEventListener(type,fn){(handlers[type]??=[]).push(fn);},querySelector(){return null;},querySelectorAll(){return[];}},toast={textContent:'',className:''};
 const context={console,crypto:webcrypto,TextEncoder,TextDecoder,Uint8Array,Map,Set,Date:GameDate,Math,Number,JSON,String,Array,Object,Promise,FormData,Blob,URL,AbortController,confirm:()=>true,btoa:v=>Buffer.from(v,'binary').toString('base64'),atob:v=>Buffer.from(v,'base64').toString('binary'),setTimeout:()=>0,clearTimeout(){},setInterval:()=>0,window:{scrollTo(){}},document:{baseURI:'https://appassets.androidplatform.net/assets/index.html',querySelector:q=>q==='#root'?root:q==='#toast'?toast:null,querySelectorAll:()=>[]},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)}};
 context.globalThis=context;vm.createContext(context);
 let code=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8').split('<script>')[1].split('</script>')[0];
 code=code.replace(/\}\)\(\);\s*$/,'globalThis.testAPI={fresh,migrateFinal,ensureAutomaticService,automaticServiceEnabled,enableAutomaticService,serviceConfig,serviceJSON,disconnectService,syncUniverse,analyseWork,evaluateLocalNarrative,loadLocalAnalysisModule,localReferences,localVector,localProjection,analyseLocalWork,plotFactors,buildAnalysis,weighted,localAnalysisDetails,projectFingerprint,currentConceptAI,render,validAIReview,moduleStats:()=>({loaded:[...localModules.keys()],tasks:localModuleTasks.size}),setAccount:v=>{account=v;},setState:v=>{s=v;if(s)migrateFinal(s);},getState:()=>s,navigate:(t,p="")=>{tab=t;subpage=p;},setChosen:id=>{chosenShow=id;workPanel="analysis";}};})();');
 vm.runInContext(code,context);
 const api=context.testAPI;
 function profile(id='alice'){api.setAccount({id,username:id,type:'local'});const state=api.fresh('Estúdio '+id,'medium');api.setState(state);return state;}
 function assets(){context.window.fetch=async url=>{const relative=new URL(url).pathname.replace(/^\/assets\//,'');const bytes=fs.readFileSync(path.join(__dirname,'../app/src/main/assets',relative));return{ok:true,json:async()=>JSON.parse(bytes.toString('utf8')),arrayBuffer:async()=>bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength)};};}
 return{api,context,storage,root,handlers,profile,assets,time:()=>clock,advance:ms=>{clock+=ms;}};
};
