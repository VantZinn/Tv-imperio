# Empire TV — 1.0.0.1 BETA

Empresa: **V&D Digital**.

Este pacote contém o aplicativo Android completo, as fontes da interface, o servidor do universo online e os testes. O APK deve ser compilado; não há um APK já gerado neste ZIP.

## Gerar o APK no GitHub, inclusive pelo celular

1. Envie **Empire_TV_1.0.0.1_BETA_Projeto_APK.zip** à raiz do seu repositório, sem extrair nem renomear.
2. Substitua todo o conteúdo de **.github/workflows/gerar-apk.yml** pelo arquivo **gerar-apk-empire-tv.yml** recebido. Enviar o YML somente à raiz não cria um workflow.
3. Salve no GitHub. Abra **Actions → Gerar APK Empire TV → Run workflow**.
4. O job testa o jogo e o servidor, compila e abre o APK duas vezes em um emulador Android 15. Aguarde a conclusão, incluindo a etapa de abertura.
5. Abra **Artifacts → Empire-TV-1.0.0.1-BETA-APK**, baixe o ZIP do artefato, extraia e instale **Empire-TV-1.0.0.1-BETA.apk**.

O workflow aceita também o projeto extraído na raiz. Dentro deste pacote há uma cópia em .github/workflows/gerar-apk.yml.

## Atualizar sem perder a carreira

Exporte o progresso em **Configurações → Conta e campanhas → Exportar progresso** antes de instalar outro APK. O identificador Android foi preservado para aproveitar os dados da instalação anterior.

O Android só aceita instalar por cima se o APK usar a mesma assinatura. O workflow gera um APK de teste; a chave de depuração de uma execução pode diferir da anterior. Se for necessário reinstalar, faça o backup antes de desinstalar e importe o JSON depois. Para distribuir atualizações continuamente, use uma chave privada de assinatura permanente. Nenhuma chave de assinatura ou chave de IA está incluída.

## Compilar e verificar no computador

Requisitos: Java 17, Android SDK 35 e Gradle 8.11.1. Para os testes, Node.js 24.

~~~sh
python3 build-app.py
node tests/test-game.cjs
node --test server/tests/*.test.mjs
npm ci --prefix tests
node tests/test-startup.cjs
gradle --no-daemon assembleDebug
~~~

Resultado: app/build/outputs/apk/debug/app-debug.apk.

O script build-app.py usa apenas a biblioteca padrão do Python. Ele reúne src/base.html, os quatro módulos da versão nova e src/final.css no arquivo completo app/src/main/assets/index.html.

## O que está nesta versão

- **Marca:** Empire TV, V&D Digital, versão 1.0.0.1 BETA, TV com coroa e direitos reservados no final de cada página.
- **Tela cheia:** modo imersivo no Android, rotação automática em pé/deitado, preservação da página ao girar, tratamento de recortes de câmera e interface que preenche a área disponível.
- **Interface:** menu principal único, barra compacta de caixa/MF, áreas por tarefa, detalhes de uma obra por vez, fila de produção e relatórios em painéis. Abas inferiores permanecem na área atual.
- **MF:** Moeda da Fama, símbolo dourado próprio, saldo separado, histórico, renovação imediata da agência, troca de missão diária, compra de powerups e troca por verba da produtora.
- **Loja:** catálogo de pacotes premium pronto. Preços e pagamentos reais estão desativados; não há cobrança, confirmação fictícia de pagamento ou crédito premium comprado.
- **Vant:** apresentação de 15 passos por toque, explicação das páginas, acompanhamento das missões primárias e revisão do tutorial em Configurações. Assistente permanece até concluir todas as missões iniciais.
- **Produção:** de uma a seis semanas do jogo, conforme escopo, duração, desenvolvimento e parecer. O investimento é pago ao iniciar; salários e manutenção seguem toda semana. Emissora própria pausada adia a estreia.
- **Mercado:** 40 emissoras com ranking, alcance e exigência que mudam segundo os resultados; concorrentes novos entram em produção e só disputam prêmios depois da estreia.
- **IA:** servidor para analisar ideias e roteiros, criar comentários específicos e novas obras concorrentes. Pareceres influenciam a criatividade e a recepção; o jogo calcula audiência, contratos e dinheiro com regras verificáveis.
- **Continuidade:** dificuldades, 100 referências de talentos, 144 desafios diários, emissoras próprias, licenças, continuações, contas, campanhas arquivadas e backups preservados.

## IA e redes durante as 24 horas

A integração real está no diretório server e agora usa **Gemini com Free tier** por padrão. Para ativá-la, crie sua chave gratuita no Google AI Studio, mantenha o projeto sem cobrança e configure GEMINI_API_KEY no servidor. Leia **ATIVAR-IA.md**. O APK que já contém Universo online é compatível com o novo servidor, sem precisar recompilar só para trocar a IA. As cotas do Google continuam se aplicando.

**Sem servidor/chave:** o jogo funciona no modo local, usando análise por regras, comentários contextuais e novos concorrentes procedurais. Esse modo não é uma IA generativa. As conversas locais avançam enquanto o jogo está aberto e recuperam um lote limitado ao retornar.

**Com servidor e IA configurados:** os pareceres usam a API do Gemini por padrão (OpenAI é opcional e exige configuração explícita), as conversas são guardadas no banco e o worker cria novas falas mesmo com o aplicativo fechado. Novas propostas concorrentes chegam pela sincronização e cumprem seu cronograma dentro da campanha.

A continuidade durante as 24 horas depende de hospedagem que mantenha o processo ativo, conexão, disco persistente, acesso ao provedor e limites de uso suficientes. Um app fechado sozinho não executa chamadas de IA. GitHub Pages pode servir arquivos estáticos, mas não executa este servidor.

Os testes da integração usaram respostas simuladas para verificar o protocolo e os efeitos no jogo. A geração com uma chave real não foi executada neste ambiente.

## Correções de abertura e carregamento

O aplicativo agora trata falhas de criação do WebView, falhas de carregamento, erros de script e encerramento do processo de renderização. Oferece tentativa de abertura, atualização do componente de exibição e um diagnóstico copiável com modelo do aparelho, versão Android/WebView e código de falha. Não copia senhas, chave de IA ou dados da campanha.

A configuração de tela cheia está protegida para que uma falha nesse recurso não interrompa a abertura. Scripts de progresso não são mais injetados enquanto o WebView está iniciando, e os recortes da tela são aplicados após a interface ficar pronta. Há compatibilidade para Array.at e Object.hasOwn em componentes de exibição anteriores.

O aviso de mensagens agora fica oculto quando está vazio e tem altura limitada quando aparece. Foi removida a combinação de posição superior e inferior que esticava o aviso verde sobre a tela de login. O carregamento também é removido completamente ao terminar, liberando os campos e botões.

O nome continua 1.0.0.1 BETA; o versionCode Android do pacote atual é 10006. O identificador do aplicativo foi preservado. Substitua o ZIP na raiz do repositório e execute novamente **Actions → Gerar APK Empire TV → Run workflow**. O workflow existente continua compatível. Leia **CORRIGIR-ABERTURA.md** antes de atualizar.

## Correção da integração de IA

As análises ficam sem limite diário interno com AI_GLOBAL_DAILY_LIMIT=0 e AI_USER_DAILY_LIMIT=0. A geração automática mantém uma parcela de chamadas e respeita os intervalos após falhar. As pausas reais do provedor continuam persistidas. Configurações → Universo online mostra a razão da pausa, quando tentar novamente e os limites locais. Esses limites não ampliam a cota gratuita do Google.

Durante falhas temporárias, negociação, financiamento e produção podem continuar com análise local por regras. O parecer local aparece identificado e não é apresentado como uma geração de IA. Pareceres de IA válidos já guardados são reaproveitados. Foram aprovados 32 testes do servidor e testes do jogo, incluindo negociação/produção sem resposta de IA, identificação automática e recuperação de sessão. Consulte **CORRIGIR-IA.md** para atualizar o servidor e o APK.

## Apresentação animada e prestígio

A abertura apresenta etapas por aproximadamente 8 segundos, com três cenários originais Full HD usados no carregamento, análise e prestígio. A análise mostra os estados reais e as notas só depois de validar o parecer. Há 12 desafios de prestígio com até 75 MF e 3 impulsos, e as missões diárias agora entregam de 1 a 12 MF por dificuldade. Vídeos e animações têm um modo Suave em Configurações. Consulte **ATUALIZACAO-ANIMADA.md** para requisitos, recompensas e aplicação. A meta de cerca de 150 MB é para o lançamento e ainda não foi atingida.

## Conexão automática e biblioteca local

Ao entrar em uma campanha, o APK conecta automaticamente a https://tv-imperio.onrender.com. Cada perfil recebe sua própria identificação; sessões vencidas são recuperadas. Configurações → Universo online permite continuar apenas no modo local e mantém contas manuais existentes. Publique primeiro o servidor atualizado e altere os limites internos antigos para 0, conforme **CORRIGIR-IA.md**.

A análise local foi ampliada para **44,2 MiB de recursos instalados**: 13.824 estudos fictícios em 12 gêneros, critérios com evidência, efeito e sugestão, e índices para selecionar experiências de reescrita próximas da ideia. As notas dependem do texto atual e não vêm prontas dos estudos. A biblioteca abre por gênero e mantém até dois módulos em memória. É um motor por regras e referências, com limites para leituras implícitas, não uma IA generativa no aparelho. A compactação deixa o ZIP menor que o conteúdo instalado.

## Verificação e lançamento

Os testes de lógica do jogo, integração com respostas controladas e os 32 testes do servidor passaram. Foram verificadas 34 combinações de páginas/subabas, limites de formulário, IDs únicos, XML Android e os SVGs.

A classe MainActivity foi compilada com Java 17 e as APIs Android 35/WebKit 1.12.1 na revisão anterior e permanece igual neste pacote. Os cinco testes de inicialização da interface e os 33 grupos de testes de lógica passaram após a correção do aviso. O erro foi reproduzido no Chromium e a correção foi verificada em telas de 390 × 844 e 844 × 390: aviso vazio invisível, carregamento removido e campos acessíveis. A compilação completa do APK e o teste real no emulador serão executados pelo workflow; ainda não foram executados neste ambiente. A instalação, o teclado e a rotação em seu celular também precisam ser verificados. As compras reais também continuam desativadas, conforme o pedido. Não trate esta entrega como uma validação completa de publicação em loja.

© V&D Digital. Todos os direitos reservados.
