# Empire TV — 1.0.0.1 BETA

Empresa: **V&D Digital**.

Este pacote contém o aplicativo Android completo, as fontes da interface, o servidor do universo online e os testes. O APK deve ser compilado; não há um APK já gerado neste ZIP.

## Gerar o APK no GitHub, inclusive pelo celular

1. Envie **Empire_TV_1.0.0.1_BETA_Projeto_APK.zip** à raiz do seu repositório, sem extrair nem renomear.
2. Substitua todo o conteúdo de **.github/workflows/gerar-apk.yml** pelo arquivo **gerar-apk-empire-tv.yml** recebido. Enviar o YML somente à raiz não cria um workflow.
3. Salve no GitHub. Abra **Actions → Gerar APK Empire TV → Run workflow**.
4. O job testa o jogo e o servidor antes de compilar. Aguarde a conclusão.
5. Abra **Artifacts → Empire-TV-1.0.0.1-BETA-APK**, baixe o ZIP do artefato, extraia e instale **Empire-TV-1.0.0.1-BETA.apk**.

O workflow aceita também o projeto extraído na raiz. Dentro deste pacote há uma cópia em .github/workflows/gerar-apk.yml.

## Atualizar sem perder a carreira

Exporte o progresso em **Configurações → Conta e campanhas → Exportar progresso** antes de instalar outro APK. O identificador Android foi preservado para aproveitar os dados da instalação anterior.

O Android só aceita instalar por cima se o APK usar a mesma assinatura. O workflow gera um APK de teste; a chave de depuração de uma execução pode diferir da anterior. Se for necessário reinstalar, faça o backup antes de desinstalar e importe o JSON depois. Para distribuir atualizações continuamente, use uma chave privada de assinatura permanente. Nenhuma chave de assinatura ou chave de IA está incluída.

## Compilar e verificar no computador

Requisitos: Java 17, Android SDK 35 e Gradle 8.11.1. Para os testes, Node.js 24.

~~~sh
python3 build-app.py
node tests/test-game.cjs
node --test server/tests/server.test.mjs
gradle --no-daemon assembleDebug
~~~

Resultado: app/build/outputs/apk/debug/app-debug.apk.

O script build-app.py usa apenas a biblioteca padrão do Python. Ele reúne src/base.html, os quatro módulos da versão nova e src/final.css no arquivo completo app/src/main/assets/index.html.

## O que está nesta versão

- **Marca:** Empire TV, V&D Digital, versão 1.0.0.1 BETA, TV com coroa e direitos reservados no final de cada página.
- **Tela cheia:** modo imersivo no Android, rotação automática em pé/deitado, preservação da página ao girar, tratamento de recortes de câmera e interface que preenche a área disponível.
- **Interface:** menu principal único, barra compacta de caixa/MF, áreas por tarefa, detalhes de uma obra por vez, fila de produção e relatórios em painéis. Abas inferiores permanecem na área atual.
- **MF:** Moeda da Fama, símbolo dourado próprio, saldo separado, histórico, renovação imediata da agência, troca de missão diária, compra de powerups e troca por verba da produtora.
- **Loja:** catálogo de pacotes premium pronto. Preços e pagamentos reais estão desativados; não há cobrança, confirmação fictícia de pagamento ou crédito premium comprado.
- **Vant:** apresentação de 15 passos por toque, explicação das páginas, acompanhamento das missões primárias e revisão do tutorial em Configurações. Assistente permanece até concluir todas as missões iniciais.
- **Produção:** de uma a seis semanas do jogo, conforme escopo, duração, desenvolvimento e parecer. O investimento é pago ao iniciar; salários e manutenção seguem toda semana. Emissora própria pausada adia a estreia.
- **Mercado:** 40 emissoras com ranking, alcance e exigência que mudam segundo os resultados; concorrentes novos entram em produção e só disputam prêmios depois da estreia.
- **IA:** servidor para analisar ideias e roteiros, criar comentários específicos e novas obras concorrentes. Pareceres influenciam a criatividade e a recepção; o jogo calcula audiência, contratos e dinheiro com regras verificáveis.
- **Continuidade:** dificuldades, 100 referências de talentos, 144 desafios diários, emissoras próprias, licenças, continuações, contas, campanhas arquivadas e backups preservados.

## IA e redes durante as 24 horas

A integração real está no diretório server. Para ativá-la, você precisa hospedar esse serviço e configurar sua chave no servidor. Leia **ATIVAR-IA.md**.

**Sem servidor/chave:** o jogo funciona no modo local, usando análise por regras, comentários contextuais e novos concorrentes procedurais. Esse modo não é uma IA generativa. As conversas locais avançam enquanto o jogo está aberto e recuperam um lote limitado ao retornar.

**Com servidor e IA configurados:** os pareceres usam a API da OpenAI, as conversas são guardadas no banco e o worker cria novas falas mesmo com o aplicativo fechado. Novas propostas concorrentes chegam pela sincronização e cumprem seu cronograma dentro da campanha.

A continuidade durante as 24 horas depende de hospedagem que mantenha o processo ativo, conexão, disco persistente, acesso ao provedor e limites de uso suficientes. Um app fechado sozinho não executa chamadas de IA. GitHub Pages pode servir arquivos estáticos, mas não executa este servidor.

Os testes da integração usaram respostas simuladas para verificar o protocolo e os efeitos no jogo. A geração com uma chave real não foi executada neste ambiente.

## Verificação e lançamento

Os testes de lógica do jogo, integração com respostas controladas e os 11 testes do servidor passaram. Foram verificadas 32 combinações de páginas/subabas, limites de formulário, IDs únicos, XML Android e os SVGs.

A compilação Android, a instalação, o teclado e a rotação em um celular físico ainda precisam ser verificados. As compras reais também continuam desativadas, conforme o pedido. Não trate esta entrega como uma validação completa de publicação em loja.

© V&D Digital. Todos os direitos reservados.
