# Empire TV — apresentação animada e desafios de prestígio

Versão exibida: **1.0.0.1 BETA**. Empresa: **V&D Digital**. versionCode Android: **10005**.

## Abertura

A apresentação dura aproximadamente 8 segundos em condições normais. Mostra Carregando estúdio, Conferindo atores, Organizando emissoras, Preparando missões e Conferindo seu progresso acima da barra. A conclusão depende também de os dados locais terem terminado de iniciar. Se o armazenamento principal falhar ou ficar bloqueado, a alternativa local continua funcionando.

A tela cobre toda a área em pé ou deitada. As interações ficam bloqueadas durante a abertura e são liberadas quando a apresentação sai; a camada e o vídeo são removidos completamente. Falhas de script continuam abrindo a recuperação, sem sinalizar sucesso.

## Análise de obras

A sala de análise tem documento animado, leitura luminosa, órbitas, cenário em vídeo, dados da obra e cinco critérios visíveis. Mostra tempo decorrido e o estado real da operação: espera do provedor, verificação da resposta e parecer validado. Não mostra uma porcentagem inventada do processamento do provedor. As notas aparecem depois da validação.

Pareceres guardados têm apresentação de recuperação e não gastam outra chamada. A análise local tem botão próprio na aba Parecer, é identificada como avaliação por regras e não envia uma solicitação de IA. Uma resposta incompleta não vira um parecer válido. As pausas e o funcionamento local implementados na atualização anterior continuam preservados.

## Recompensas

Em **Objetivos → Prestígio**, há 12 desafios permanentes da campanha, de Difícil a Lendário. Pedem qualidade, audiência, consistência de temporadas, franquias, emissoras próprias, faturamento e prêmios. Cada um dá de 15 a 75 MF e de 1 a 3 impulsos. O progresso já conta desde o começo, mas o resgate só é liberado após concluir a jornada inicial. Uma conquista paga uma vez, inclusive depois de restaurar a campanha.

Os impulsos são: 1 = Inspiração; 2 = Inspiração e Audiência; 3 = os anteriores e Desconto. Entram no inventário para usar depois. O modo Real diretor continua sem impulsos e recebe as MF previstas.

As 144 missões diárias também têm MF proporcionais à dificuldade:

| Classe | MF por missão |
|---|---:|
| Muito fácil | 1 |
| Fácil | 2 |
| Médio | 3 |
| Difícil | 5 |
| Muito difícil | 8 |
| Lendário | 12 |

O dinheiro, o XP e os impulsos das diárias continuam seguindo as regras anteriores. A rodada continua em 24 horas reais e o resgate é único. Recompensas de rodadas já resgatadas não são pagas novamente com o valor novo.

## Animações e mídia

Inclui três cenários originais em vídeo Full HD, 30 fps, com loops de 8 segundos e sem faixa de áudio, além dos cenários estáticos. Há luzes, partículas, logo com coroa, transições de páginas e cartões, respostas nos botões, destaque do saldo MF, progresso animado, Vant em movimento e celebração de conquistas. Os vídeos são pausados e liberados ao sair da tela.

Em **Configurações → Visual e animações**, Cinemático é o padrão; Suave reduz os movimentos e usa o cenário estático. A preferência de movimento reduzido do aparelho também é respeitada. Os arquivos de mídia vêm no APK e não dependem do servidor.

Os vídeos representam cerca de 12 MiB de mídia útil nesta atualização. **A meta aproximada de 150 MB é para o lançamento na Play Store**; este pacote ainda não chega a esse tamanho. O crescimento deve acompanhar arte, trilhas, animações e conteúdo jogável novos. O tamanho final do APK só é confirmado pela compilação; o ZIP do projeto não tem o mesmo tamanho do APK.

## Aplicar

1. Substitua **Empire_TV_1.0.0.1_BETA_Projeto_APK.zip** na raiz do GitHub, com esse nome exato.
2. Execute **Actions → Gerar APK Empire TV → Run workflow**. O workflow existente continua compatível.
3. Baixe o APK dessa nova execução. O identificador do aplicativo e a estrutura das campanhas foram mantidos.

Esta mudança é no projeto Android. O servidor corrigido na entrega anterior continua compatível; não é necessário republicá-lo só por causa das animações e dos desafios.

## Verificação

Os testes verificam início com armazenamento normal/indisponível/bloqueado, compatibilidade, recuperação de script, valores de recompensas, requisitos completos, resgate único, restauração e a regra do Real diretor. O Chromium verifica abertura, reprodução dos vídeos, análise local e desafios em 390 × 844 e 844 × 390. A classe MainActivity foi compilada com Java 17 e APIs Android 35/WebKit. A compilação completa e a abertura do APK no emulador continuam sendo executadas no GitHub Actions; este ambiente não executou o APK em um celular físico.

Para recriar os cenários, tools/build-cinematics.py usa Pillow, numpy e ffmpeg. A compilação habitual usa os vídeos já incluídos e não precisa dessas ferramentas.

© V&D Digital. Todos os direitos reservados.
