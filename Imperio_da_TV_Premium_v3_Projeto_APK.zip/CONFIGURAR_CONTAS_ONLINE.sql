-- IMPÉRIO DA TV PREMIUM V2 — BANCO SUPABASE
-- Cole este SQL no SQL Editor de um projeto seu no Supabase.
-- NUNCA insira uma chave secret/service_role no aplicativo.

create table if not exists public.game_saves (
    user_id uuid primary key references auth.users(id) on delete cascade,
    save_data jsonb not null,
    updated_at timestamptz not null default now()
);

alter table public.game_saves enable row level security;

-- Somente usuários autenticados podem manipular o próprio jogo salvo.
revoke all on public.game_saves from anon;
grant select, insert, update, delete on public.game_saves to authenticated;

drop policy if exists "Jogador le somente seu save" on public.game_saves;
create policy "Jogador le somente seu save" on public.game_saves
for select to authenticated using ((select auth.uid())=user_id);

drop policy if exists "Jogador cria somente seu save" on public.game_saves;
create policy "Jogador cria somente seu save" on public.game_saves
for insert to authenticated with check ((select auth.uid())=user_id);

drop policy if exists "Jogador atualiza somente seu save" on public.game_saves;
create policy "Jogador atualiza somente seu save" on public.game_saves
for update to authenticated
using ((select auth.uid())=user_id)
with check ((select auth.uid())=user_id);

drop policy if exists "Jogador apaga somente seu save" on public.game_saves;
create policy "Jogador apaga somente seu save" on public.game_saves
for delete to authenticated using ((select auth.uid())=user_id);
