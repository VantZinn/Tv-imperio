/* The app connects to the game's server. Provider credentials stay on that server. */
const EMPIRE_UNIVERSE_URL='https://tv-imperio.onrender.com';
const autoConnectTasks=new Map(),autoRetryTimes=new Map(),autoConnectVersions=new Map();
function serviceKey(){return 'empire-universe-'+(account?.id||'guest');}
function serviceConfig(){try{const c=JSON.parse(localStorage.getItem(serviceKey())||'null');return c&&typeof c.url==='string'&&typeof c.token==='string'?c:null;}catch{return null;}}
function automaticServiceEnabled(){if(!account)return false;try{return JSON.parse(localStorage.getItem('empire-universe-pref-'+account.id)||'null')?.disabled!==true;}catch{return true;}}
function onlineAnalysisEnabled(){return Boolean(serviceConfig())||(automaticServiceEnabled()&&typeof fetch==='function');}
function automaticConnectionMessage(){if(!automaticServiceEnabled())return 'Modo local escolhido. A conexão automática pode ser ativada aqui.';if(autoConnectTasks.has(account?.id))return 'Conectando automaticamente ao universo do jogo. Você pode continuar jogando.';return s?.live?.error||'O jogo conecta automaticamente à IA do Empire TV quando há internet.';}
function automaticSessionReady(c){return c&&(c.mode!=='automatic'||(c.url===EMPIRE_UNIVERSE_URL&&Number.isFinite(c.expiresAt)&&c.expiresAt>Date.now()+60000));}
async function ensureAutomaticService(force=false){
 if(!account||!s||typeof fetch!=='function')return false;
 const existing=serviceConfig();if(automaticSessionReady(existing))return true;
 if(!automaticServiceEnabled())return false;
 const owner=account.id,version=autoConnectVersions.get(owner)||0;if(autoConnectTasks.has(owner))return autoConnectTasks.get(owner);
 if(!force&&(autoRetryTimes.get(owner)||0)>Date.now())return false;
 const task=(async()=>{
  try{
   const key='empire-universe-device-'+owner;let device;
   try{device=JSON.parse(localStorage.getItem(key)||'null');}catch{}
   if(!device||!/^[a-f0-9]{64}$/.test(device.deviceId)||!/^[a-f0-9]{64}$/.test(device.deviceSecret)){
    const hex=()=>Array.from(crypto.getRandomValues(new Uint8Array(32)),v=>v.toString(16).padStart(2,'0')).join('');
    device={deviceId:hex(),deviceSecret:hex()};localStorage.setItem(key,JSON.stringify(device));
   }
   const result=await serviceJSON('/v1/auth/device',device,{url:EMPIRE_UNIVERSE_URL,token:''});
   if(account?.id!==owner||(autoConnectVersions.get(owner)||0)!==version||!automaticServiceEnabled())return false;
   if(!/^[a-f0-9]{64}$/.test(result.token)||!Number.isFinite(result.expiresAt)||result.expiresAt<=Date.now()+60000)throw Object.assign(Error('A identificação automática não foi confirmada pelo servidor.'),{status:502,retryAfter:60});
   const current=serviceConfig();if(current&&current.mode!=='automatic')return true;
   localStorage.setItem(serviceKey(),JSON.stringify({url:EMPIRE_UNIVERSE_URL,token:result.token,expiresAt:result.expiresAt,username:account.username,mode:'automatic'}));
   if(!existing){s.live.serverCursor=0;s.live.lastSyncAt=0;}
   autoRetryTimes.delete(owner);applyAIStatus(result.aiStatus,result.aiAvailable);save();return true;
  }catch(e){
   if(account?.id===owner&&(autoConnectVersions.get(owner)||0)===version){autoRetryTimes.set(owner,Date.now()+Math.max(30000,(e.retryAfter||60)*1000));s.live.error=e.message;s.live.mode='local';save();}
   return false;
  }
 })();
 autoConnectTasks.set(owner,task);try{return await task;}finally{if(autoConnectTasks.get(owner)===task)autoConnectTasks.delete(owner);}
}
async function enableAutomaticService(){
 if(!account||!s)return;const owner=account.id;autoConnectVersions.set(owner,(autoConnectVersions.get(owner)||0)+1);localStorage.removeItem('empire-universe-pref-'+owner);localStorage.removeItem(serviceKey());autoRetryTimes.delete(owner);
 if(autoConnectTasks.has(owner))await autoConnectTasks.get(owner);if(account?.id!==owner)return;
 const ready=await ensureAutomaticService(true);if(account?.id!==owner)return;if(ready)await syncUniverse(true);render();notice(ready?aiServiceMessage():automaticConnectionMessage(),!ready);
}
function validServiceURL(raw){try{const u=new URL(raw);if(u.username||u.password||u.search||u.hash)return null;if(u.protocol!=='https:'&&!(['localhost','127.0.0.1'].includes(u.hostname)&&u.protocol==='http:'))return null;return u.origin+u.pathname.replace(/\/$/,'');}catch{return null;}}
function aiRetryAt(){const value=s?.live?.aiStatus?.retryAt;return Number.isFinite(value)?value:0;}
function aiServiceMessage(){
 const status=s?.live?.aiStatus;
 if(status&&status.available===false){const next=aiRetryAt();return status.message+(next>Date.now()?' Nova tentativa após '+new Date(next).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})+'.':'');}
 return s?.live?.lastAIAt?'Servidor conectado. Última geração de IA confirmada em '+new Date(s.live.lastAIAt).toLocaleString('pt-BR')+'.':'Servidor conectado; a geração de IA será confirmada ao receber um parecer válido.';
}
function aiQuotaDetails(){
 const q=s?.live?.aiStatus?.quotas;if(!q||!q.global||!q.account||!q.automatic)return '';
 const count=x=>!Number.isSafeInteger(x.used)?'—':x.unlimited===true?String(x.used):x.disabled===true?'0':Number.isSafeInteger(x.limit)?x.used+' / '+x.limit:'—';
 const label=x=>x.unlimited===true?'Sem limite interno':x.disabled===true?'Geração desativada':'Chamadas por dia';
 return '<details class="em-ai-quota"><summary>Limites da IA</summary>'+kpis([['Chamadas do servidor',count(q.global),label(q.global)],['Análises desta conta',count(q.account),label(q.account)],['Geração automática',count(q.automatic),label(q.automatic)]])+'<p>Sem limite interno significa que o jogo não impõe uma quantidade diária de análises. A cota gratuita do provedor continua válida. As chamadas automáticas usam uma parcela separada para preservar essa cota para os jogadores. Tentativas enviadas ao provedor são contabilizadas mesmo quando falham.</p>'+(Number.isFinite(q.resetAt)?'<p>Reinício da contagem diária do servidor: '+esc(new Date(q.resetAt).toLocaleString('pt-BR'))+'. O provedor confirma a disponibilidade em cada nova chamada.</p>':'')+'</details>';
}
function applyAIStatus(info,configured=true){
 if(!s)return;
 if(info&&typeof info.available==='boolean'){
  const seconds=Number(info.retryAfter),retryAt=seconds>0?Date.now()+Math.min(129600,seconds)*1000:Number.isFinite(info.retryAt)?info.retryAt:0;
  s.live.aiStatus={configured:info.configured!==false,available:info.available,code:String(info.code||'').slice(0,80),message:String(info.message||'A IA está em pausa.').slice(0,240),retryAt,quotas:info.quotas||null};
 }else if(!s.live.aiStatus||aiRetryAt()<=Date.now())s.live.aiStatus={configured,available:configured,code:configured?'':'AI_NOT_CONFIGURED',message:configured?'':'A IA ainda não foi configurada no servidor.',retryAt:0,quotas:null};
 s.live.mode=s.live.aiStatus.available?'online':'connected';s.live.error=s.live.aiStatus.available?'':aiServiceMessage();
}
function temporaryAIError(e){return [429,502,503,504].includes(e.status);}
async function serviceJSON(route,body={},override=null,retried=false){
 const c=override||serviceConfig();if(!c)throw Error('Conecte um servidor do universo em Configurações.');
 const owner=account?.id,controller=new AbortController(),timer=setTimeout(()=>controller.abort(),route==='/v1/auth/device'?15000:100000);
 try{const response=await fetch(c.url+route,{method:'POST',headers:{'Content-Type':'application/json',...(c.token?{Authorization:'Bearer '+c.token}:{})},body:JSON.stringify(body),signal:controller.signal});
  let data;try{data=await response.json();}catch{throw Object.assign(Error('O servidor não devolveu uma resposta válida. O jogo pode continuar com análise local.'),{status:502,code:'AI_SERVER_INVALID_RESPONSE',retryAfter:60});}
  if(!response.ok){
   if(response.status===401&&!override&&!retried&&c.mode==='automatic'&&c.url===EMPIRE_UNIVERSE_URL&&account?.id===owner&&automaticServiceEnabled()){
    if(serviceConfig()?.token===c.token)localStorage.removeItem(serviceKey());
    if(await ensureAutomaticService(true)){if(account?.id!==owner)throw Error('O perfil mudou durante a conexão.');return await serviceJSON(route,body,null,true);}
   }
   const retryAfter=Number(data.retryAfter||response.headers?.get?.('retry-after'))||0;throw Object.assign(Error(String(data.error||'Servidor indisponível.').slice(0,240)),{status:response.status||503,code:String(data.code||'').slice(0,80),retryAfter,retryAt:Number(data.retryAt)||0});
  }return data;
 }catch(e){if(e.name==='AbortError')throw Object.assign(Error('A conexão com o servidor demorou demais. O progresso foi preservado.'),{status:504,code:'AI_SERVER_TIMEOUT',retryAfter:60});if(e instanceof TypeError)throw Object.assign(Error('Não foi possível conectar ao servidor. O jogo pode continuar com análise local.'),{status:503,code:'AI_SERVER_CONNECTION',retryAfter:60});throw e;}finally{clearTimeout(timer);}
}
function validAIReview(r){
 const string=v=>typeof v==='string'&&v.length<=2400;
 return r&&string(r.summary)&&string(r.verdict)&&string(r.hook)&&r.scores&&['originality','coherence','characters','impact','execution'].every(k=>Number.isInteger(r.scores[k])&&r.scores[k]>=0&&r.scores[k]<=100)&&Number.isInteger(r.productionWeeks)&&r.productionWeeks>=1&&r.productionWeeks<=6&&Array.isArray(r.strengths)&&r.strengths.length<=8&&r.strengths.every(string)&&Array.isArray(r.risks)&&r.risks.length<=8&&r.risks.every(x=>['aspect','evidence','impact','advice'].every(k=>string(x[k])))&&Array.isArray(r.comments)&&r.comments.length<=24&&r.comments.every(c=>string(c.name)&&string(c.text)&&['Jovem','Adulto','Senhor'].includes(c.ageGroup)&&['tuiter','istagram','facibuk'].includes(c.platform)&&Number.isInteger(c.replyTo));
}
async function connectService(fd){
 const url=validServiceURL(String(fd.get('url')||'')),name=String(fd.get('username')||'').trim(),password=String(fd.get('password')||''),register=fd.get('mode')==='register';
 if(!url)throw Error('Use a URL HTTPS do servidor. Localhost HTTP é aceito apenas para desenvolvimento.');
 const owner=account.id,configuration={url,token:''};
 autoConnectVersions.set(owner,(autoConnectVersions.get(owner)||0)+1);
 showSceneLoading('Conectando seu universo',25);
 try{const result=await serviceJSON('/v1/auth/'+(register?'register':'login'),{username:name,password},configuration);
  if(account?.id!==owner)return;localStorage.setItem(serviceKey(),JSON.stringify({url,token:result.token,username:name}));s.live.serverCursor=0;s.live.lastSyncAt=0;applyAIStatus(result.aiStatus,result.aiAvailable);save();await syncUniverse(true);notice(aiServiceMessage());
 }finally{hideSceneLoading();render();}
}
function disconnectService(){if(account){const owner=account.id;autoConnectVersions.set(owner,(autoConnectVersions.get(owner)||0)+1);try{localStorage.removeItem(serviceKey());localStorage.setItem('empire-universe-pref-'+owner,JSON.stringify({disabled:true}));}catch{}}if(s){s.live.mode='local';s.live.error='';s.live.aiStatus=null;save();render();}notice('Modo local ativo. Seu progresso continua.');}
async function analyseWork(showId,script='',intent=null,production=false,allowLocal=false){
 const sh=showBy(showId);if(!sh)throw Error('Obra não encontrada.');
 const actualIntent=intent??sh.intent,key=projectFingerprint(sh,script,actualIntent),prior=production?sh.aiPrepared:sh.aiConcept;
 if(prior?.fingerprint===key&&validAIReview(prior)){localReviewMode=null;aiBusy=true;showSceneLoading('Revisitando seu parecer',100,{kind:'analysis',work:sh});try{completeAnalysisScene(prior,true);await settleAnalysisScene();return prior;}finally{aiBusy=false;hideSceneLoading();render();}}
 if(!automaticSessionReady(serviceConfig())&&!(await ensureAutomaticService())){if(allowLocal||!automaticServiceEnabled())return null;throw Error(automaticConnectionMessage());}
 const owner=account.id,campaign=s.campaignId,connectionVersion=autoConnectVersions.get(owner)||0;aiBusy=true;showSceneLoading('Sua ideia está em análise',10,{kind:'analysis',work:sh});
 try{
  if(aiRetryAt()>Date.now())throw Object.assign(Error(s.live.aiStatus.message),{status:429,code:s.live.aiStatus.code,retryAt:aiRetryAt(),retryAfter:Math.ceil((aiRetryAt()-Date.now())/1000)});
  const payload={campaignId:campaign,project:{id:sh.id,title:sh.name,kind:sh.kind,genre:sh.genre,duration:sh.duration,concept:sh.concept,story:sh.story,intent:actualIntent,script},context:{difficulty:s.difficulty,reputation:s.reputation,crew:crewSnapshot(sh,''),networks:networks.map(n=>({id:n.id,name:n.name,threshold:n.threshold,reach:n.reach,focus:n.focus})),competition:s.world.filter(w=>w.status==='active').slice(-12).map(w=>({title:w.name,genre:w.genre,quality:w.quality}))}};
  setSceneStage('Aguardando parecer da IA','Critérios enviados: originalidade, coerência, personagens, impacto e execução.');
  const result=await serviceJSON('/v1/analyse',payload);setSceneStage('Conferindo o parecer','Validando notas, evidências, sugestões e prazo de produção.');if(!validAIReview(result.review))throw Object.assign(Error('O parecer da IA veio incompleto. Nenhum custo de produção foi aplicado.'),{status:502,code:'AI_INVALID_RESPONSE',retryAfter:60});
  if(account?.id!==owner||s?.campaignId!==campaign||!showBy(showId)||projectFingerprint(showBy(showId),script,actualIntent)!==key||(autoConnectVersions.get(owner)||0)!==connectionVersion)throw Error('A obra ou a conexão mudou durante a análise. Analise a revisão atual.');
  const review={...result.review,fingerprint:key,source:'ai',at:Date.now(),provider:result.provider||'Servidor do universo',cached:Boolean(result.cached)};
  localReviewMode=null;if(production)sh.aiPrepared=review;else{sh.aiConcept=review;sh.appeal=Math.round(25+aiNarrative(review)*.65);}
  s.live.lastAIAt=Date.now();applyAIStatus(result.aiStatus,true);save();completeAnalysisScene(review,result.cached);return review;
 }catch(e){
  const same=account?.id===owner&&s?.campaignId===campaign&&(autoConnectVersions.get(owner)||0)===connectionVersion;
  if(same){
   if(temporaryAIError(e)){const retryAfter=e.retryAfter||60;applyAIStatus({configured:e.code!=='AI_NOT_CONFIGURED',available:false,code:e.code||'AI_UNAVAILABLE',message:e.message,retryAt:e.retryAt,retryAfter});}
   else s.live.error=e.message;
   save();
   setSceneStage(temporaryAIError(e)?'IA em pausa':e.status===422?'Revise o conteúdo':'Parecer não confirmado',e.message,'error');
   if(allowLocal&&temporaryAIError(e)){setSceneStage('Usando análise local','Esta ação continua pelas regras do jogo; nenhum parecer de IA foi confirmado.','error');notice('IA em pausa. Esta ação continua com análise local, calculada pelas regras do jogo.');return null;}
  }
  throw e;
 }finally{await settleAnalysisScene();aiBusy=false;hideSceneLoading();render();}
}
function universeSummary(){
 return {campaignId:s.campaignId,studio:s.name,week:s.week,difficulty:s.difficulty,projects:s.shows.slice(-16).map(sh=>{const ep=sh.episodes.filter(e=>e.status==='aired').at(-1);return{id:sh.id,title:sh.name,kind:sh.kind,genre:sh.genre,concept:sh.concept,story:sh.story,intent:sh.intent,status:sh.status,fame:sh.fanBase,lastEpisode:ep?{id:ep.id,title:ep.title,number:ep.number,season:ep.season,quality:ep.quality,critics:ep.critics,public:ep.viewers,views:ep.viewership,likes:ep.likes,favorites:ep.favorites,actor:ep.actorName,intent:ep.intent,script:ep.script,credits:(ep.credits||[]).map(c=>({role:c.role,name:c.name,fame:c.fame}))}:null};}),cursor:s.live.serverCursor,networks:networks.map(n=>({id:n.id,name:n.name,focus:n.focus,threshold:n.threshold,reach:n.reach})),recentTexts:s.social.posts.slice(0,45).map(p=>p.text)};
}
let universeInFlight=false,universeQueued=false;
async function syncUniverse(force=false){
 if(!account||!s||universeInFlight||(!force&&serviceConfig()&&Date.now()-s.live.lastSyncAt<60000))return false;
 const owner=account.id,campaign=s.campaignId,connectionVersion=autoConnectVersions.get(owner)||0;universeInFlight=true;
 try{if(!automaticSessionReady(serviceConfig())&&!(await ensureAutomaticService()))return false;if(account?.id!==owner||s?.campaignId!==campaign||(autoConnectVersions.get(owner)||0)!==connectionVersion)return false;const result=await serviceJSON('/v1/sync',universeSummary());if(account?.id!==owner||s?.campaignId!==campaign||(autoConnectVersions.get(owner)||0)!==connectionVersion)return false;
  if(!Array.isArray(result.posts)||!Array.isArray(result.works)||!Number.isSafeInteger(result.cursor))throw Error('Sincronização do universo inválida.');
  for(const post of result.posts.slice(0,100)){
   if(!['tuiter','istagram','facibuk'].includes(post.platform)||typeof post.text!=='string'||post.text.length>2400||typeof post.name!=='string'||!['Jovem','Adulto','Senhor'].includes(post.ageGroup))continue;
   const key=hashText(post.text);if(s.social.used[key])continue;s.social.used[key]=true;
   const sh=s.shows.find(x=>String(x.id)===String(post.projectId)),id='online'+post.id;
   s.social.posts.unshift({id,platform:post.platform,user:post.name,voice:post.ageGroup,week:s.week,title:sh?.name||post.title||'Mercado',text:post.text,likes:Number.isFinite(post.likes)?Math.max(0,Math.round(post.likes)):0,replyTo:post.replyTo?'online'+post.replyTo:null,showId:sh?.id||null,at:post.at,source:'ai'});
   if(sh){const ep=sh.episodes.find(e=>String(e.id)===String(post.episodeId)&&e.status==='aired');if(ep&&!ep.comments.some(c=>c.text===post.text))ep.comments.push({id,name:post.name,voice:post.ageGroup,role:post.role==='Crítico'?'Crítico':'Fã',parent:null,text:post.text,source:'ai'});}
  }
  for(const w of result.works.slice(0,60)){
   if(s.live.importedWorks.includes(w.id)||!genres.includes(w.genre)||!networks.some(n=>n.id===w.networkId)||!Number.isInteger(w.productionWeeks)||w.productionWeeks<1||w.productionWeeks>6||!Number.isFinite(w.quality)||typeof w.title!=='string'||typeof w.premise!=='string')continue;
   s.live.importedWorks.push(w.id);s.world.push({id:'online-'+w.id,name:w.title.slice(0,80),kind:w.kind==='film'?'film':'series',genre:w.genre,networkId:w.networkId,studio:String(w.studio).slice(0,80),quality:clamp(Math.round(w.quality),5,100),viewers:0,status:'production',season:1,episode:0,debutWeek:s.week+w.productionWeeks,updatedWeek:s.week,history:[],productionWeeks:w.productionWeeks,source:'ai',premise:w.premise.slice(0,1800),story:w.story||{},intent:String(w.intent||'').slice(0,1200)});
   addNews('Projeto concorrente anunciado',w.title+' entra em produção na '+networkBy(w.networkId).name+'; estreia em '+w.productionWeeks+' semanas.','Mercado');
  }
  s.world=s.world.slice(-120);s.live.importedWorks=s.live.importedWorks.slice(-500);s.social.posts=s.social.posts.slice(0,600);s.live.serverCursor=result.cursor;s.live.lastSyncAt=Date.now();applyAIStatus(result.aiStatus,result.aiAvailable);save();
  const editing=['INPUT','SELECT','TEXTAREA'].includes(document.activeElement?.tagName);
  if(!editing&&(tab==='social'||(tab==='networks'&&subpage!=='owned')||(tab==='settings'&&subpage==='connection')))render();return true;
 }catch(e){if(account?.id===owner&&s?.campaignId===campaign&&(autoConnectVersions.get(owner)||0)===connectionVersion){s.live.error=e.message;s.live.mode=serviceConfig()?'connected':'local';s.live.lastSyncAt=Date.now();save();if(force)notice(e.message,true);}return false;}finally{universeInFlight=false;}
}
function queueUniverseSync(){if(universeQueued||!account||!s||campaignSetup||(!serviceConfig()&&!automaticServiceEnabled())||(autoRetryTimes.get(account.id)||0)>Date.now())return;universeQueued=true;setTimeout(()=>{universeQueued=false;syncUniverse(true);},500);}
setInterval(()=>{if(!account||!s||campaignSetup||aiBusy)return;const changed=addAmbientLocal();if(changed){save();if(tab==='social')render();}syncUniverse();},30000);
