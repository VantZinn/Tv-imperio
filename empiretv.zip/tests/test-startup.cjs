/* DOM checks for the complete startup; Android launch is checked by test-apk-startup.py. */
const {JSDOM,VirtualConsole,ResourceLoader}=require('jsdom');
const {IDBFactory}=require('fake-indexeddb');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.join(__dirname,'..'),assets=path.join(root,'app/src/main/assets');
const source=fs.readFileSync(path.join(assets,'index.html'),'utf8');
class Assets extends ResourceLoader{fetch(url){if(url.endsWith('/startup.js'))return Promise.resolve(fs.readFileSync(path.join(assets,'startup.js')));return null;}}
async function scenario(name,{blocked=false,unavailable=false,olderMethods=false,broken=false}={}){
 const errors=[],native={ready:0,failed:[]};const virtualConsole=new VirtualConsole();virtualConsole.on('jsdomError',e=>errors.push(e.message));
 let html=broken?source.replace('<script>','<script>throw new Error("Startup regression fixture");'):source;
 const dom=new JSDOM(html,{url:'https://appassets.androidplatform.net/assets/index.html',resources:new Assets(),runScripts:'dangerously',pretendToBeVisual:true,virtualConsole,beforeParse(w){
  w.TextEncoder=TextEncoder;w.TextDecoder=TextDecoder;w.scrollTo=()=>{};w.confirm=()=>true;
  w.EmpireNative={ready(){native.ready++;},failed(code){native.failed.push(code);}};
  if(!unavailable)w.indexedDB=blocked?{open(){const request={};w.setTimeout(()=>request.onblocked&&request.onblocked(),10);return request;}}:new IDBFactory();
  if(olderMethods){delete w.Array.prototype.at;delete w.Object.hasOwn;}
 }});
 try{
  const deadline=Date.now()+4000;
  while(!native.ready&&!native.failed.length&&Date.now()<deadline)await new Promise(r=>setTimeout(r,25));
  if(broken){assert.equal(native.ready,0);assert(native.failed.includes('SCRIPT_START_FAILED'));assert.equal(dom.window.EmpireStartup.status(),'failed');}
  else{
   assert.deepEqual(errors,[]);assert.equal(native.ready,1);assert.deepEqual(native.failed,[]);assert.equal(dom.window.EmpireStartup.status(),'ready');
   assert.equal(dom.window.document.getElementById('boot-screen'),null);assert.equal(dom.window.getComputedStyle(dom.window.document.getElementById('scene-loading')).display,'none');const toast=dom.window.document.getElementById('toast');assert.equal(dom.window.getComputedStyle(toast).display,'none');assert.equal(dom.window.getComputedStyle(toast).top,'auto');assert.equal(dom.window.getComputedStyle(toast).height,'auto');assert.equal(dom.window.getComputedStyle(toast).pointerEvents,'none');toast.textContent='Teste de mensagem';toast.className='toast show';assert.equal(dom.window.getComputedStyle(toast).display,'block');assert.equal(dom.window.getComputedStyle(toast).top,'auto');toast.textContent='';toast.className='toast';assert.equal(dom.window.getComputedStyle(toast).display,'none');assert(dom.window.document.getElementById('root').innerHTML.includes('data-action="auth"'));
   if(olderMethods){assert.equal(dom.window.Array.prototype.at.call([1,2],-1),2);assert(dom.window.Object.hasOwn({a:1},'a'));}
  }
  console.log('PASS: '+name);
 }finally{dom.window.close();}
}
(async()=>{
 await scenario('Primeira abertura: login pronto, carregamento removido e Android informado.');
 await scenario('Banco indisponível: abertura funciona com armazenamento local.',{unavailable:true});
 await scenario('Banco bloqueado: abertura usa a alternativa sem ficar presa.',{blocked:true});
 await scenario('WebView sem métodos recentes: compatibilidade instalada antes do jogo.',{olderMethods:true});
 await scenario('Erro de script: diagnóstico de abertura, sem sinal falso de sucesso.',{broken:true});
})().catch(e=>{console.error(e);process.exitCode=1;});
