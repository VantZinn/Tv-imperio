/* Single capture layer prevents an action from being handled by two navigation systems. */
function emGo(page){if(!EM_MENU.some(m=>m[0]===page))return;tab=page;subpage='';menuOpen=false;chosenShow=null;chosenReport=null;formDefaults={};render();}
function advanceVant(){
 if(!s.vant.touring)return;
 if(s.vant.index>=VANT_STEPS.length-1){s.vant.touring=false;tab='home';subpage='';save();render();return;}
 s.vant.index++;const step=VANT_STEPS[s.vant.index];tab=step[0];subpage=s.vant.index===3?'agency':s.vant.index===5?'studio':s.vant.index===13?'assistant':'';menuOpen=false;save();render();
}
function fireEmployee(tid){const t=talentBy(tid);if(!t||!s.hired.includes(tid))return;if(!confirm('Dispensar '+t.name+'? O salário deixa de ser pago nas próximas semanas. Produções gravadas mantêm os créditos.'))return;s.hired=s.hired.filter(x=>x!==tid);delete s.assignments[tid];delete s.contracts[tid];for(const sh of s.shows)for(const r of BETA_ROLES)if(sh.team[r]===tid)delete sh.team[r];marketCache=null;log(t.name+' foi dispensado.');update();notice('Contrato encerrado.');}
root.addEventListener('click',async e=>{
 const b=e.target.closest('[data-em-nav],[data-em-menu],[data-em-sub],[data-em-work],[data-em-work-close],[data-em-work-panel],[data-em-produce],[data-em-report],[data-em-open-report],[data-em-report-panel],[data-em-report-close],[data-em-refresh-agency],[data-em-reroll],[data-em-exchange],[data-em-powerup],[data-em-prestige],[data-em-motion],[data-em-local-review],[data-em-analyse],[data-em-sync],[data-em-disconnect],[data-em-vant-next],[data-em-vant-hide],[data-em-vant-restart],[data-fire]');
 if(!b||!account||!s)return;e.preventDefault();e.stopImmediatePropagation();if(aiBusy)return;
 try{
  if(b.hasAttribute('data-em-nav'))emGo(b.dataset.emNav);
  else if(b.hasAttribute('data-em-menu')){menuOpen=!menuOpen;render();}
  else if(b.hasAttribute('data-em-sub')){const allowed=EM_TABS[tab]||[];if(!allowed.some(t=>t[0]===b.dataset.emSub))return;if(tab==='social')socialNetwork=b.dataset.emSub;else subpage=b.dataset.emSub;chosenShow=null;chosenReport=null;render();}
  else if(b.hasAttribute('data-em-work')){chosenShow=Number(b.dataset.emWork);workPanel='overview';render();}
  else if(b.hasAttribute('data-em-work-close')){chosenShow=null;render();}
  else if(b.hasAttribute('data-em-work-panel')){if(!['overview','writing','team','distribution','analysis'].includes(b.dataset.emWorkPanel))return;workPanel=b.dataset.emWorkPanel;render();}
  else if(b.hasAttribute('data-em-produce')){tab='production';subpage='studio';chosenShow=Number(b.dataset.emProduce);render();}
  else if(b.hasAttribute('data-em-report')||b.hasAttribute('data-em-open-report')){if(b.hasAttribute('data-em-open-report')){tab='reports';subpage='';}chosenReport=Number(b.dataset.emReport||b.dataset.emOpenReport);reportPanel='overview';render();}
  else if(b.hasAttribute('data-em-report-close')){chosenReport=null;render();}
  else if(b.hasAttribute('data-em-report-panel')){if(!['overview','creative','audience','comments','credits'].includes(b.dataset.emReportPanel))return;reportPanel=b.dataset.emReportPanel;render();}
  else if(b.hasAttribute('data-em-refresh-agency'))refreshAgency();
  else if(b.hasAttribute('data-em-reroll'))rerollMission(b.dataset.emReroll);
  else if(b.hasAttribute('data-em-exchange'))exchangeMF(b.dataset.emExchange);
  else if(b.hasAttribute('data-em-powerup'))mfPowerup(b.dataset.emPowerup);
  else if(b.hasAttribute('data-em-prestige'))claimPrestige(b.dataset.emPrestige);
  else if(b.hasAttribute('data-em-motion'))setMotionMode(b.dataset.emMotion);
  else if(b.hasAttribute('data-em-local-review'))await analyseLocalWork(Number(b.dataset.emLocalReview));
  else if(b.hasAttribute('data-em-analyse')){await analyseWork(Number(b.dataset.emAnalyse));workPanel='analysis';render();}
  else if(b.hasAttribute('data-em-sync')){if(serviceConfig())await syncUniverse(true);else{if(addAmbientLocal(Date.now(),true))save();render();notice('Conversa local atualizada.');}}
  else if(b.hasAttribute('data-em-disconnect'))disconnectService();
  else if(b.hasAttribute('data-em-vant-next'))advanceVant();
  else if(b.hasAttribute('data-em-vant-hide')){s.vant.collapsed=true;save();render();}
  else if(b.hasAttribute('data-em-vant-restart')){s.vant.index=0;s.vant.touring=true;s.vant.collapsed=false;tab='home';subpage='';save();render();}
  else if(b.hasAttribute('data-fire'))fireEmployee(b.dataset.fire);
 }catch(error){hideSceneLoading();notice(error.message||'Não foi possível concluir a ação.',true);}
},true);
root.addEventListener('submit',async e=>{
 const form=e.target.closest('form[data-action]');if(!form||!account||!s)return;const action=form.dataset.action;
 if(!['produce','pitch','connectUniverse'].includes(action))return;
 e.preventDefault();e.stopImmediatePropagation();if(aiBusy)return;const fd=new FormData(form);
 try{
  if(action==='connectUniverse'){await connectService(fd);return;}
  const sh=showBy(fd.get('showId'));if(!sh)return;
  if(action==='pitch'){if(serviceConfig())await analyseWork(sh.id,'',null,false,true);pitch(sh.id,String(fd.get('network')));}
  else{if(serviceConfig())await analyseWork(sh.id,String(fd.get('script')||'').trim().slice(0,3500),String(fd.get('intent')||sh.intent||'').trim().slice(0,1200),true,true);produce(fd);}
 }catch(error){notice(error.message||'Não foi possível concluir a ação.',true);}
},true);
root.addEventListener('change',e=>{
 if(e.target.matches?.('[data-em-kind]')){const select=e.target.closest('form')?.querySelector('[data-em-duration]'),film=e.target.value==='film';if(select)select.innerHTML=(film?[60,90,120,150]:[20,30,45,60]).map(n=>'<option value="'+n+'" '+(n===(film?90:45)?'selected':'')+'>'+n+' minutos</option>').join('');return;}
 if(e.target.matches?.('[data-em-production-select]')){chosenShow=Number(e.target.value);render();return;}
});
fireTalent=fireEmployee;
const finalSequelBase=makeSequel;
makeSequel=function(ident){const before=s.shows.length;finalSequelBase(ident);if(s.shows.length>before){chosenShow=s.shows.at(-1).id;workPanel='overview';subpage='';save();render();queueUniverseSync();}};
const finalFundingBase=evaluateFunding;
evaluateFunding=async function(fd){try{const sh=showBy(fd.get('showId'));if(serviceConfig()&&sh)await analyseWork(sh.id,'',null,false,true);finalFundingBase(fd);}catch(e){notice(e.message,true);}};
const finalCreateBase=createShow;
createShow=function(fd){const before=s.shows.length;finalCreateBase(fd);if(s.shows.length===before)return;chosenShow=s.shows.at(-1).id;workPanel='overview';tab='shows';subpage='';save();render();queueUniverseSync();};
const finalEditBase=editStory;
editStory=function(fd){const sh=showBy(fd.get('showId'));if(!sh)return;const before=projectFingerprint(sh);finalEditBase(fd);if(projectFingerprint(sh)!==before){sh.aiConcept=null;sh.aiPrepared=null;save();render();queueUniverseSync();}};
const finalSafeBase=safeState;
safeState=function(v){return finalSafeBase(v)&&(!v.fameWallet||validWallet(v.fameWallet))&&(!v.market||(typeof v.market==='object'&&v.market.networks&&typeof v.market.networks==='object'));};
window.EmpireNavigation={back(){
 if(aiBusy)return true;
 if(menuOpen){menuOpen=false;render();return true;}
 if(s?.vant.touring){s.vant.touring=false;save();render();return true;}
 if(chosenReport){chosenReport=null;render();return true;}
 if(chosenShow&&tab==='shows'){chosenShow=null;render();return true;}
 if(subpage&&tab!=='social'){subpage='';render();return true;}
 if(s&&tab!=='home'){emGo('home');return true;}
 return false;
}};
if(window.addEventListener)window.addEventListener('pageshow',()=>{if(s){migrateFinal(s);if(addAmbientLocal())save();queueUniverseSync();}});
