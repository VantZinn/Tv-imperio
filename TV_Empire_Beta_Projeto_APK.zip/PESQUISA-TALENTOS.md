# Pesquisa de talentos — TV Empire beta

Pesquisa consultada em 11 de outubro de 2026. O catálogo contém 100 pessoas distintas usadas como referências para personagens humorísticos. A seleção combina créditos de obras reconhecidas, prêmios, biografias de carreira e campanhas importantes. Não existe um ranking universal e comparável dos “100 melhores” entre atuação, roteiro, direção, showrunning, marketing e dublagem; este catálogo é uma seleção editorial para o jogo, sem ordem de mérito.

| Formação | Referências | Candidatos por ciclo |
|---|---:|---:|
| Showrunner | 18 | 4 |
| Roteirista | 18 | 4 |
| Direção | 18 | 4 |
| Atuação | 20 | 4 |
| Marketing | 10 | 4 |
| Dublagem | 16 | 4 |
| **Total** | **100** | **24** |

## Catálogo e interpretação

O arquivo TALENTOS-100.csv contém cada nome real pesquisado, sua versão humorística, especialidades, obra ou carreira de referência, atributos fictícios e fonte consultada. Pessoas com carreiras em diversas áreas foram alocadas em uma única formação para evitar duplicação. A seleção inclui profissionais históricos; a presença de um personagem não afirma que a pessoa real esteja atualmente disponível para contratação.

As especialidades são **inferências editoriais para o jogo**, inspiradas em aspectos das carreiras; não são classificações oficiais nem uma avaliação de todos os trabalhos de cada pessoa. Técnica, fama, salários e raridade são parâmetros fictícios de balanceamento. Os dados de emissoras e prêmios do universo do jogo também são simulados, e não contratos reais ou informações financeiras de empresas.

## Probabilidade de aparição

A chance inicial no CSV assume nenhum contratado entre os 100 talentos. Dentro de cada formação, o algoritmo distribui quatro inclusões esperadas conforme o peso de aparição. A soma das probabilidades individuais é 400%, porque quatro candidatos são escolhidos, e não apenas um. A amostragem garante quatro nomes distintos por formação. Após contratar alguém, a chance é recalculada entre as pessoas restantes; o jogo exibe a chance atual. Quando faltam profissionais daquela formação, aprendizes fictícios completam as quatro vagas. A renovação acontece a cada cinco minutos do relógio do dispositivo.

## Fontes e critérios

- **Cinema:** registros históricos de indicados e vencedores da [Academy of Motion Picture Arts and Sciences](https://www.oscars.org/oscars/ceremonies). O CSV aponta a edição que verifica uma obra ou crédito relevante para cada referência. As edições representam realizações históricas, sem afirmar que todo crédito mencionado tenha vencido um prêmio.
- **Televisão e showrunners:** [Television Academy](https://www.televisionacademy.com/bios/vince-gilligan), biografias individuais e créditos; [Netflix sobre os irmãos Duffer](https://about.netflix.com/pt_br/news/stranger-things-renewed-for-season-4-as-netflix-makes-overall-deal-with-the-duffer-brothers).
- **Direção adicional:** [Festival de Cannes — Decision to Leave](https://www.festival-cannes.com/en/festival/films/heojil-kyolshim) e [Marvel — Black Panther](https://www.marvel.com/articles/movies/sterling-k-brown-signs-on-to-marvel-s-black-panther).
- **Marketing:** artigos e comunicados de Amazon Advertising, NBCUniversal, Paramount, Amblin, IMAX e estúdios via PR Newswire; caso de campanha publicado pela AANA. Esses documentos verificam experiência ou participação histórica, sem afirmar cargos atuais.
- **Dublagem:** créditos e entrevistas da Television Academy, Disney, Paramount e Sony/DC. Para as referências brasileiras, reportagem da Superinteressante relacionando profissionais e personagens. O CSV fornece as URLs individuais.

As fontes embasam as referências de carreira; não avalizam nem participam deste jogo. Os nomes dos personagens e suas opiniões são fictícios. Não foram copiadas biografias ou avaliações dos profissionais.

© V&D Digital. Todos os direitos reservados.
