/* Online AI is opt-in. No provider secret is stored or requested in the APK. */
function serviceKey(){return 'empire-universe-'+(account?.id||'guest');}
function serviceConfig(){try{const c=JSON.parse(localStorage.getItem(serviceKey())||'null');return c&&typeof c.url==='string'&&typeof c.token==='string'?c:null;}catch{return null;}}
function validServiceURL(raw){try{const u=new URL(raw);if(u.username||u.password||u.search||u.hash)return null;if(u.protocol!=='https:'&&!(['localhost','127.0.0.1'].includes(u.hostname)&&u.protocol==='http:'))return null;return u.origin+u.pathname.replace(/\/$/,'');}catch{return null;}}
function aiRetryAt(){const value=s?.live?.aiStatus?.retryAt;return Number.isFinite(value)?value:0;}
function aiServiceMessage(){
 const status=s?.live?.aiStatus;
 if(status&&status.available===false){const next=aiRetryAt();return status.message+(next>Date.now()?' Nova tentativa após '+new Date(next).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})+'.':'');}
 return s?.live?.lastAIAt?'Servidor conectado. Última geração de IA confirmada em '+new Date(s.live.lastAIAt).toLocaleString('pt-BR')+'.':'Servidor conectado; a geração de IA será confirmada ao receber um parecer válido.';
}
function aiQuotaDetails(){
 const q=s?.live?.aiStatus?.quotas;if(!q||!q.global||!q.account||!q.automatic)return '';
 const count=x=>Number.isSafeInteger(x.used)&&Number.isSafeInteger(x.limit)?x.used+' / '+x.limit:'—';
 return '<details><summary>Limites da IA</summary>'+kpis([['Chamadas do servidor',count(q.global)],['Análises desta conta',count(q.account)],['Geração automática',count(q.automatic)]])+'<p>As chamadas automáticas têm uma parcela limitada para preservar análises dos jogadores. Estes limites são do servidor; a cota gratuita do provedor também se aplica. Tentativas enviadas ao provedor são contabilizadas mesmo quando falham.</p>'+(Number.isFinite(q.resetAt)?'<p>Renovação do limite diário: '+esc(new Date(q.resetAt).toLocaleString('pt-BR'))+'.</p>':'')+'</details>';
}
function applyAIStatus(info,configured=true){
 if(!s)return;
 if(info&&typeof info.available==='boolean'){
  const seconds=Number(info.retryAfter),retryAt=seconds>0?Date.now()+Math.min(129600,seconds)*1000:Number.isFinite(info.retryAt)?info.retryAt:0;
  s.live.aiStatus={configured:info.configured!==false,available:info.available,code:String(info.code||'').slice(0,80),message:String(info.message||'A IA está em pausa.').slice(0,240),retryAt,quotas:info.quotas||null};
 }else if(!s.live.aiStatus||aiRetryAt()<=Date.now())s.live.aiStatus={configured,available:configured,code:configured?'':'AI_NOT_CONFIGURED',message:configured?'':'A IA ainda não foi configurada no servidor.',retryAt:0,quotas:null};
 s.live.mode=s.live.aiStatus.available?'online':'connected';s.live.error=s.live.aiStatus.available?'':aiServiceMessage();
}
function temporaryAIError(e){return [429,502,503,504].includes(e.status);}
async function serviceJSON(route,body={},override=null){
 const c=override||serviceConfig();if(!c)throw Error('Conecte um servidor do universo em Configurações.');
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),100000);
 try{const response=await fetch(c.url+route,{method:'POST',headers:{'Content-Type':'application/json',...(c.token?{Authorization:'Bearer '+c.token}:{})},body:JSON.stringify(body),signal:controller.signal});
  let data;try{data=await response.json();}catch{throw Object.assign(Error('O servidor não devolveu uma resposta válida. O jogo pode continuar com análise local.'),{status:502,code:'AI_SERVER_INVALID_RESPONSE',retryAfter:60});}
  if(!response.ok){const retryAfter=Number(data.retryAfter||response.headers?.get?.('retry-after'))||0;throw Object.assign(Error(String(data.error||'Servidor indisponível.').slice(0,240)),{status:response.status||503,code:String(data.code||'').slice(0,80),retryAfter,retryAt:Number(data.retryAt)||0});}return data;
 }catch(e){if(e.name==='AbortError')throw Object.assign(Error('A conexão com o servidor demorou demais. O progresso foi preservado.'),{status:504,code:'AI_SERVER_TIMEOUT',retryAfter:60});if(e instanceof TypeError)throw Object.assign(Error('Não foi possível conectar ao servidor. O jogo pode continuar com análise local.'),{status:503,code:'AI_SERVER_CONNECTION',retryAfter:60});throw e;}finally{clearTimeout(timer);}
}
function validAIReview(r){
 const string=v=>typeof v==='string'&&v.length<=2400;
 return r&&string(r.summary)&&string(r.verdict)&&string(r.hook)&&r.scores&&['originality','coherence','characters','impact','execution'].every(k=>Number.isInteger(r.scores[k])&&r.scores[k]>=0&&r.scores[k]<=100)&&Number.isInteger(r.productionWeeks)&&r.productionWeeks>=1&&r.productionWeeks<=6&&Array.isArray(r.strengths)&&r.strengths.length<=8&&r.strengths.every(string)&&Array.isArray(r.risks)&&r.risks.length<=8&&r.risks.every(x=>['aspect','evidence','impact','advice'].every(k=>string(x[k])))&&Array.isArray(r.comments)&&r.comments.length<=24&&r.comments.every(c=>string(c.name)&&string(c.text)&&['Jovem','Adulto','Senhor'].includes(c.ageGroup)&&['tuiter','istagram','facibuk'].includes(c.platform)&&Number.isInteger(c.replyTo));
}
async function connectService(fd){
 const url=validServiceURL(String(fd.get('url')||'')),name=String(fd.get('username')||'').trim(),password=String(fd.get('password')||''),register=fd.get('mode')==='register';
 if(!url)throw Error('Use a URL HTTPS do servidor. Localhost HTTP é aceito apenas para desenvolvimento.');
 const owner=account.id,configuration={url,token:''};
 showSceneLoading('Conectando seu universo',25);
 try{const result=await serviceJSON('/v1/auth/'+(register?'register':'login'),{username:name,password},configuration);
  if(account?.id!==owner)return;localStorage.setItem(serviceKey(),JSON.stringify({url,token:result.token,username:name}));s.live.serverCursor=0;s.live.lastSyncAt=0;applyAIStatus(result.aiStatus,result.aiAvailable);save();await syncUniverse(true);notice(aiServiceMessage());
 }finally{hideSceneLoading();render();}
}
function disconnectService(){try{localStorage.removeItem(serviceKey());}catch{}if(s){s.live.mode='local';s.live.error='';s.live.aiStatus=null;save();render();}notice('Modo local ativo. Seu progresso continua.');}
async function analyseWork(showId,script='',intent=null,production=false,allowLocal=false){
 const sh=showBy(showId);if(!sh)throw Error('Obra não encontrada.');
 const actualIntent=intent??sh.intent,key=projectFingerprint(sh,script,actualIntent),prior=production?sh.aiPrepared:sh.aiConcept;
 if(prior?.fingerprint===key&&validAIReview(prior)){aiBusy=true;showSceneLoading('Revisitando seu parecer',100,{kind:'analysis',work:sh});try{completeAnalysisScene(prior,true);await settleAnalysisScene();return prior;}finally{aiBusy=false;hideSceneLoading();render();}}
 if(!serviceConfig())return null;
 const owner=account.id,campaign=s.campaignId;aiBusy=true;showSceneLoading('Sua ideia está em análise',10,{kind:'analysis',work:sh});
 try{
  if(aiRetryAt()>Date.now())throw Object.assign(Error(s.live.aiStatus.message),{status:429,code:s.live.aiStatus.code,retryAt:aiRetryAt(),retryAfter:Math.ceil((aiRetryAt()-Date.now())/1000)});
  const payload={campaignId:campaign,project:{id:sh.id,title:sh.name,kind:sh.kind,genre:sh.genre,duration:sh.duration,concept:sh.concept,story:sh.story,intent:actualIntent,script},context:{difficulty:s.difficulty,reputation:s.reputation,crew:crewSnapshot(sh,''),networks:networks.map(n=>({id:n.id,name:n.name,threshold:n.threshold,reach:n.reach,focus:n.focus})),competition:s.world.filter(w=>w.status==='active').slice(-12).map(w=>({title:w.name,genre:w.genre,quality:w.quality}))}};
  setSceneStage('Aguardando parecer da IA','Critérios enviados: originalidade, coerência, personagens, impacto e execução.');
  const result=await serviceJSON('/v1/analyse',payload);setSceneStage('Conferindo o parecer','Validando notas, evidências, sugestões e prazo de produção.');if(!validAIReview(result.review))throw Object.assign(Error('O parecer da IA veio incompleto. Nenhum custo de produção foi aplicado.'),{status:502,code:'AI_INVALID_RESPONSE',retryAfter:60});
  if(account?.id!==owner||s?.campaignId!==campaign||!showBy(showId)||projectFingerprint(showBy(showId),script,actualIntent)!==key)throw Error('A obra mudou durante a análise. Analise a revisão atual.');
  const review={...result.review,fingerprint:key,source:'ai',at:Date.now(),provider:result.provider||'Servidor do universo',cached:Boolean(result.cached)};
  if(production)sh.aiPrepared=review;else{sh.aiConcept=review;sh.appeal=Math.round(25+aiNarrative(review)*.65);}
  s.live.lastAIAt=Date.now();applyAIStatus(result.aiStatus,true);save();completeAnalysisScene(review,result.cached);return review;
 }catch(e){
  const same=account?.id===owner&&s?.campaignId===campaign;
  if(same){
   if(temporaryAIError(e)){const retryAfter=e.retryAfter||60;applyAIStatus({configured:e.code!=='AI_NOT_CONFIGURED',available:false,code:e.code||'AI_UNAVAILABLE',message:e.message,retryAt:e.retryAt,retryAfter});}
   else s.live.error=e.message;
   save();
   setSceneStage(temporaryAIError(e)?'IA em pausa':e.status===422?'Revise o conteúdo':'Parecer não confirmado',e.message,'error');
   if(allowLocal&&temporaryAIError(e)){setSceneStage('Usando análise local','Esta ação continua pelas regras do jogo; nenhum parecer de IA foi confirmado.','error');notice('IA em pausa. Esta ação continua com análise local, calculada pelas regras do jogo.');return null;}
  }
  throw e;
 }finally{await settleAnalysisScene();aiBusy=false;hideSceneLoading();render();}
}
function universeSummary(){
 return {campaignId:s.campaignId,studio:s.name,week:s.week,difficulty:s.difficulty,projects:s.shows.slice(-16).map(sh=>{const ep=sh.episodes.filter(e=>e.status==='aired').at(-1);return{id:sh.id,title:sh.name,kind:sh.kind,genre:sh.genre,concept:sh.concept,story:sh.story,intent:sh.intent,status:sh.status,fame:sh.fanBase,lastEpisode:ep?{id:ep.id,title:ep.title,number:ep.number,season:ep.season,quality:ep.quality,critics:ep.critics,public:ep.viewers,views:ep.viewership,likes:ep.likes,favorites:ep.favorites,actor:ep.actorName,intent:ep.intent,script:ep.script,credits:(ep.credits||[]).map(c=>({role:c.role,name:c.name,fame:c.fame}))}:null};}),cursor:s.live.serverCursor,networks:networks.map(n=>({id:n.id,name:n.name,focus:n.focus,threshold:n.threshold,reach:n.reach})),recentTexts:s.social.posts.slice(0,45).map(p=>p.text)};
}
let universeInFlight=false,universeQueued=false;
async function syncUniverse(force=false){
 if(!account||!s||!serviceConfig()||universeInFlight||(!force&&Date.now()-s.live.lastSyncAt<60000))return false;
 const owner=account.id,campaign=s.campaignId;universeInFlight=true;
 try{const result=await serviceJSON('/v1/sync',universeSummary());if(account?.id!==owner||s?.campaignId!==campaign)return false;
  if(!Array.isArray(result.posts)||!Array.isArray(result.works)||!Number.isSafeInteger(result.cursor))throw Error('Sincronização do universo inválida.');
  for(const post of result.posts.slice(0,100)){
   if(!['tuiter','istagram','facibuk'].includes(post.platform)||typeof post.text!=='string'||post.text.length>2400||typeof post.name!=='string'||!['Jovem','Adulto','Senhor'].includes(post.ageGroup))continue;
   const key=hashText(post.text);if(s.social.used[key])continue;s.social.used[key]=true;
   const sh=s.shows.find(x=>String(x.id)===String(post.projectId)),id='online'+post.id;
   s.social.posts.unshift({id,platform:post.platform,user:post.name,voice:post.ageGroup,week:s.week,title:sh?.name||post.title||'Mercado',text:post.text,likes:Number.isFinite(post.likes)?Math.max(0,Math.round(post.likes)):0,replyTo:post.replyTo?'online'+post.replyTo:null,showId:sh?.id||null,at:post.at,source:'ai'});
   if(sh){const ep=sh.episodes.find(e=>String(e.id)===String(post.episodeId)&&e.status==='aired');if(ep&&!ep.comments.some(c=>c.text===post.text))ep.comments.push({id,name:post.name,voice:post.ageGroup,role:post.role==='Crítico'?'Crítico':'Fã',parent:null,text:post.text,source:'ai'});}
  }
  for(const w of result.works.slice(0,60)){
   if(s.live.importedWorks.includes(w.id)||!genres.includes(w.genre)||!networks.some(n=>n.id===w.networkId)||!Number.isInteger(w.productionWeeks)||w.productionWeeks<1||w.productionWeeks>6||!Number.isFinite(w.quality)||typeof w.title!=='string'||typeof w.premise!=='string')continue;
   s.live.importedWorks.push(w.id);s.world.push({id:'online-'+w.id,name:w.title.slice(0,80),kind:w.kind==='film'?'film':'series',genre:w.genre,networkId:w.networkId,studio:String(w.studio).slice(0,80),quality:clamp(Math.round(w.quality),5,100),viewers:0,status:'production',season:1,episode:0,debutWeek:s.week+w.productionWeeks,updatedWeek:s.week,history:[],productionWeeks:w.productionWeeks,source:'ai',premise:w.premise.slice(0,1800),story:w.story||{},intent:String(w.intent||'').slice(0,1200)});
   addNews('Projeto concorrente anunciado',w.title+' entra em produção na '+networkBy(w.networkId).name+'; estreia em '+w.productionWeeks+' semanas.','Mercado');
  }
  s.world=s.world.slice(-120);s.live.importedWorks=s.live.importedWorks.slice(-500);s.social.posts=s.social.posts.slice(0,600);s.live.serverCursor=result.cursor;s.live.lastSyncAt=Date.now();applyAIStatus(result.aiStatus,result.aiAvailable);save();
  const editing=['INPUT','SELECT','TEXTAREA'].includes(document.activeElement?.tagName);
  if(!editing&&(tab==='social'||(tab==='networks'&&subpage!=='owned')||(tab==='settings'&&subpage==='connection')))render();return true;
 }catch(e){if(account?.id===owner&&s?.campaignId===campaign){s.live.error=e.message;s.live.lastSyncAt=Date.now();save();if(force)notice(e.message,true);}return false;}finally{universeInFlight=false;}
}
function queueUniverseSync(){if(universeQueued||!serviceConfig())return;universeQueued=true;setTimeout(()=>{universeQueued=false;syncUniverse(true);},500);}
setInterval(()=>{if(!account||!s||campaignSetup||aiBusy)return;const changed=addAmbientLocal();if(changed){save();if(tab==='social')render();}syncUniverse();},30000);
