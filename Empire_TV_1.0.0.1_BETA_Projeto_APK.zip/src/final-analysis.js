/* Explainable local evaluation; reference cases are fictional examples, never facts about the player's work. */
/* LOCAL_ANALYSIS_CATALOG */
/* LOCAL_ANALYSIS_PACK */
const localModules=new Map(),localModuleTasks=new Map(),localModuleErrors=new Map(),localProjectionCache=new Map();
let localReviewMode=null;
function viewingLocalReview(sh){return localReviewMode?.owner===account?.id&&localReviewMode?.showId===sh.id;}
const localStop=new Set(LOCAL_ANALYSIS_CATALOG.stopwords);
const localSuffix=/(amentos|imentos|amento|imento|idades|idade|mente|acoes|acao|icoes|icao|ados|adas|ando|endo|indo|aram|eram|iram|ado|ada|ores|ora|oes|ais)$/;
const LOCAL_SIGNALS={
 agent:'medic|professor|inventor|cozinheir|carteir|musicist|mecanic|fotograf|agricultor|advogad|pescador|estudant|arquivist|atleta|zelador|jornalist|artes|programador|bibliotec|motorist|pesquisador|vizinh|cuidador|projecionist|irma|familia|grupo|casal|crianca|jovem|velho|idos|detetiv|policial|cientist|protagonist|personagem|\\bela\\b|\\bele\\b|participante|morador',
 goal:'salva|resgata|recupera|procura|busca|revela|protege|proteger|constr|vence|vencer|derrota|chega|chegar|encontra|encontrar|conseg|descobr|evita|evitar|imped|preserva|preservar|conclu|termina|terminar|reune|reunir|reconstr|ensina|ensinar|aprend|investig|testa|testar|cria|criar|devolve|devolver|entrega|entregar|vender|vende|compra|compra|liberta|libertar|atravessa|atravessar|volta|voltar|retorna|retornar|foge|fugir|escapa|escapar|assume|assumir|transmite|transmitir|cumpr|repara|reparar|narrar|documenta|comparar|compara|verifica|verificar|acompanha|acompanhar',
 need:'precisa|necessita|quer|deseja|pretende|decid|promet|sonha|tent|deve|objetivo|pergunta|investig|busca|procura',
 opposition:'mas\\b|porem|enquanto|contra|apesar|imped|oculta|esconde|bloque|ameac|obstacul|rival|adversar|inimig|recusa|proib|resist|corta|fech|destroi|destru|tormenta|tempestad|falta|escass|limite|prazo|nao pode|nao consegue|sem dinheiro|sem acesso|discord|contradiz|contradic|negad',
 stake:'perd|perder|perigo|risco|arrisc|custo|preco|sacrific|morr|morte|vida|demit|emprego|carreira|familia|culpa|confianca|liberdade|heranca|consequenc|amea|ausencia|ultimo|ultima|fech|rejeic|fracass|despedida',
 personal:'porque|para que|promet|mae|pai|irma|filh|familia|culpa|luto|amor|lealdade|desejo|crenc|memoria|vergonha|arrepend|orgulho|responsab|confianca|pertenc|identidade|necessidade|curiosidade',
 choice:'decid|escolh|renuncia|renunciar|sacrific|sacrificar|abre mao|abrir mao|aceita|aceitar|recusa|recusar|prefere|preferir|em vez|ou\\b|assume|assumir|admite|admitir|repara|reparar|revela|revelar|transmite|transmitir',
 change:'perde|perdem|perder|salva|salvar|escapa|escapam|escapar|descobre|descobrem|descobrir|mud|transform|aprende|aprender|reconcil|conquist|consegue|conseguem|revela|revelar|aceita|aceitar|devolve|devolver|permite|permitir|liberta|libertar|reconstro|reconstru|separa|separar|repar|repara|resolve|resolver|reformula|reformular|conclui|concluir|vence|vencer|termina|terminar',
 link:'porque|por isso|portanto|consequenc|entao|assim|ao descobrir|ao revelar|ao decidir|quando|em troca|para salvar|para proteger|obriga|forca|provoca|resulta|causa|leva a|\\bse\\b.*\\bnao\\b',
 preparation:'pista|antes|desde|aprende|regra|limite|prepara|repet|observa|promessa|ensaio|primeir|sinal|prenunci|mostra',
 rule:'regra|limite|so pode|apenas|nao pode|cada vez|sempre que|custo|preco|em troca|condicao|exige|contrapartida|consentimento|criterio',
 research:'fonte|entrevista|arquivo|documento|pesquisa|registro|evidencia|testemunha|verifica|verificar|contraponto|dados|hipotese|compar|observa|relato',
 question:'pergunta|por que|porque|como|quem|investig|hipotese|entender|compreender|descobrir|verificar|acompanha',
 format:'rodada|prova|participante|competicao|eliminacao|voto|premio|criterio|regra|formato|consentimento',
 style:'humor|montagem|fragment|ponto de vista|perspectiv|visual|silencio|cor\\b|cores|som|ritmo|estrutura|tom|circular|cronologi|contraste|metafor|simbol|imagem|anim|arquivo|rotina|primeira pessoa|nao linear',
 theme:'responsab|identidade|pertenc|luto|memoria|cuidado|justica|poder|amor|perdao|culpa|autoria|confianca|desigual|medo|verdade|liberdade|relacao|reconciliacao',
 miracle:'de repente tudo se resolve|resolve tudo sem|sem motivo|do nada.*resolve|poder novo.*resolve|magicamente.*resolve|tudo.*era.*sonho',
 passive:'alguem resolve tudo|outra pessoa resolve tudo|so espera|apenas espera|nao faz nada|tudo acontece com',
 generic:'historia muito boa|historia incrivel|muito incrivel|sera um sucesso|vai ser sucesso|coisas acontecem|muitas coisas|um desafio|uma aventura|muito emocionante|algo acontece'
};
const localRx=Object.fromEntries(Object.entries(LOCAL_SIGNALS).map(([key,value])=>[key,new RegExp(value)]));
function localWords(text){return (norm(String(text||'')).match(/[a-z]{3,}/g)||[]).filter(w=>!localStop.has(w)).map(w=>{const stem=w.length>6?w.replace(localSuffix,''):w;return stem.length>=3?stem:w;});}
function localSignal(name,text){return localRx[name].test(norm(text||''));}
function localSnippet(text,name=''){const sentences=String(text||'').split(/[.!?;\n]+\s*/).filter(Boolean);const selected=name?sentences.find(x=>localSignal(name,x)):sentences[0];return shortText(selected||String(text||''),220);}
function localProjection(word){
 if(localProjectionCache.has(word))return localProjectionCache.get(word);
 let seed=2166136261;for(let i=0;i<word.length;i++)seed=Math.imul(seed^word.charCodeAt(i),16777619)>>>0;
 const vector=new Float32Array(128);for(let i=0;i<128;i++){let x=(seed^Math.imul(i+1,2654435761))>>>0;x^=x>>>16;x=Math.imul(x,2246822507)>>>0;x^=x>>>13;x=Math.imul(x,3266489909)>>>0;x^=x>>>16;vector[i]=(x>>>8)/8388608-1;}
 if(localProjectionCache.size>3000)localProjectionCache.clear();localProjectionCache.set(word,vector);return vector;
}
function localVector(text,weights){const counts=new Map();for(const w of localWords(text))counts.set(w,(counts.get(w)||0)+1);const out=new Float32Array(128);for(const[w,n]of counts){const vector=localProjection(w),weight=(weights[w]||1)*(1+Math.log(n));for(let i=0;i<128;i++)out[i]+=vector[i]*weight;}let magnitude=0;for(const v of out)magnitude+=v*v;magnitude=Math.sqrt(magnitude)||1;for(let i=0;i<128;i++)out[i]/=magnitude;return out;}
async function loadLocalAnalysisModule(genre,force=false){
 if(localModules.has(genre)){const old=localModules.get(genre);localModules.delete(genre);localModules.set(genre,old);return old;}
 if(localModuleTasks.has(genre))return localModuleTasks.get(genre);
 if(localModuleErrors.has(genre)&&!force)return null;
 const meta=LOCAL_ANALYSIS_PACK.modules.find(m=>m.name===genre);if(!meta||typeof window.fetch!=='function')return null;
 const task=(async()=>{const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
  try{
   const base=new URL('analysis/',document.baseURI),results=await Promise.all([window.fetch(new URL(meta.module,base).href,{signal:controller.signal}),window.fetch(new URL(meta.index,base).href,{signal:controller.signal})]);
   if(results.some(r=>!r.ok))throw Error('Recursos locais indisponíveis.');
   const [jsonBytes,bytes]=await Promise.all(results.map(r=>r.arrayBuffer()));
   const hashes=await Promise.all([jsonBytes,bytes].map(async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',value)),v=>v.toString(16).padStart(2,'0')).join('')));
   if(hashes[0]!==meta.moduleSha256||hashes[1]!==meta.indexSha256)throw Error('O módulo local precisa ser reinstalado.');
   const data=JSON.parse(new TextDecoder().decode(jsonBytes));
   if(data.version!==1||data.genre!==genre||data.dimensions!==128||!Array.isArray(data.cases)||data.cases.length!==meta.cases||bytes.byteLength!==meta.cases*128*2||!data.weights||Object.values(data.weights).some(w=>!Number.isFinite(w)||w<1||w>20)||data.cases.some(c=>typeof c.id!=='string'||typeof c.premise!=='string'||typeof c.decision!=='string'||typeof c.revision!=='string'||!Array.isArray(c.checks)))throw Error('O módulo local precisa ser reinstalado.');
   const module={...data,vectors:new Int16Array(bytes)};localModuleErrors.delete(genre);localModules.set(genre,module);while(localModules.size>2)localModules.delete(localModules.keys().next().value);return module;
  }catch(e){localModuleErrors.set(genre,'O motor local continua funcionando. As referências ampliadas deste gênero não puderam ser carregadas.');return null;}finally{clearTimeout(timer);}
 })();localModuleTasks.set(genre,task);try{return await task;}finally{localModuleTasks.delete(genre);}
}
function localReferences(sh,script='',intent=sh.intent){
 const module=localModules.get(sh.genre);if(!module)return[];const text=[sh.concept,...Object.values(sh.story||{}),script,intent].join(' '),vector=localVector(text,module.weights),ranked=[];
 for(let row=0;row<module.cases.length;row++){let score=0;const start=row*128;for(let d=0;d<128;d++)score+=vector[d]*module.vectors[start+d]/32767;const example=module.cases[row];score+=example.kind===sh.kind?.055:0;ranked.push({score,example});}
 ranked.sort((a,b)=>b.score-a.score||a.example.id.localeCompare(b.example.id));const selected=[],arcs=new Set();
 for(const {example} of ranked){const theme=example.tags[0];if(arcs.has(theme))continue;arcs.add(theme);selected.push({id:example.id,premise:example.premise,motivation:example.motivation,conflict:example.conflict,decision:example.decision,payoff:example.payoff,intention:example.intention,mechanism:example.mechanism,risk:example.risk,revision:example.revision,checks:example.checks,kind:example.kind});if(selected.length===3)break;}
 return selected;
}
function evaluateLocalNarrative(sh,script='',intent=sh.intent){
 const story=sh.story||{},concept=String(sh.concept||''),motivation=String(story.motivation||''),conflict=String(story.conflict||''),payoff=String(story.payoff||''),body=[concept,motivation,conflict,payoff,script].filter(Boolean).join(' '),all=body+' '+(intent||'');
 const genre=LOCAL_ANALYSIS_CATALOG.genres.find(g=>g.name===sh.genre)||LOCAL_ANALYSIS_CATALOG.genres[0],documentary=sh.genre==='Documentário',reality=sh.genre==='Reality';
 const has=(name,text=body)=>localSignal(name,text),agent=has('agent',concept)||/\b[A-ZÀ-Ý][a-zà-ÿ]{1,20}\s+(quer|precisa|decide|busca|vende|salva|procura|devolve|tenta)/.test(concept),goal=has('goal'),opposition=has('opposition'),stakes=has('stake'),choice=has('choice'),change=has('change',payoff||script||concept),personal=has('personal',motivation||concept),link=has('link'),preparation=has('preparation'),rule=has('rule'),style=has('style',intent),theme=has('theme',all);
 const clauses=body.split(/[.!?;\n]+/).map(x=>norm(x).trim()).filter(x=>x.length>12),duplicates=clauses.length-new Set(clauses).size,repetition=duplicates/Math.max(1,clauses.length);
 const tokens=localWords(body),counts=new Map();for(const w of tokens)counts.set(w,(counts.get(w)||0)+1);const dominant=Math.max(0,...counts.values())/Math.max(1,tokens.length),spam=repetition>.4||dominant>.45;
 const generic=has('generic')&&!goal&&!opposition&&!stakes,penalty=(spam?24:0)+(generic?25:0),score=v=>Math.round(clamp(v-penalty,8,98));
 const motiveText=motivation||concept,conflictText=conflict||concept,endText=payoff||script||concept;
 const wordsOfConcept=new Set(localWords(concept)),overlap=Math.max(0,...(s?.shows||[]).filter(other=>other.id!==sh.id&&other.franchiseRoot!==sh.franchiseRoot).map(other=>{const candidate=new Set(localWords(other.concept));return [...wordsOfConcept].filter(w=>candidate.has(w)).length/Math.max(1,new Set([...wordsOfConcept,...candidate]).size);}));
 const contrast=(has('style',all)&&stakes)||(choice&&has('change'))||(/(?:memoria|sombra|tempo|sonho|objeto|cidade)/.test(norm(body))&&/(?:vende|troca|apaga|devolve|paga|empresta|rouba)/.test(norm(body)));
 const evidence=(text,name,missing)=>text&&(!name||has(name,text))?'Trecho informado: “'+localSnippet(text,name)+'”.':missing;
 const criterion=(key,label,value,text,signal,missing,impact,advice,weight=1,applicable=true)=>({...factor(key,label,score(value),evidence(text,signal,missing),advice,applicable?weight:0),source:'local',impact,confidence:applicable?(text&&(!signal||has(signal,text))?86:48):30,applicable});
 let premiseScore=24+(agent?16:0)+(goal?20:0)+(has('opposition',concept)?18:opposition?10:0)+(has('stake',concept)?12:stakes?7:0)+(personal?8:0);
 if(documentary)premiseScore=28+(has('question',concept)?24:0)+(has('research')?22:0)+(goal?14:0)+(concept?8:0);
 if(reality)premiseScore=28+(has('format')?23:0)+(rule?20:0)+(agent?12:0)+(stakes?12:0);
 const motivationScore=24+(personal?23:0)+(has('need',motiveText)?17:goal?11:0)+(has('stake',motiveText)?19:stakes?10:0)+(choice?10:0);
 const conflictScore=26+(has('opposition',conflictText)?25:opposition?16:0)+(has('agent',conflictText)||rule?12:0)+(stakes?19:0)+(choice||goal?14:0);
 const payoffScore=24+(change?24:0)+(has('choice',endText)?21:choice?11:0)+(has('stake',endText)?20:stakes?9:0)+(link||preparation?8:0)-(has('miracle',endText)&&!rule&&!preparation&&!style?25:0);
 const causalityScore=30+(goal?13:0)+(opposition?14:0)+(choice?15:0)+(change?14:0)+(link?12:0);
 const developmentScore=24+(agent||documentary||reality?11:0)+(goal?13:0)+(opposition?13:0)+(choice?13:0)+(change?13:0)+(preparation?10:0);
 const originalityScore=52+(contrast?18:0)+(style?10:0)+(theme?8:0)+(goal&&opposition?9:0)-(overlap>.72?Math.round((overlap-.72)*100):0);
 const fs=[
  criterion('premise',documentary?'Pergunta e recorte':reality?'Formato e proposta':'Premissa',premiseScore,concept,'','A proposta central ainda não foi informada.',documentary?'Uma pergunta delimitada ajuda a escolher o que observar e verificar.':reality?'Uma proposta legível permite compreender a regra e a participação.':'O objetivo orienta o público antes de ampliar o universo.','Mostre '+(documentary?'a pergunta, o recorte e o acesso a uma evidência.':reality?'quem participa, qual regra organiza a disputa e o que o resultado muda.':'quem age, o que tenta conseguir e o que se opõe. Uma frase precisa pode bastar.'),1.4),
  criterion('motivation',documentary?'Razão da investigação':'Motivação',documentary?32+(has('question')?28:0)+(has('research')?24:0)+(theme?10:0):motivationScore,motiveText,'personal','Não identifiquei um vínculo, necessidade ou motivo pessoal explícito; ele pode estar implícito.', 'Um motivo concreto torna a escolha compreensível e diferencia reação de desejo.',documentary?'Explique por que a pergunta importa e o que poderia alterar a hipótese.':'Ligue a necessidade a um vínculo, valor ou risco específico. Evite apenas afirmar que a pessoa quer muito.',1.2),
  criterion('conflict',documentary?'Tensão entre evidências':'Conflito',documentary?32+(has('research')?24:0)+(opposition?24:0)+(choice?12:0):conflictScore,conflictText,'opposition','Não encontrei oposição concreta; descreva uma tentativa e aquilo que a impede.', 'A oposição precisa exigir uma resposta e reduzir ou transformar as alternativas.',documentary?'Compare fontes que podem confirmar ou modificar a hipótese, sem inventar certeza.':'Mostre como o obstáculo reage à tentativa e força uma escolha. '+genre.revision,1.3),
  criterion('payoff',documentary?'Resultado e limites':'Consequência',payoffScore,endText,'change','Não encontrei mudança ou resultado explícito. Um final aberto também pode mostrar uma consequência.', 'O resultado dá sentido à expectativa criada e mostra o efeito de uma ação.',documentary?'Informe o que foi verificado, o que continua incerto e por que a conclusão pode ser provisória.':'Mostre o efeito da decisão sobre objetivo e vínculo. Um resultado feliz, triste ou aberto pode funcionar.',1.2),
  criterion('causality','Causa e decisão',causalityScore,body,'link','Não encontrei uma ligação explícita de causa; confira se a sequência de ações já a torna visível.', 'A virada deve mudar porque alguém agiu ou porque uma informação foi verificada.', 'Teste a cadeia: tentativa → oposição → decisão → consequência. A intenção pode justificar uma estrutura fragmentada.',.9),
  criterion('development','Progressão',developmentScore,script||body,'','O desenvolvimento ainda não foi informado.', 'Cada etapa deve acrescentar uma decisão, informação ou consequência, e não apenas tamanho.', 'Compare começo e resultado. Retire uma etapa: se nada muda, dê a ela uma função ou simplifique.',1),
  criterion('originality','Identidade e criatividade',originalityScore,all,'','A identidade criativa ainda não foi descrita.', 'Este critério verifica contrastes e intenção no texto; não prova que uma ideia é inédita no mundo.',(overlap>.72?'A premissa compartilha muitos termos com outra obra da sua produtora. Mostre o que muda além do título. ':'')+'Explique a relação própria entre desejo, regra, ponto de vista e consequência. Não é preciso usar palavras difíceis.',1.7),
  criterion('agency','Agência dos personagens',30+(goal?19:0)+(choice?27:0)+(change?16:0)-(has('passive')?25:0),body,'choice','Uma decisão ativa não apareceu claramente; em narrativas de observação ela pode ser menor ou implícita.', 'O público acompanha melhor o efeito de uma decisão do que uma solução recebida pronta.', 'Faça uma ação da pessoa modificar uma alternativa, mesmo que ela não controle o resultado.',.4,!documentary),
  criterion('stakes','O que está em jogo',30+(stakes?34:0)+(personal?20:0)+(change?10:0),body,'stake','O preço da falha ou o valor do resultado ainda não apareceu com clareza.', 'O risco pode ser emocional, material ou íntimo; não precisa ser uma ameaça à vida.', 'Dê um exemplo do que será diferente se a tentativa falhar. '+genre.question,.45),
  criterion('orientation','Orientação do público',35+(goal?17:0)+(opposition?17:0)+(preparation?20:0)+(style?8:0),all,'preparation','A proposta ainda não informa como o público acompanha informações e viradas.', 'Um estilo experimental continua podendo oferecer referências para o público.', 'Escolha um gesto, objeto ou regra que ajude a reconhecer uma mudança de tempo, espaço ou ponto de vista.',.25),
  criterion('setup','Preparação de viradas',35+(preparation?28:0)+(link?16:0)+(rule?12:0),body,'preparation','Não identifiquei pista, regra ou preparação explícita; confira o que o início permite observar.', 'A preparação permite surpresa sem depender de uma explicação criada no desfecho.', 'Plante uma informação observável e mude seu significado quando a decisão chegar.',.25),
  criterion('worldrules','Regras do mundo',35+(rule?32:0)+(stakes?17:0)+(choice?11:0),body,'rule','A possibilidade extraordinária ainda não apresenta limite ou custo explícito.', 'Um limite torna as possibilidades do mundo parte do conflito.', 'Mostre uma aplicação pequena da regra e a consequência de usá-la; a regra pode ser poética quando a intenção a explica.',.25,['Fantasia','Ficção científica','Terror','Animação'].includes(sh.genre)),
  criterion('genrecraft','Proposta de '+sh.genre,40+(goal?12:0)+(opposition?12:0)+(stakes?12:0)+(style?12:0)+(genre.signals.some(w=>norm(all).includes(w))?8:0),all,'','A proposta do gênero ainda não foi desenvolvida.', 'O gênero oferece expectativas e possibilidades; não exige uma fórmula única.', genre.revision+'. '+genre.question,.35),
  criterion('serial','Motor da série',32+(change?22:0)+(choice?19:0)+(opposition?18:0),body,'change','Ainda não identifiquei um resultado de etapa que possa gerar outra consequência.', 'Uma série precisa justificar a próxima etapa depois de entregar algo nesta.', 'Resolva uma pergunta do episódio e faça a consequência abrir uma pergunta diferente. Evite adiar tudo para o último episódio.',.35,sh.kind==='series'),
  criterion('local-intent','Intenção e linguagem',30+(style?30:0)+(theme?22:0)+(choice?10:0),intent,'','A intenção de linguagem ainda não foi escrita.', 'A intenção ajuda a avaliar uma escolha fora do padrão por aquilo que ela pretende fazer.', 'Explique o efeito desejado e uma escolha que produz esse efeito. A experiência pode ser simples ou ousada.',.3),
  criterion('economy','Clareza e repetição',spam?42:generic?38:90,spam?body:concept,'','', 'Repetição útil pode construir um padrão; repetição de preenchimento não desenvolve a ideia.', spam?'Há repetição muito alta de frases ou de um termo. Dê a cada retorno uma informação ou consequência nova.':'Concentre cada frase numa decisão, informação, imagem ou consequência. O tamanho do texto não dá pontos por si só.',.2),
  criterion('research','Evidências e verificação',32+(has('research')?34:0)+(opposition?17:0)+(has('question')?12:0),body,'research','O acesso a fontes ou a um modo de verificação não foi informado.', 'Este motor não verifica fatos externos; avalia somente o plano de investigação descrito.', 'Indique uma fonte, o modo de conferir a afirmação e um contraponto que poderia alterar a conclusão.',.55,documentary),
  criterion('format','Regras e participação',30+(rule?25:0)+(has('format')?25:0)+(choice?14:0),body,'rule','Não identifiquei uma regra verificável do formato.', 'Regras compreensíveis permitem que a escolha dos participantes tenha efeito.', 'Informe a regra antes da decisão, o critério do resultado e como os participantes podem agir.',.55,reality)
 ];
 return{factors:fs,score:Math.round(weighted(fs)),confidence:Math.round(fs.filter(f=>f.applicable).reduce((sum,f)=>sum+f.confidence,0)/fs.filter(f=>f.applicable).length),genre:genre.name,method:'Regras explicáveis + referências narrativas locais',repetition,originalityOverlap:overlap};
}
const enrichedPlotBase=plotFactors;
plotFactors=function(sh,script=''){return currentConceptAI(sh)?enrichedPlotBase(sh,script):evaluateLocalNarrative(sh,script,sh.intent).factors;};
const enrichedBuildBase=buildAnalysis;
buildAnalysis=function(sh,ep){
 const fs=enrichedBuildBase(sh,ep);if(ep.aiReview)return fs;
 const snapshot={...sh,concept:ep.storySnapshot?.concept??sh.concept,story:ep.storySnapshot?.story??sh.story},intent=ep.intent||sh.intent,local=evaluateLocalNarrative(snapshot,ep.script,intent),support=local.factors.find(f=>f.key==='local-intent');
 return fs.map(f=>{
  if(f.key==='intention')return {...f,score:support.score,evidence:support.evidence,advice:support.advice,confidence:support.confidence,source:'local'};
  if(f.key==='dir1'&&ep.direction?.[1]===2&&ep.direction?.[0]===2&&support.score>=75)return {...f,score:94,evidence:f.evidence+' A intenção registrada sustenta o contraste sem exigir um texto longo.'};
  return f;
 });
};
function localAnalysisDetails(sh){
 const value=sh.localConcept,valid=value&&Array.isArray(value.references)&&value.references.length<=3&&value.references.every(r=>r&&['id','premise','motivation','conflict','decision','payoff','intention','mechanism','risk','revision'].every(k=>typeof r[k]==='string'&&r[k].length<4000)&&Array.isArray(r.checks)&&r.checks.length<=8&&r.checks.every(c=>typeof c==='string'&&c.length<1000));
 const review=valid&&value.fingerprint===projectFingerprint(sh)?value:null,meta=LOCAL_ANALYSIS_PACK;
 const references=review?.references||[],error=localModuleErrors.get(sh.genre);
 return '<details class="card"><summary>Como a análise local funciona</summary><p>O motor avalia os sinais e trechos informados, com critérios próprios para cada gênero. A extensão do texto não dá pontos. Uma interpretação implícita pode não ser reconhecida por regras.</p><p>'+meta.totalCases.toLocaleString('pt-BR')+' estudos de referência fictícios em '+meta.modules.length+' gêneros · '+(meta.totalBytes/1024/1024).toFixed(1)+' MiB de recursos instalados. O jogo abre somente o módulo necessário.</p><p>As referências ajudam a comparar mecanismos e reescritas; não são cenas da sua obra e não determinam uma nota pronta.</p></details>'+(error?emNote(error,'info'):'')+(references.length?'<article class="card"><h3>Referências para experimentar</h3><p>Exemplos fictícios selecionados pelo conteúdo da sua proposta. Adapte o mecanismo à sua própria ideia.</p>'+references.map((r,i)=>'<details><summary>Experiência de reescrita '+(i+1)+'</summary><p><b>Exemplo:</b> '+esc(r.premise)+'</p><p>'+esc(r.decision)+'</p><p><b>Teste:</b> '+esc(r.revision)+'</p><details><summary>Ver o estudo completo</summary><p><b>Motivação:</b> '+esc(r.motivation)+'</p><p><b>Conflito:</b> '+esc(r.conflict)+'</p><p><b>Consequência:</b> '+esc(r.payoff)+'</p><p><b>Intenção:</b> '+esc(r.intention)+'</p><p><b>Mecanismo:</b> '+esc(r.mechanism)+'</p><p><b>Risco:</b> '+esc(r.risk)+'</p><ul>'+r.checks.map(c=>'<li>'+esc(c)+'</li>').join('')+'</ul></details></details>').join('')+'</article>':'');
}
