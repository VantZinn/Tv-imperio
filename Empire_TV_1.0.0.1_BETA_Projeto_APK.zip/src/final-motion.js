/* Cinematic presentation. Timed presentation never marks an unfinished request complete. */
let motionMode='cinematic',sceneMotion=null,sceneSerial=0,lastMotionWallet=null;
try{motionMode=localStorage.getItem('empire-motion')==='reduced'?'reduced':'cinematic';}catch{}
function motionClock(){return typeof window.performance?.now==='function'?window.performance.now():Date.now();}
function motionDOM(){return typeof document.getElementById==='function';}
function motionDelay(ms){return motionDOM()?new Promise(resolve=>setTimeout(resolve,Math.max(0,ms))):Promise.resolve();}
function cinematicMedia(name){return '<video class="em-cinematic-media" autoplay loop muted playsinline preload="metadata" poster="media/'+name+'-poster.webp" aria-hidden="true"><source src="media/'+name+'.mp4" type="video/mp4"></video><div class="em-film-grain" aria-hidden="true"></div>';}
function stopCinematicMedia(scope){
 if(!scope?.querySelectorAll||!window.MediaSource)return;
 scope.querySelectorAll('video.em-cinematic-media').forEach(video=>{video.pause();video.querySelectorAll('source').forEach(source=>source.remove());video.removeAttribute('src');video.load();});
}
function bindCinematicMedia(scope=document){
 if(!scope.querySelectorAll)return;
 const reduce=motionMode==='reduced'||Boolean(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches);
 scope.querySelectorAll('video.em-cinematic-media').forEach(video=>{
  if(video.dataset.bound)return;video.dataset.bound='1';video.muted=true;
  video.addEventListener('error',()=>{video.hidden=true;},{once:true});
  if(!window.MediaSource)return;
  if(reduce){video.pause();video.removeAttribute('autoplay');return;}
  const play=video.play();if(play?.catch)play.catch(()=>{});
 });
}
function applyMotionMode(){if(document.documentElement)document.documentElement.dataset.motion=motionMode;}
function setMotionMode(mode){if(!['cinematic','reduced'].includes(mode))return;motionMode=mode;try{localStorage.setItem('empire-motion',mode);}catch{}applyMotionMode();render();}
function animateInterface(){
 if(!root.querySelectorAll)return;
 root.querySelectorAll('.em-page-head,.em-hero,.card,.em-work-row,.social-post,.em-network-row').forEach((el,index)=>{if(el.style)el.style.setProperty('--enter-i',String(Math.min(index,12)));});
 const wallet=root.querySelector('.em-wallet>button');if(wallet&&s){if(lastMotionWallet!==null&&lastMotionWallet!==s.fameWallet.balance)wallet.classList.add('em-wallet-changed');lastMotionWallet=s.fameWallet.balance;}
 bindCinematicMedia(root);
}
function rewardBurst(mf,boosts,title){
 if(!motionDOM()||!document.body)return;
 const el=document.createElement('aside');el.className='em-reward-burst';el.setAttribute('role','status');
 el.innerHTML='<div class="em-reward-toast">'+MF_ICON+'<div><span>CONQUISTA RESGATADA</span><b>'+esc(title)+'</b><p>+'+mf+' MF'+(boosts?' · '+boosts+' impulso(s)':'')+'</p></div></div><div class="em-reward-confetti" aria-hidden="true">'+Array.from({length:24},(_,i)=>'<i style="--spark-i:'+i+';--spark-x:'+((i%9-4)*32)+'px;--spark-y:'+(-80-(i%6)*30)+'px;--spark-r:'+(i*37)+'deg"></i>').join('')+'</div>';
 document.querySelectorAll('.em-reward-burst').forEach(old=>old.remove());document.body.appendChild(el);setTimeout(()=>el.remove(),3400);
}
function motionSettingsScreen(){return emPage('Visual e animações','Escolha como seu estúdio ganha vida.','<div class="em-card-grid">'+[['cinematic','Cinemático','Abertura animada, cenários em vídeo, partículas, transições e celebrações.'],['reduced','Suave','Mantém as informações e a arte; reduz movimentos e usa cenários estáticos.']].map(([id,title,text])=>'<article class="card"><span class="eyebrow">'+(motionMode===id?'ATIVO':'APRESENTAÇÃO')+'</span><h3>'+title+'</h3><p>'+text+'</p>'+emButton(motionMode===id?'Selecionado':'Usar este visual','data-em-motion="'+id+'" '+(motionMode===id?'disabled':''),'primary','spark')+'</article>').join('')+'</div>'+emNote('A abertura apresenta etapas por cerca de 8 segundos. O tempo de uma análise depende da resposta do servidor. A preferência de movimento reduzido do aparelho também é respeitada.','info'));}

function sceneLoadingView(label,progress=35,options={}){
 if(!motionDOM())return;const el=document.querySelector('#scene-loading');if(!el)return;
 const toast=document.querySelector('#toast');if(toast){toast.className='toast';toast.textContent='';}
 if(sceneMotion?.timer)clearInterval(sceneMotion.timer);
 const work=options.work,analysis=options.kind==='analysis';sceneMotion={id:++sceneSerial,started:motionClock(),analysis,timer:null,finished:false};
 el.hidden=false;el.className='em-loading-overlay '+(analysis?'em-analysis-overlay':'');
 el.innerHTML=cinematicMedia(analysis?'analysis':'studio')+'<div class="em-stage-beam left"></div><div class="em-stage-beam right"></div><div class="em-loading-card '+(analysis?'em-analysis-card':'')+'"><span class="eyebrow">'+(analysis?'SALA DE ANÁLISE · '+(options.local?'AVALIAÇÃO LOCAL':'UNIVERSO ONLINE'):'SEU ESTÚDIO ESTÁ EM MOVIMENTO')+'</span><div class="em-analysis-visual" aria-hidden="true"><div class="em-analysis-orbit"></div><div class="em-analysis-orbit second"></div><div class="em-analysis-document"><i></i><i></i><i></i><i></i><div class="em-analysis-scan"></div></div><span class="em-analysis-spark one"></span><span class="em-analysis-spark two"></span>'+TV_LOGO+'</div><h2>'+esc(label)+'</h2>'+(work?'<p class="em-analysis-work">'+esc(work.name)+'</p><p class="em-analysis-meta">'+(isFilm(work)?'Filme':'Série')+' · '+esc(work.genre)+' · '+work.duration+' min</p>':'')+(analysis?'<div class="em-analysis-criteria">'+[['originality','Originalidade'],['coherence','Coerência'],['characters','Personagens'],['impact','Impacto'],['execution','Execução']].map(([key,title])=>'<div><span>'+title+'</span><b data-analysis-score="'+key+'">···</b></div>').join('')+'</div>':'')+'<div class="em-analysis-operation"><b id="scene-stage">Preparando contexto</b><time id="scene-elapsed">0s</time></div><div class="loading-progress working" role="progressbar" aria-label="Análise em andamento" aria-valuetext="Aguardando resultado"><span></span></div><p id="scene-detail">'+(analysis?'As notas aparecem apenas depois da validação do parecer.':'Conectando com segurança. Seu progresso está preservado.')+'</p></div>';
 bindCinematicMedia(el);const id=sceneMotion.id;
 sceneMotion.timer=setInterval(()=>{if(sceneMotion?.id!==id)return;const timer=document.getElementById('scene-elapsed');if(timer)timer.textContent=Math.floor((motionClock()-sceneMotion.started)/1000)+'s';},1000);
}
function setSceneStage(label,detail='',state='working'){
 if(!motionDOM())return;const el=document.querySelector('#scene-loading');if(!el||el.hidden)return;
 const stage=el.querySelector('#scene-stage'),message=el.querySelector('#scene-detail');if(stage)stage.textContent=label;if(message)message.textContent=detail;
 el.dataset.phase=state;const bar=el.querySelector('.loading-progress');if(bar){bar.classList.toggle('working',state==='working');bar.setAttribute('aria-valuetext',label);if(state==='done'){bar.setAttribute('aria-valuenow','100');const fill=bar.querySelector('span');if(fill)fill.style.width='100%';}}
}
function completeAnalysisScene(review,cached=false,local=false){
 if(!motionDOM())return;const el=document.querySelector('#scene-loading');if(!el)return;
 el.querySelectorAll('[data-analysis-score]').forEach(node=>{const n=review.scores?.[node.dataset.analysisScore];node.textContent=Number.isFinite(n)?n+'/100':'—';});
 if(sceneMotion)sceneMotion.finished=true;
 setSceneStage(local?'Análise local concluída':cached?'Parecer recuperado e validado':'Parecer validado',local?'Avaliação pelas regras do jogo. Evidências e sugestões estão na aba Parecer.':'Notas, evidências e sugestões conferidas. Seu parecer está pronto.', 'done');
}
async function settleAnalysisScene(){
 if(!motionDOM()||!sceneMotion?.analysis)return;
 await motionDelay(Math.max(0,1500-(motionClock()-sceneMotion.started)));
 if(sceneMotion?.finished)await motionDelay(550);
}
function clearSceneMotion(){if(sceneMotion?.timer)clearInterval(sceneMotion.timer);sceneMotion=null;const el=document.querySelector('#scene-loading');if(el){el.hidden=true;stopCinematicMedia(el);el.innerHTML='';delete el.dataset.phase;}}
async function analyseLocalWork(showId){
 const sh=showBy(showId);if(!sh||aiBusy)return;
 aiBusy=true;showSceneLoading('Lendo sua ideia',10,{kind:'analysis',work:sh,local:true});
 try{
  const factors=finalPlotBase(sh),get=key=>factors.find(f=>f.key===key)?.score;
  setSceneStage('Conferindo o argumento','Leitura por regras: premissa, motivação, conflito, consequência e intenção.');
  await motionDelay(1100);
  completeAnalysisScene({scores:{originality:get('originality'),coherence:get('causality'),characters:get('motivation'),impact:get('payoff'),execution:get('development')}},false,true);
  await settleAnalysisScene();workPanel='analysis';
 }finally{aiBusy=false;hideSceneLoading();render();}
}

function makeEmpireBoot(){
 const phases=[['Carregando estúdio','Preparando o acesso e a identidade da sua produtora.'],['Conferindo atores','Conferindo '+talents.length+' talentos e suas especialidades.'],['Organizando emissoras','Preparando '+networks.length+' emissoras, alcance e programação.'],['Preparando missões','Organizando '+DAILY_OBJECTIVES.length+' desafios diários e '+PRESTIGE_OBJECTIVES.length+' desafios de prestígio.'],['Conferindo seu progresso','Preparando contas, campanhas e recursos salvos.']];
 return{percent:0,finished:false,assetsReady:false,started:window.EmpireStartup?.startedClock??motionClock(),timer:null,
  start(){if(!motionDOM())return;const root=document.getElementById('root');if(root){root.setAttribute('inert','');root.setAttribute('aria-hidden','true');}applyMotionMode();bindCinematicMedia();this.tick();this.timer=setInterval(()=>this.tick(),80);},
  progress(value){this.resourceProgress=Math.max(this.resourceProgress||0,value);},
  finish(){this.assetsReady=true;this.tick();},
  tick(){
   if(this.finished||!motionDOM())return;if(window.EmpireStartup?.status()==='failed'){clearInterval(this.timer);return;}
   const elapsed=motionClock()-this.started,index=Math.min(phases.length-1,Math.floor(elapsed/1500));
   this.percent=Math.min(this.assetsReady?99:92,Math.floor(elapsed/7600*100));
   const boot=document.getElementById('boot-screen');if(!boot)return;
   const fill=document.getElementById('boot-progress'),label=document.getElementById('boot-label'),stage=document.getElementById('boot-stage'),detail=document.getElementById('boot-detail');
   if(fill)fill.style.width=this.percent+'%';if(label)label.textContent=this.percent+'%';if(stage)stage.textContent=phases[index][0];if(detail)detail.textContent=phases[index][1];
   const bar=boot.querySelector('[role="progressbar"]');if(bar)bar.setAttribute('aria-valuenow',String(this.percent));
   boot.querySelectorAll('[data-boot-check]').forEach(node=>{node.classList.toggle('done',Number(node.dataset.bootCheck)<index);node.classList.toggle('current',Number(node.dataset.bootCheck)===index);});
   if(elapsed<7600||!this.assetsReady)return;
   this.finished=true;this.percent=100;clearInterval(this.timer);if(fill)fill.style.width='100%';if(label)label.textContent='100%';if(stage)stage.textContent='Estúdio pronto';if(detail)detail.textContent='Sua próxima grande história começa agora.';if(bar)bar.setAttribute('aria-valuenow','100');boot.classList.add('leaving');
   setTimeout(()=>{boot.hidden=true;boot.style.pointerEvents='none';stopCinematicMedia(boot);boot.remove();const root=document.getElementById('root');if(root){root.removeAttribute('inert');root.removeAttribute('aria-hidden');}if(window.EmpireStartup)window.EmpireStartup.ready();},200);
  }
 };
}
applyMotionMode();
