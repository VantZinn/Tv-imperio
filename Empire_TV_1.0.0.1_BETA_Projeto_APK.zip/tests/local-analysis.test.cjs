const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),{createHash}=require('node:crypto'),createGame=require('./game-fixture.cjs');
const assets=path.join(__dirname,'../app/src/main/assets/analysis'),manifest=JSON.parse(fs.readFileSync(path.join(assets,'manifest.json'),'utf8'));
const project=()=>({id:1,name:'O Mercado das Lembranças',kind:'film',genre:'Fantasia',duration:60,concept:'Ana vende lembranças, mas cada venda apaga um amigo.',story:{motivation:'Ela precisa lembrar do irmão que prometeu proteger.',conflict:'Cada uso custa uma lembrança e o rival bloqueia a volta para casa.',payoff:'Ana decide devolver a memória, por isso perde o emprego, mas salva o irmão.'},intent:'Humor sobre identidade e perda; a imagem muda depois de cada escolha.',franchiseRoot:'O Mercado das Lembranças',episodes:[]});

test('Biblioteca instalada supera 40 MiB com estudos completos, índices úteis e integridade verificada',()=>{
 assert.equal(manifest.modules.length,12);assert(manifest.totalBytes>=40*1024*1024);let bytes=0,cases=0;
 for(const meta of manifest.modules){
  const json=fs.readFileSync(path.join(assets,meta.module)),index=fs.readFileSync(path.join(assets,meta.index)),module=JSON.parse(json);assert.equal(createHash('sha256').update(json).digest('hex'),meta.moduleSha256);assert.equal(createHash('sha256').update(index).digest('hex'),meta.indexSha256);assert.equal(index.length,meta.cases*128*2);assert.equal(module.cases.length,meta.cases);
  const seen=new Set();for(const example of module.cases){for(const key of ['premise','motivation','conflict','decision','payoff','intention','mechanism','risk','revision'])assert(example[key].length>40);assert.equal(example.checks.length,8);assert(!('score' in example));const identity=example.premise+example.decision+example.payoff+example.intention;assert(!seen.has(identity));seen.add(identity);}
  const vectors=new Int16Array(index.buffer,index.byteOffset,index.byteLength/2);for(let row=0;row<module.cases.length;row++){let norm=0;for(let d=0;d<128;d++)norm+=(vectors[row*128+d]/32767)**2;assert(Math.abs(norm-1)<.02);}
  bytes+=json.length+index.length;cases+=module.cases.length;
 }assert.equal(bytes,manifest.totalBytes);assert.equal(cases,manifest.totalCases);
});

test('Ideia curta desenvolvida recebe boa avaliação; extensão e palavras repetidas não dão pontos',()=>{
 const g=createGame();g.profile();const sh=project(),good=g.api.evaluateLocalNarrative(sh);assert(good.score>=80,good.score);const vague=g.api.evaluateLocalNarrative({...sh,concept:'Uma história incrível, vai ser sucesso.',story:{motivation:'',conflict:'',payoff:''},intent:''});assert(good.score>vague.score+40);
 const repeated=g.api.evaluateLocalNarrative({...sh,concept:'drama '.repeat(200),story:{motivation:'drama '.repeat(200),conflict:'drama '.repeat(200),payoff:'drama '.repeat(200)},intent:''});assert(repeated.score<30);
 const extended=g.api.evaluateLocalNarrative({...sh,concept:sh.concept+' Objetos ornamentais azuis ocupam nichos retangulares cobertos por panos beges.'});assert.equal(extended.score,good.score);
 for(const f of good.factors){assert(f.impact.length>10);assert(f.advice.length>10);assert(f.confidence>0);assert(!f.evidence.includes('uma médica'));}
});

test('Critérios mudam por formato; documentário não exige um herói ou regra mágica',()=>{
 const g=createGame();g.profile();const sh={...project(),genre:'Documentário',concept:'Investigar por que a ponte foi fechada, comparando registros e entrevistas.',story:{motivation:'Compreender a responsabilidade pelo isolamento do bairro.',conflict:'Os documentos contradizem o relato oficial, mas uma testemunha não pode aparecer.',payoff:'A pesquisa verifica a data do fechamento e revela o limite da hipótese inicial.'},intent:'Arquivo e observação da rotina mostram o impacto da decisão.'};const result=g.api.evaluateLocalNarrative(sh);
 assert.equal(result.factors.find(f=>f.key==='premise').label,'Pergunta e recorte');assert(result.factors.find(f=>f.key==='research').applicable);assert.equal(result.factors.find(f=>f.key==='agency').weight,0);assert.equal(result.factors.find(f=>f.key==='worldrules').weight,0);assert(result.score>70);
 const reality=g.api.evaluateLocalNarrative({...sh,genre:'Reality',concept:'Participantes escolhem uma prova por rodada, mas cada escolha custa uma aliança.',story:{...sh.story,conflict:'A regra exige consentimento e o voto elimina uma possibilidade.'}});assert(reality.factors.find(f=>f.key==='format').applicable);assert.equal(reality.factors.find(f=>f.key==='research').weight,0);
});

test('Trechos e críticas usam somente o texto informado; mudança de consequência altera o parecer',()=>{
 const g=createGame();g.profile();const sh=project(),result=g.api.evaluateLocalNarrative(sh),body=[sh.concept,...Object.values(sh.story),sh.intent].join(' ');
 for(const f of result.factors){const quote=f.evidence.match(/“([^”]+)”/);if(quote)assert(body.includes(quote[1]),quote[1]);}
 const revised=g.api.evaluateLocalNarrative({...sh,story:{...sh.story,payoff:'De repente tudo se resolve e ela não faz nada.'},intent:''});assert(revised.factors.find(f=>f.key==='payoff').score<result.factors.find(f=>f.key==='payoff').score);assert(result.factors.find(f=>f.key==='originality').impact.includes('não prova'));
});

test('Módulos carregam por gênero, índice recupera caso relevante e memória mantém somente dois módulos',async()=>{
 const g=createGame();g.profile();g.assets();let calls=0;const fetch=g.context.window.fetch;g.context.window.fetch=async(...args)=>{calls++;return fetch(...args);};const module=await g.api.loadLocalAnalysisModule('Fantasia');assert(module);assert.equal(calls,2);assert.equal(await g.api.loadLocalAnalysisModule('Fantasia'),module);assert.equal(calls,2);
 const example=module.cases[45],sh={...project(),kind:example.kind,concept:example.premise,story:{motivation:example.motivation,conflict:example.conflict,payoff:example.payoff},intent:example.intention},references=g.api.localReferences(sh,example.decision);assert.equal(references.length,3);assert.equal(references[0].id,example.id);
 await g.api.loadLocalAnalysisModule('Drama');await g.api.loadLocalAnalysisModule('Comédia');assert.equal(g.api.moduleStats().loaded.length,2);assert(!g.api.moduleStats().loaded.includes('Fantasia'));
});

test('Analisar localmente guarda referências, altera somente o parecer e funciona sem servidor',async()=>{
 const g=createGame(),state=g.profile();g.assets();const sh=project();state.shows.push(sh);const cash=state.cash,mf=state.fameWallet.balance;await g.api.analyseLocalWork(sh.id);assert.equal(sh.localConcept.references.length,3);assert(sh.localConcept.loadedCases>1000);assert.equal(state.cash,cash);assert.equal(state.fameWallet.balance,mf);assert.equal(g.api.serviceConfig(),null);assert(g.api.localAnalysisDetails(sh).includes('não são cenas da sua obra'));
 g.api.navigate('shows');g.api.setChosen(sh.id);g.api.render();assert(g.root.innerHTML.includes('Parecer local'));assert(g.root.innerHTML.includes('Referências para experimentar'));
});

test('Recurso local corrompido não gera referências inventadas nem impede avaliação básica',async()=>{
 const g=createGame();g.profile();g.assets();const original=g.context.window.fetch;g.context.window.fetch=async url=>url.endsWith('vectors.i16')?{ok:true,arrayBuffer:async()=>new ArrayBuffer(2)}:original(url);assert.equal(await g.api.loadLocalAnalysisModule('Fantasia'),null);assert.equal(g.api.localReferences(project()).length,0);assert(g.api.evaluateLocalNarrative(project()).score>=80);assert.equal(g.api.moduleStats().loaded.length,0);
});
