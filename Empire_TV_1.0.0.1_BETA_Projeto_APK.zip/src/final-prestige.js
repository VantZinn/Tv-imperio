/* Persistent campaign challenges. Rewards never depend on a fabricated AI result. */
const DAILY_MF=[1,2,3,5,8,12];
function dailyMF(objective){return DAILY_MF[objective?.tier]||1;}
const PRESTIGE_OBJECTIVES=[
 {id:'phenomenon',title:'Fenômeno nacional',tier:'Difícil',mf:15,boosts:1,desc:'Estreie uma obra com 5 milhões de visualizações, público ≥85 e crítica ≥80.',metric:'phenomenon',goal:5000000},
 {id:'filmcraft',title:'Cinema de autor',tier:'Difícil',mf:20,boosts:1,desc:'Exiba 3 filmes com qualidade ≥85 e crítica ≥80.',metric:'films',goal:3},
 {id:'season',title:'Temporada impecável',tier:'Muito difícil',mf:25,boosts:2,desc:'Complete uma temporada de pelo menos 6 episódios, todos com público ≥85 e crítica ≥82.',metric:'season',goal:6},
 {id:'genres',title:'Vozes diferentes',tier:'Muito difícil',mf:25,boosts:2,desc:'Estreie obras de 5 gêneros diferentes, cada uma com qualidade ≥85 e crítica ≥80.',metric:'genres',goal:5},
 {id:'favorites',title:'Na memória do público',tier:'Muito difícil',mf:30,boosts:2,desc:'Conquiste 1 milhão de favoritos em estreias com público ≥85.',metric:'favorites',goal:1000000},
 {id:'franchise',title:'Franquia respeitada',tier:'Muito difícil',mf:35,boosts:2,desc:'Exiba a obra original e 2 continuações da mesma franquia, todas com público médio ≥85.',metric:'franchise',goal:3},
 {id:'streak',title:'Oito episódios de aplausos',tier:'Lendário',mf:40,boosts:3,desc:'Exiba 8 episódios seguidos da mesma série, todos com público ≥88 e crítica ≥85.',metric:'streak',goal:8},
 {id:'blockbuster',title:'Bilheteria lendária',tier:'Lendário',mf:40,boosts:3,desc:'Exiba um filme com 10 milhões de visualizações, qualidade ≥90 e lucro de produção positivo.',metric:'blockbuster',goal:10000000},
 {id:'broadcast',title:'Sua emissora, seu império',tier:'Lendário',mf:45,boosts:3,desc:'Uma emissora sua deve alcançar 25 milhões de visualizações acumuladas e ter lucro positivo.',metric:'broadcast',goal:25000000},
 {id:'awards',title:'Coleção de troféus',tier:'Lendário',mf:50,boosts:3,desc:'Conquiste 8 prêmios nas premiações do universo.',metric:'awards',goal:8},
 {id:'revenue',title:'Produtora de referência',tier:'Lendário',mf:60,boosts:3,desc:'Fature R$ 10 milhões com suas exibições e tenha pelo menos 10 produções já exibidas.',metric:'revenue',goal:10000000},
 {id:'empire',title:'Empire TV',tier:'Lendário',mf:75,boosts:3,desc:'Acumule 100 milhões de visualizações em produções de qualidade ≥85 e conquiste 12 prêmios.',metric:'empire',goal:100000000}
];
function prestigeUnlocked(){return objectiveDefs.every(o=>s.claimed.includes(o.id));}
function prestigeProgress(o){
 const aired=s.shows.flatMap(sh=>sh.episodes.filter(ep=>ep.status==='aired').map(ep=>({sh,ep}))),score=ep=>Number.isFinite(ep.viewers)&&Number.isFinite(ep.critics),max=list=>Math.max(0,...list),sum=list=>list.reduce((a,b)=>a+b,0);
 let value=0,extra=true,detail='';
 if(o.metric==='phenomenon')value=max(aired.filter(x=>score(x.ep)&&x.ep.viewers>=85&&x.ep.critics>=80).map(x=>x.ep.viewership||0));
 else if(o.metric==='films')value=aired.filter(x=>isFilm(x.sh)&&x.ep.quality>=85&&score(x.ep)&&x.ep.critics>=80).length;
 else if(o.metric==='season'){
  for(const sh of s.shows.filter(x=>!isFilm(x))){const seasons=[...new Set(sh.episodes.map(ep=>ep.season))];for(const season of seasons){const eps=sh.episodes.filter(ep=>ep.season===season),shown=eps.filter(ep=>ep.status==='aired'),good=shown.filter(ep=>score(ep)&&ep.viewers>=85&&ep.critics>=82);const count=shown.length===good.length?good.length:0;if(count>value)value=count;}}
 }
 else if(o.metric==='genres')value=new Set(aired.filter(x=>x.ep.quality>=85&&score(x.ep)&&x.ep.critics>=80).map(x=>x.sh.genre)).size;
 else if(o.metric==='favorites')value=sum(aired.filter(x=>score(x.ep)&&x.ep.viewers>=85).map(x=>x.ep.favorites||0));
 else if(o.metric==='franchise'){
  const groups=new Map();for(const sh of s.shows){const eps=sh.episodes.filter(ep=>ep.status==='aired');if(!eps.length||!eps.every(ep=>Number.isFinite(ep.viewers))||sum(eps.map(ep=>ep.viewers))/eps.length<85)continue;const key=sh.franchiseRoot||sh.name;const group=groups.get(key)||[];group.push(sh);groups.set(key,group);}
  for(const group of groups.values()){if(!group.some(sh=>!sh.parentId))continue;value=Math.max(value,1+group.filter(sh=>sh.parentId).length);}
 }
 else if(o.metric==='streak'){for(const sh of s.shows.filter(x=>!isFilm(x))){let streak=0;for(const ep of sh.episodes.filter(ep=>ep.status==='aired').slice().sort((a,b)=>a.airWeek-b.airWeek||a.season-b.season||a.number-b.number)){streak=score(ep)&&ep.viewers>=88&&ep.critics>=85?streak+1:0;value=Math.max(value,streak);}}}
 else if(o.metric==='blockbuster')value=max(aired.filter(x=>isFilm(x.sh)&&x.ep.quality>=90&&Number.isFinite(x.ep.netProduction)&&x.ep.netProduction>0).map(x=>x.ep.viewership||0));
 else if(o.metric==='broadcast')value=max(s.networks.filter(n=>n.metrics?.profit>0).map(n=>n.metrics.views||0));
 else if(o.metric==='awards')value=s.awards?.wins||0;
 else if(o.metric==='revenue'){value=s.counts.revenue||0;extra=aired.length>=10;detail=aired.length+' / 10 produções exibidas';}
 else if(o.metric==='empire'){value=sum(aired.filter(x=>x.ep.quality>=85).map(x=>x.ep.viewership||0));extra=(s.awards?.wins||0)>=12;detail=(s.awards?.wins||0)+' / 12 prêmios';}
 const claimed=Boolean(s.prestige?.claimed?.[o.id]),ready=value>=o.goal&&extra,percent=Math.min(value/o.goal,extra?1:.95)*100;
 return{value,ready,claimed,percent,detail};
}
function claimPrestige(id){
 migrateFinal(s);const o=PRESTIGE_OBJECTIVES.find(o=>o.id===id);if(!o)return false;
 const p=prestigeProgress(o);if(p.claimed||!p.ready||!prestigeUnlocked())return notice('Conclua os requisitos do desafio e a jornada inicial antes de resgatar.',true),false;
 const receipt=s.campaignId+':prestige:'+o.id;
 if(s.fameWallet.rewarded[receipt]){s.prestige.claimed[o.id]=true;save();render();return false;}
 if(!walletChange(o.mf,'Desafio de prestígio: '+o.title,receipt))return false;
 const boosts=s.difficulty==='director'?0:o.boosts;
 for(let i=0;i<boosts;i++)s.boosts[POWERUPS[i%POWERUPS.length]]++;
 s.prestige.claimed[o.id]=true;log('Prestígio: '+o.title+' · +'+o.mf+' MF'+(boosts?' e '+boosts+' impulso(s)':'')+'.');save();render();rewardBurst(o.mf,boosts,o.title);notice('Desafio concluído: +'+o.mf+' MF'+(boosts?' e '+boosts+' impulso(s)':'')+'.');return true;
}
function prestigeScreen(){
 const unlocked=prestigeUnlocked(),done=PRESTIGE_OBJECTIVES.filter(o=>s.prestige.claimed[o.id]).length;
 const hero='<section class="em-prestige-hero">'+cinematicMedia('prestige')+'<div class="em-prestige-content"><span class="eyebrow">A PRÓXIMA ERA DO SEU ESTÚDIO</span><h2>Conquiste seu legado.</h2><p>Desafios que exigem audiência, qualidade e consistência. Até 75 MF e 3 impulsos por conquista.</p>'+pill(done+' / '+PRESTIGE_OBJECTIVES.length+' conquistas','orange')+'</div><div class="em-prestige-cup" aria-hidden="true">'+icon('award')+'</div></section>';
 return emPage('Desafios de prestígio','Conquistas permanentes desta campanha. Cada recompensa tem resgate único.',hero+(!unlocked?emNote('O progresso já conta. Termine as missões iniciais para liberar o resgate.','goal'):'')+(s.difficulty==='director'?emNote('No Real diretor, as recompensas são em MF. A regra de campanha sem impulsos continua valendo.','info'):'<details><summary>Quais impulsos vou receber?</summary><p>1 impulso: Inspiração (+15 na qualidade). 2 impulsos: Inspiração e Audiência (+40% no alcance). 3 impulsos: os dois anteriores e Desconto (redução de 28% no custo da produção). São adicionados ao inventário; você escolhe quando usar.</p></details>')+'<div class="em-card-grid em-prestige-grid">'+PRESTIGE_OBJECTIVES.map((o,index)=>{const p=prestigeProgress(o),boosts=s.difficulty==='director'?0:o.boosts;return '<article class="card em-prestige-card '+(p.claimed?'claimed':p.ready?'ready':'')+'"><div class="between">'+pill(o.tier,'orange')+'<span class="em-prestige-number">'+String(index+1).padStart(2,'0')+'</span></div><h3>'+esc(o.title)+'</h3><p>'+esc(o.desc)+'</p><div class="bar"><i style="width:'+p.percent+'%"></i></div><p class="scope-label">'+(o.metric==='revenue'?money(Math.min(p.value,o.goal)):compact(Math.min(p.value,o.goal)))+' / '+(o.metric==='revenue'?money(o.goal):compact(o.goal))+(p.detail?' · '+esc(p.detail):'')+'</p><div class="em-reward-line">'+MF_ICON+'<b>+'+o.mf+' MF</b>'+(boosts?'<span>'+icon('spark')+' '+boosts+' impulso(s)</span>':'')+'</div>'+emButton(p.claimed?'Recompensa recebida':!unlocked?'Conclua a jornada inicial':p.ready?'Resgatar conquista':'Em progresso','data-em-prestige="'+o.id+'" '+(p.claimed||!p.ready||!unlocked?'disabled':''),'primary',p.claimed?'check':'award')+'</article>';}).join('')+'</div>');
}
