# Regras da versão 1.0.0.1 BETA

## Moeda da Fama

MF é separada da verba da empresa. A interface mostra o custo antes de gastar.

| Ação | Valor |
|---|---:|
| Boas-vindas, uma vez por conta local | +25 MF |
| Todas as missões primárias, uma vez por conta | +30 MF |
| Missão diária concluída, conforme dificuldade | +1 a +12 MF |
| Desafio de prestígio concluído | +15 a +75 MF e até 3 impulsos |
| Renovar a agência imediatamente | −8 MF |
| Trocar missão diária em andamento | −3 MF |
| Um powerup na loja | −6 MF |
| Trocar por R$ 10.000 do jogo | −5 MF |
| Trocar por R$ 45.000 do jogo | −20 MF |
| Trocar por R$ 120.000 do jogo | −50 MF |

A renovação com MF reinicia um intervalo completo de cinco minutos, sem antecipação pela virada do relógio. A agência continua com 24 candidatos, quatro por formação.

Uma missão trocada mantém a dificuldade, recebe progresso novo a partir da troca e não apaga o progresso das outras missões. Missões prontas ou resgatadas não podem ser trocadas.

O saldo acompanha a conta entre campanhas. Boas-vindas e a recompensa inicial não podem ser recebidas novamente apenas começando outra campanha. No Real diretor, a troca por verba fica disponível depois do primeiro financiamento e os powerups continuam bloqueados.

Compras de MF com dinheiro real estão desativadas. Os valores acima são recursos da simulação, sem valor de saque. A carteira comprada no servidor permanece zerada e o endpoint de compra retorna indisponibilidade; um JSON enviado pelo cliente não confirma pagamento.

## Produção e criatividade

Filmes e episódios entram numa fila de uma a seis semanas. Duração, desenvolvimento escrito, gênero de execução complexa, upgrades e parecer orientam o prazo. O cronograma aparece antes e depois do início.

Créditos e decisões ficam registrados ao iniciar. Revisar o argumento enquanto há material em produção fica bloqueado para preservar a obra gravada. A estreia respeita o prazo; rede própria pausada adia a publicação.

Com IA, a ideia recebe notas separadas de originalidade, coerência, personagens, impacto e execução. Cada risco inclui evidência, efeito e sugestão. A narrativa tem o maior peso; equipe e recursos influenciam o acabamento. A IA não escolhe um número arbitrário de visualizações ou dinheiro: o motor usa qualidade, fama, divulgação, distribuição e concorrência para calcular os resultados.

A campanha conecta automaticamente ao servidor do jogo, com identificação separada por perfil. As cotas internas diárias estão desativadas por padrão; as cotas reais do provedor continuam valendo.

A avaliação local usa critérios explicáveis e uma biblioteca de 44,2 MiB com estudos fictícios e índices por gênero. Cada parecer mostra os sinais do texto, efeitos e sugestões. A quantidade de palavras não dá pontos. O motor por regras pode não reconhecer um significado implícito; o parecer generativo exige serviço e cota disponíveis.

## Emissoras e concorrentes

O ranking combina audiência e qualidade da grade. A posição, a exigência e o alcance são recalculados ao avançar a semana. Mudanças do alcance são graduais e limitadas por uma faixa em relação ao alcance inicial.

A negociação mostra compatibilidade, exigência, evidência e chance. Médio, Difícil e Real diretor têm rigor adicional de 7, 12 e 15 pontos na chance, respectivamente. Uma proposta excelente recebe vantagem pela qualidade; contratos existentes preservam a licença.

Novos concorrentes cumprem cronograma. Projetos incompatíveis com o nível de uma emissora são direcionados a uma opção mais acessível. Obras ainda em produção não entram no júri.

## Vant e navegação

Vant apresenta 15 passos. Cada toque avança a explicação; terminar a apresentação não conclui as missões. A jornada só termina quando todas as 11 missões iniciais forem concluídas. É possível rever as páginas em Configurações.

O menu principal muda de área. Abas inferiores mudam conteúdo dentro da mesma área. Detalhes de obra e resultado abrem em painéis próprios. O botão Voltar do Android fecha menu/detalhes ou volta ao estúdio antes de sair do aplicativo.

## Persistência

A migração preserva o caixa, o demonstrativo financeiro, a equipe, campanhas e produções da versão anterior. Material que já estava pronto mantém o prazo registrado. A regra nova de produção vale para produções iniciadas nesta versão.

Contas locais continuam protegidas por senha. O backup JSON inclui a campanha e não é uma confirmação de pagamento. A integração online envia resumos criativos da campanha atual e mantém conversas privadas por conta.

© V&D Digital. Todos os direitos reservados.
