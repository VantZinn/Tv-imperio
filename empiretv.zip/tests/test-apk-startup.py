"""Launch the built APK on a fresh CI emulator and reject startup crashes."""
import argparse
import json
import subprocess
import time
from pathlib import Path

PACKAGE = 'br.com.imperiodatv.indie'


def adb(*args, check=True):
    result = subprocess.run(['adb', *args], capture_output=True, text=True, timeout=45)
    if check and result.returncode:
        raise RuntimeError(result.stderr.strip() or result.stdout.strip() or 'ADB failed')
    return result.stdout.strip()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('apk')
    parser.add_argument('--output', default='apk-startup-diagnostics')
    args = parser.parse_args()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    report = {'package': PACKAGE, 'status': 'pending', 'launches': []}
    try:
        # This check must never stop or reinstall an app on the user's physical phone.
        if adb('shell', 'getprop', 'ro.kernel.qemu') != '1':
            raise RuntimeError('Este teste aceita somente um emulador Android.')
        report['android'] = adb('shell', 'getprop', 'ro.build.version.release')
        report['api'] = adb('shell', 'getprop', 'ro.build.version.sdk')
        adb('install', '-r', str(Path(args.apk).resolve()))
        for attempt in range(2):
            adb('shell', 'am', 'force-stop', PACKAGE)
            adb('logcat', '-c')
            launch = adb('shell', 'am', 'start', '-W', '-n', PACKAGE + '/.MainActivity')
            if 'Error' in launch or 'Exception' in launch:
                raise RuntimeError('O Android não abriu a atividade: ' + launch)
            ready = False
            ready_at = None
            deadline = time.monotonic() + 35
            while time.monotonic() < deadline:
                logs = adb('logcat', '-d', '-s', 'EmpireTVStartup:I', 'AndroidRuntime:E', 'chromium:E')
                (output / ('startup-' + str(attempt + 1) + '.log')).write_text(logs, encoding='utf-8')
                if 'GAME_START_FAILED' in logs or 'FATAL EXCEPTION' in logs:
                    raise RuntimeError('O APK falhou durante a abertura. Consulte o diagnóstico do job.')
                if not adb('shell', 'pidof', PACKAGE, check=False):
                    raise RuntimeError('O APK fechou durante a abertura.')
                if ready:
                    activity = adb('shell', 'dumpsys', 'activity', 'activities')
                    resumed = [line for line in activity.splitlines() if 'ResumedActivity' in line or 'mResumedActivity' in line]
                    if not any(PACKAGE in line for line in resumed):
                        raise RuntimeError('A atividade do jogo deixou de ficar aberta na tela.')
                if 'GAME_READY revision=2' in logs and not ready:
                    ready = True
                    ready_at = time.monotonic()
                if ready and time.monotonic() - ready_at >= 10:
                    report['launches'].append({'attempt': attempt + 1, 'ready': True, 'aliveAfterReadySeconds': 10})
                    break
                time.sleep(1)
            else:
                raise RuntimeError('A interface não ficou pronta no prazo do teste.')
        report['status'] = 'passed'
        print('PASS: APK abriu duas vezes, carregou a interface e permaneceu ativo.')
    except Exception as error:
        report['status'] = 'failed'
        report['error'] = str(error)
        raise
    finally:
        (output / 'result.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
