# Empire TV — corrigir o fechamento ao abrir

O repositório conferido é VantZinn/Tv-imperio. A compilação de 13/10/2026 às 06:41 (Brasília) terminou com sucesso, mas o ZIP do projeto publicado era o pacote anterior. Os arquivos de servidor na raiz são compatíveis com o serviço de IA. Não há evidência de que sua posição na raiz cause o fechamento do APK.

O relato recebido foi: o aplicativo abre e fecha em aproximadamente três segundos. A causa exata no aparelho ainda depende de um registro de falha. Esta revisão reforça a abertura e inclui verificação e recuperação para obter esse diagnóstico.

## Atualizar os dois arquivos do aplicativo

1. Baixe **Empire_TV_1.0.0.1_BETA_Projeto_APK.zip** desta nova entrega.
2. No GitHub, substitua o ZIP com esse mesmo nome na raiz. Não extraia nem renomeie; se o celular acrescentar (1) ao nome, ajuste para o nome exato antes de enviar.
3. Abra **.github/workflows/gerar-apk.yml** e substitua todo o conteúdo pelo novo **gerar-apk-empire-tv.yml** recebido. Enviar o YML apenas à raiz não altera o workflow.
4. Salve as mudanças. Abra **Actions → Gerar APK Empire TV → Run workflow**.
5. Aguarde também **Abrir o APK e verificar se continua funcionando**. Essa etapa usa um emulador Android 15, abre duas vezes e exige que a interface termine de carregar e o processo permaneça vivo após cada abertura.
6. Com o job concluído com sucesso, baixe **Artifacts → Empire-TV-1.0.0.1-BETA-APK**, extraia e instale o APK dessa execução nova.

O workflow usa o ZIP da raiz para compilar o aplicativo. Os arquivos server.mjs, ai-provider.mjs, package.json, catalog.json e Dockerfile da hospedagem não precisam ser substituídos por arquivos do aplicativo.

## Antes de instalar

Atualize **Android System WebView** e **Google Chrome** na loja do aparelho e tente abrir o APK atual novamente. O jogo utiliza o componente WebView para exibir a interface.

Tente instalar a atualização por cima da instalação atual. **Não desinstale se houver progresso sem backup.** APKs de teste de execuções diferentes podem ter assinaturas distintas, e Android pode recusar uma atualização direta. Se o jogo conseguir abrir, exporte a campanha primeiro. Esta revisão não apaga armazenamento ou campanhas.

## Se a nova abertura falhar

A tela de recuperação oferece **Tentar novamente**, **Atualizar WebView / Chrome** e **Copiar diagnóstico**. O diagnóstico informa a revisão, modelo do aparelho, versão do Android, versão do componente de exibição e código da falha; não contém senha, chave de IA ou roteiro.

Se o workflow falhar no teste do emulador, consulte **Artifacts → Empire-TV-Diagnostico-Abertura** e a etapa que falhou. O log registra se houve falha da interface, falha do Android ou fechamento do processo. Um APK sem passar nessa etapa não é apresentado como verificado.

## O que foi verificado nesta entrega

- Lógica do jogo e testes de contas/campanhas passaram.
- Cinco cenários de inicialização no DOM: abertura normal, banco indisponível, banco bloqueado, métodos ausentes de versões anteriores e falha de script.
- MainActivity compilada com Java 17, Android API 35 e WebKit 1.12.1.
- Código e configuração do teste de lançamento adicionados ao workflow.

A montagem final do APK e o teste em emulador serão executados ao rodar o novo workflow. Esta entrega ainda não confirma a resolução no seu celular físico; o diagnóstico permitirá verificar qualquer falha restante.

© V&D Digital. Todos os direitos reservados.
