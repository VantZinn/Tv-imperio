const test=require('node:test'),assert=require('node:assert/strict'),createGame=require('./game-fixture.cjs');
const ready=g=>({configured:true,available:true,code:'',retryAt:0,quotas:{global:{used:41,limit:null,unlimited:true},account:{used:40,limit:null,unlimited:true},automatic:{used:4,limit:4},resetAt:g.time()+86400000}});
const auth=(g,token='ab'.repeat(32))=>({token,expiresAt:g.time()+7*86400000,accountKind:'device',aiAvailable:true,aiStatus:ready(g)});
const synced=g=>({posts:[],works:[],cursor:0,aiAvailable:true,aiStatus:ready(g)});
const response=(body,status=200)=>({ok:status<400,status,json:async()=>body});

test('Primeira campanha se conecta sem formulário; identificação é única por perfil',async()=>{
 const g=createGame();g.profile();const requests=[];g.context.fetch=async(url,options)=>{requests.push({url,options,body:JSON.parse(options.body)});return response(url.endsWith('/v1/auth/device')?auth(g):synced(g));};
 assert.equal(await g.api.syncUniverse(true),true);assert.equal(requests[0].url,'https://tv-imperio.onrender.com/v1/auth/device');assert.deepEqual(Object.keys(requests[0].body).sort(),['deviceId','deviceSecret']);assert.equal(requests[0].body.deviceId.length,64);assert.equal(requests[0].options.headers.Authorization,undefined);
 assert.equal(requests[1].options.headers.Authorization,'Bearer '+'ab'.repeat(32));assert.equal(g.api.serviceConfig().mode,'automatic');assert.equal(g.api.getState().live.mode,'online');const first=requests[0].body;
 g.profile('bob');assert.equal(await g.api.ensureAutomaticService(),true);const second=requests.at(-1).body;assert.notEqual(second.deviceId,first.deviceId);assert.notEqual(second.deviceSecret,first.deviceSecret);assert(g.storage.has('empire-universe-alice'));assert(g.storage.has('empire-universe-bob'));
});

test('Pedidos simultâneos compartilham identificação e sessão é reutilizada',async()=>{
 const g=createGame();g.profile();let calls=0;g.context.fetch=async()=>{calls++;return response(auth(g));};
 const values=await Promise.all([g.api.ensureAutomaticService(),g.api.ensureAutomaticService(),g.api.ensureAutomaticService()]);assert(values.every(Boolean));assert.equal(calls,1);assert.equal(await g.api.ensureAutomaticService(),true);assert.equal(calls,1);
 g.api.navigate('settings','connection');g.api.render();assert(g.root.innerHTML.includes('IA conectada automaticamente'));assert(g.root.innerHTML.includes('Sem limite interno'));assert(!g.root.innerHTML.includes('40 / 0'));
});

test('Sessão expirada ou perdida no servidor é recuperada uma vez com a mesma identificação',async()=>{
 const g=createGame();g.profile();g.context.fetch=async()=>response(auth(g));await g.api.ensureAutomaticService();const device=g.storage.get('empire-universe-device-alice'),paths=[];let rejected=false;
 g.context.fetch=async(url,options)=>{paths.push(new URL(url).pathname);if(url.endsWith('/v1/auth/device')){assert.equal(JSON.stringify(JSON.parse(options.body)),device);return response(auth(g,'cd'.repeat(32)));}if(!rejected){rejected=true;return response({error:'Sessão expirada.'},401);}assert.equal(options.headers.Authorization,'Bearer '+'cd'.repeat(32));return response(synced(g));};
 assert.equal(await g.api.syncUniverse(true),true);assert.deepEqual(paths,['/v1/sync','/v1/auth/device','/v1/sync']);assert.equal(g.api.serviceConfig().token,'cd'.repeat(32));
});

test('Modo local cancela conexão pendente e não reconecta sem escolha do jogador',async()=>{
 const g=createGame();g.profile();let finish,calls=0;g.context.fetch=async()=>{calls++;return new Promise(resolve=>{finish=resolve;});};const pending=g.api.ensureAutomaticService();g.api.disconnectService();finish(response(auth(g)));assert.equal(await pending,false);assert.equal(g.api.serviceConfig(),null);assert.equal(g.api.automaticServiceEnabled(),false);assert.equal(await g.api.ensureAutomaticService(),false);assert.equal(calls,1);
 g.context.fetch=async url=>{calls++;return response(url.endsWith('/v1/auth/device')?auth(g):synced(g));};await g.api.enableAutomaticService();assert.equal(g.api.automaticServiceEnabled(),true);assert.equal(g.api.serviceConfig().mode,'automatic');assert.equal(calls,3);
});

test('Falha de conexão usa espera entre tentativas e preserva saldo e campanha',async()=>{
 const g=createGame(),state=g.profile();const cash=state.cash,wallet=state.fameWallet.balance;let calls=0;g.context.fetch=async()=>{calls++;throw Error('Servidor temporariamente indisponível.');};
 assert.equal(await g.api.syncUniverse(true),false);assert.equal(await g.api.syncUniverse(true),false);assert.equal(calls,1);assert.equal(state.cash,cash);assert.equal(state.fameWallet.balance,wallet);assert.equal(state.live.mode,'local');assert.equal(g.api.serviceConfig(),null);
 g.advance(61000);g.context.fetch=async url=>{calls++;return response(url.endsWith('/v1/auth/device')?auth(g):synced(g));};assert.equal(await g.api.syncUniverse(true),true);assert.equal(calls,3);
});

test('Conexão manual existente é mantida e troca de perfil ignora resposta antiga',async()=>{
 const g=createGame();g.profile();g.storage.set('empire-universe-alice',JSON.stringify({url:'https://custom.invalid',token:'manual-token',username:'legacy'}));let calls=0;g.context.fetch=async()=>{calls++;return response(auth(g));};assert.equal(await g.api.ensureAutomaticService(),true);assert.equal(calls,0);assert.equal(g.api.serviceConfig().token,'manual-token');
 g.profile('bob');let finish;g.context.fetch=async()=>new Promise(resolve=>{finish=resolve;});const pending=g.api.ensureAutomaticService();g.profile('carol');finish(response(auth(g)));assert.equal(await pending,false);assert.equal(g.storage.has('empire-universe-bob'),false);assert.equal(g.api.serviceConfig(),null);
});

test('Desconectar enquanto sincroniza impede resposta antiga de reativar o universo',async()=>{
 const g=createGame();g.profile();g.context.fetch=async()=>response(auth(g));await g.api.ensureAutomaticService();let finish;g.context.fetch=async()=>new Promise(resolve=>{finish=resolve;});const pending=g.api.syncUniverse(true);g.api.disconnectService();finish(response(synced(g)));assert.equal(await pending,false);assert.equal(g.api.getState().live.mode,'local');assert.equal(g.api.serviceConfig(),null);
});
