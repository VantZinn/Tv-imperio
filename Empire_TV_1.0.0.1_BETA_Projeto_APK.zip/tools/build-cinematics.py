"""Render original Empire TV stage art and silent Full HD cinematic loops.

Optional asset rebuild: Python + Pillow + numpy + ffmpeg. The APK uses the
included outputs and does not need these authoring dependencies.
"""
from pathlib import Path
import math
import random
import subprocess
import tempfile
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'app/src/main/assets/media'
DEST.mkdir(parents=True,exist_ok=True)
W,H=1920,1080

def stage(name):
    y,x=np.mgrid[0:H,0:W].astype(np.float32)
    base=np.zeros((H,W,3),dtype=np.float32)+np.array([5,14,25])
    for cx,cy,sigma,color in [(500,310,470,(32,22,6)),(1510,480,500,(6,35,37)),(970,720,320,(10,26,30))]:
        if name=='prestige':color=(color[0]+18,color[1]+6,color[2]-3)
        glow=np.exp(-((x-cx)**2+(y-cy)**2)/(2*sigma**2))
        base+=glow[:,:,None]*np.array(color)
    im=Image.fromarray(np.clip(base,0,255).astype('uint8'),'RGB').convert('RGBA')
    d=ImageDraw.Draw(im)
    # Stage floor and perspective guide lights.
    d.polygon([(0,775),(W,775),(W,H),(0,H)],fill=(5,14,23))
    for i in range(-9,10):d.line([(W/2+i*55,775),(W/2+i*270,H)],fill=(34,57,59),width=1)
    for j in [791,825,874,946,1060]:d.line([(0,j),(W,j)],fill=(44,61,61),width=1)
    glow_layer=Image.new('RGBA',(W,H));g=ImageDraw.Draw(glow_layer)
    for cx,color in [(160,(236,188,88,26)),(1760,(96,223,195,27))]:
        g.polygon([(cx-15,870),(cx+15,870),(cx+650,0),(cx-480,0)],fill=color)
        g.ellipse((cx-38,840,cx+38,898),fill=(color[0],color[1],color[2],100))
    im=Image.alpha_composite(im,glow_layer.filter(ImageFilter.GaussianBlur(25)))
    d=ImageDraw.Draw(im)
    rng=random.Random(42)
    for _ in range(190):
        sx,sy=rng.randrange(W),rng.randrange(50,810);r=rng.choice([1,1,1,2]);a=rng.randrange(20,80)
        d.ellipse((sx-r,sy-r,sx+r,sy+r),fill=(190,a+70,100,a))
    if name=='studio':
        # An original control room: illuminated monitors and film reels.
        for side in [0,1]:
            for i in range(3):
                left=65+i*185 if side==0 else 1335+i*185
                top=290+i*42
                d.rounded_rectangle((left,top,left+154,top+115),14,fill=(13,34,42),outline=(81,116,108),width=2)
                d.line((left+14,top+90,left+137,top+90),fill=(173,159,100),width=2)
                for k in range(5):
                    hh=16+(k*11+i*8)%41
                    d.rounded_rectangle((left+19+k*23,top+82-hh,left+29+k*23,top+82),2,fill=(55+k*9,122+k*6,116))
        for cx,cy,r in [(212,585,118),(1722,623,140)]:
            d.ellipse((cx-r,cy-r,cx+r,cy+r),fill=(18,39,46),outline=(175,157,98),width=3)
            d.ellipse((cx-24,cy-24,cx+24,cy+24),fill=(202,179,113),outline=(241,218,158),width=2)
            for k in range(6):
                ang=k*math.pi/3;px=cx+math.cos(ang)*r*.64;py=cy+math.sin(ang)*r*.64
                d.ellipse((px-r*.22,py-r*.22,px+r*.22,py+r*.22),fill=(5,19,29),outline=(58,95,97),width=2)
        d.polygon([(395,881),(1525,881),(1680,1040),(240,1040)],fill=(16,32,38),outline=(85,103,88))
        for k in range(21):d.rounded_rectangle((420+k*51,918,446+k*51,925),3,fill=(100+k%3*36,156,132))
    elif name=='analysis':
        # Film documents and an orbital reading room; decorative, no invented scores.
        for i in range(3):
            left=146+i*52;top=325+i*44
            d.rounded_rectangle((left,top,left+225,top+310),14,fill=(18+i*8,54+i*6,64),outline=(93,158,145),width=2)
            for j in range(7):d.rounded_rectangle((left+25,top+46+j*29,left+190-(j%3)*24,top+50+j*29),2,fill=(115,158,153))
        cx,cy=1500,520
        for r in [180,245,305]:d.ellipse((cx-r,cy-r*.52,cx+r,cy+r*.52),outline=(100,145,123),width=2)
        for k in range(8):
            a=k*math.pi/4;px=cx+math.cos(a)*255;py=cy+math.sin(a)*140
            d.ellipse((px-17,py-17,px+17,py+17),fill=(178,172,106),outline=(225,210,150),width=2)
        d.rounded_rectangle((1415,435,1585,605),24,fill=(23,58,65),outline=(127,184,157),width=3)
        d.polygon([(1460,478),(1540,520),(1460,562)],fill=(196,188,116))
    else:
        # Art deco premiere stage and a stylized gold television trophy.
        for i in range(9):
            xx=1170+i*76
            d.polygon([(xx-22,90),(xx+22,90),(xx+9,730),(xx-9,730)],fill=(59+i%3*10,56,38),outline=(127,111,67))
        cx=1510
        for r in [230,300,362]:d.ellipse((cx-r,410-r,cx+r,410+r),outline=(130,114,65),width=3)
        d.polygon([(1225,810),(1795,810),(1870,936),(1150,936)],fill=(34,42,40),outline=(184,152,83))
        d.polygon([(1290,755),(1730,755),(1795,810),(1225,810)],fill=(53,57,42),outline=(215,180,98))
        d.rounded_rectangle((1390,320,1630,480),22,fill=(171,137,69),outline=(247,217,136),width=6)
        d.rounded_rectangle((1415,345,1585,455),13,fill=(22,48,50),outline=(232,201,116),width=3)
        d.polygon([(1470,367),(1530,400),(1470,433)],fill=(226,200,125))
        d.polygon([(1390,307),(1370,247),(1420,270),(1465,215),(1510,274),(1560,226),(1607,270),(1650,245),(1630,307)],fill=(240,202,110))
        d.polygon([(1477,485),(1543,485),(1560,668),(1460,668)],fill=(182,145,74),outline=(225,191,109))
        d.rounded_rectangle((1400,662,1620,716),12,fill=(215,179,95),outline=(244,215,148),width=3)
    return im.convert('RGB')

with tempfile.TemporaryDirectory(prefix='empire-cinematics-') as tmp:
    for name in ['studio','analysis','prestige']:
        im=stage(name);png=Path(tmp)/(name+'.png');im.save(png)
        im.save(DEST/(name+'-poster.webp'),quality=94,method=6)
        vf="zoompan=z='1.045+0.012*sin(on*2*PI/240)':x='iw/2-iw/zoom/2+12*sin(on*2*PI/240)':y='ih/2-ih/zoom/2+8*cos(on*2*PI/240)':d=240:s=1920x1080:fps=30,noise=alls=3:allf=t+u,format=yuv420p"
        subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-loop','1','-i',str(png),'-vf',vf,'-t','8','-c:v','libx264','-preset','medium','-crf','16','-threads','2','-filter_threads','2','-profile:v','high','-level','4.1','-movflags','+faststart','-an','-metadata','artist=V&D Digital','-metadata','title=Empire TV — '+name,str(DEST/(name+'.mp4'))],check=True)
        print(name,round((DEST/(name+'.mp4')).stat().st_size/1024/1024,2),'MiB',flush=True)
print('Cenários originais em Full HD, 30 fps, sem faixa de áudio.',flush=True)
