package br.com.imperiodatv.indie;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceError;
import android.webkit.ConsoleMessage;
import android.webkit.RenderProcessGoneDetail;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.util.Log;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.FrameLayout;
import android.view.ViewGroup;
import android.util.Base64;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;

/** Immersive Android container for Empire TV; the package ID preserves existing saves. */
public class MainActivity extends Activity {
    private static final int REQUEST_IMPORT = 1001;
    private static final int REQUEST_EXPORT = 1002;
    private static final String GAME_URL = "https://appassets.androidplatform.net/assets/index.html";
    private WebView game;
    private ValueCallback<Uri[]> filePicker;
    private String pendingBackup;
    private FrameLayout container;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private boolean startupReady;
    private boolean startupFailed;
    private int startupAttempt;
    private String lastFailure = "";
    private String lastInsetsScript = "";
    private static final String STARTUP_TAG = "EmpireTVStartup";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        container = new FrameLayout(this);
        container.setBackgroundColor(Color.rgb(7, 11, 22));
        setContentView(container);
        startGame();
    }

    private void startGame() {
        final int attempt = ++startupAttempt;
        startupReady = false;
        startupFailed = false;
        lastInsetsScript = "";
        destroyGame();
        container.removeAllViews();
        try {
            initializeGame(attempt);
            enterFullscreen();
            mainHandler.postDelayed(() -> {
                if (attempt == startupAttempt && !startupReady && !startupFailed && !isFinishing()) {
                    showRecovery("A abertura demorou além do esperado. Atualize o componente Android WebView e tente novamente.", "STARTUP_TIMEOUT");
                }
            }, 25000);
        } catch (RuntimeException | LinkageError error) {
            Log.e(STARTUP_TAG, "NATIVE_START_FAILED", error);
            showRecovery("O componente de exibição do Android não iniciou. Atualize o WebView ou o Chrome e tente novamente.", "NATIVE_START_FAILED: " + error.getClass().getSimpleName());
        }
    }

    private void initializeGame(final int attempt) {
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        game = new WebView(this);
        WebSettings settings = game.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // Required for user-approved backup import through Android file picker.
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(false); // Offline cinematics are muted and contain no audio track.
        game.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl();
                if("appassets.androidplatform.net".equals(uri.getHost()) && "https".equals(uri.getScheme())) return false;
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (ActivityNotFoundException ignored) { }
                }
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (view == game && startupReady) view.requestApplyInsets();
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && attempt == startupAttempt) {
                    showRecovery("Não foi possível carregar os arquivos do jogo neste aparelho.", "ASSET_LOAD_FAILED: " + error.getErrorCode());
                }
            }
            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                if (view == game && attempt == startupAttempt) {
                    showRecovery("O componente de exibição do Android parou. Feche outros aplicativos e tente novamente; seu progresso foi mantido.", detail.didCrash() ? "WEBVIEW_RENDERER_CRASH" : "WEBVIEW_RENDERER_STOPPED");
                }
                return true;
            }
        });
        game.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                // The page owns its progress. Avoid injecting scripts into a WebView that is still initializing.
                if(progress==100 && view==game && startupReady)view.requestApplyInsets();
            }
            @Override public boolean onConsoleMessage(ConsoleMessage message) {
                if (!startupReady && !startupFailed && attempt == startupAttempt && message.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                    final String code = "SCRIPT_START_FAILED: line " + message.lineNumber();
                    mainHandler.post(() -> {
                        if (attempt == startupAttempt && !startupReady && !startupFailed)
                            showRecovery("A interface não iniciou neste componente Android. Atualize o WebView ou o Chrome e tente novamente.", code);
                    });
                }
                return true;
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> result, FileChooserParams params) {
                if(filePicker!=null)filePicker.onReceiveValue(null);
                filePicker=result;
                try { startActivityForResult(params.createIntent(),REQUEST_IMPORT);return true; }
                catch(Exception e) { filePicker=null;Toast.makeText(MainActivity.this,"Não foi possível abrir seus arquivos.",Toast.LENGTH_LONG).show();return false; }
            }
        });
        game.addJavascriptInterface(new BackupBridge(),"AndroidBridge");
        game.addJavascriptInterface(new StartupBridge(attempt),"EmpireNative");
        container.addView(game,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
        if (Build.VERSION.SDK_INT >= 28) {
            game.setOnApplyWindowInsetsListener((view, insets) -> {
                android.view.DisplayCutout cutout=insets.getDisplayCutout();
                float density=getResources().getDisplayMetrics().density;
                int left=cutout==null?0:(int)Math.ceil(cutout.getSafeInsetLeft()/density);
                int top=cutout==null?0:(int)Math.ceil(cutout.getSafeInsetTop()/density);
                int right=cutout==null?0:(int)Math.ceil(cutout.getSafeInsetRight()/density);
                int bottom=cutout==null?0:(int)Math.ceil(cutout.getSafeInsetBottom()/density);
                String script="(function(){var d=document.documentElement.style;d.setProperty('--native-left','"+left+"px');d.setProperty('--native-top','"+top+"px');d.setProperty('--native-right','"+right+"px');d.setProperty('--native-bottom','"+bottom+"px');})()";
                if (view==game && startupReady && !script.equals(lastInsetsScript)) {
                    lastInsetsScript=script;
                    ((WebView)view).evaluateJavascript(script,null);
                }
                return insets;
            });
        }
        game.loadUrl(GAME_URL);
    }

    public class StartupBridge {
        private final int attempt;
        StartupBridge(int attempt){this.attempt=attempt;}
        @JavascriptInterface public void ready(){mainHandler.post(() -> {
            if(attempt!=startupAttempt || startupFailed || game==null || isFinishing())return;
            startupReady=true;
            Log.i(STARTUP_TAG,"GAME_READY revision=2");
            game.requestApplyInsets();
        });}
        @JavascriptInterface public void failed(String code){mainHandler.post(() -> {
            if(attempt==startupAttempt && !startupReady && !startupFailed)
                showRecovery("A interface não terminou de carregar. Atualize o componente Android WebView e tente novamente.","SCRIPT_START_FAILED");
        });}
    }

    private void destroyGame(){
        if(game==null)return;
        WebView previous=game;
        game=null;
        try{
            if(previous.getParent() instanceof ViewGroup)((ViewGroup)previous.getParent()).removeView(previous);
            previous.destroy();
        }catch(RuntimeException ignored){}
    }

    private void showRecovery(String message,String code){
        if(isFinishing() || isDestroyed() || startupFailed)return;
        startupFailed=true;
        startupReady=false;
        lastFailure=code;
        Log.e(STARTUP_TAG,"GAME_START_FAILED "+code);
        destroyGame();
        container.removeAllViews();
        LinearLayout panel=new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int padding=(int)(24*getResources().getDisplayMetrics().density);
        panel.setPadding(padding,padding,padding,padding);
        TextView title=new TextView(this);
        title.setText("Empire TV • Recuperar abertura");title.setTextColor(Color.WHITE);title.setTextSize(23);
        TextView detail=new TextView(this);
        detail.setText(message);detail.setTextColor(Color.rgb(185,205,215));detail.setTextSize(16);detail.setPadding(0,padding,0,padding);
        panel.addView(title);panel.addView(detail);
        Button retry=new Button(this);retry.setText("Tentar novamente");retry.setOnClickListener(v->startGame());panel.addView(retry);
        Button update=new Button(this);update.setText("Atualizar WebView / Chrome");update.setOnClickListener(v->{
            String name="com.google.android.webview";
            PackageInfo info=currentWebViewPackage();if(info!=null)name=info.packageName;
            try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/apps/details?id="+name)));}
            catch(ActivityNotFoundException ignored){Toast.makeText(this,"Abra a loja do aparelho e atualize Android System WebView e Chrome.",Toast.LENGTH_LONG).show();}
        });panel.addView(update);
        Button report=new Button(this);report.setText("Copiar diagnóstico");report.setOnClickListener(v->{
            String provider="indisponível";
            PackageInfo info=currentWebViewPackage();if(info!=null)provider=info.packageName+" "+info.versionName;
            String data="Empire TV 1.0.0.1 BETA · abertura 2\nAndroid: "+Build.VERSION.RELEASE+" (API "+Build.VERSION.SDK_INT+")\nAparelho: "+Build.MANUFACTURER+" "+Build.MODEL+"\nWebView: "+provider+"\nFalha: "+lastFailure;
            ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            if(clipboard!=null)clipboard.setPrimaryClip(ClipData.newPlainText("Diagnóstico Empire TV",data));
            Toast.makeText(this,"Diagnóstico copiado. Não contém senha, chave de IA ou progresso.",Toast.LENGTH_LONG).show();
        });panel.addView(report);
        TextView rights=new TextView(this);rights.setText("© V&D Digital. Todos os direitos reservados.");rights.setTextColor(Color.rgb(140,165,180));rights.setTextSize(12);rights.setPadding(0,padding,0,0);panel.addView(rights);
        container.addView(panel,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private PackageInfo currentWebViewPackage(){
        if(Build.VERSION.SDK_INT<26)return null;
        try{return WebView.getCurrentWebViewPackage();}catch(RuntimeException | LinkageError ignored){return null;}
    }

    public class BackupBridge {
        /** Launches system save-file picker; does not transmit backup content to a server. */
        @JavascriptInterface public void saveBackup(String base64, String filename) {
            if(base64==null || base64.length()>16_000_000)return;
            runOnUiThread(()->{
                pendingBackup=base64;
                String safeName=(filename==null?"empire-tv-backup.json":filename.replaceAll("[^a-zA-Z0-9._-]","_"));
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE,safeName);
                try { startActivityForResult(intent,REQUEST_EXPORT); }
                catch(Exception e){ pendingBackup=null;Toast.makeText(MainActivity.this,"Não foi possível salvar o backup.",Toast.LENGTH_LONG).show(); }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQUEST_IMPORT){
            if(filePicker!=null){
                filePicker.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));
                filePicker=null;
            }
        }else if(requestCode==REQUEST_EXPORT){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&pendingBackup!=null){
                try(OutputStream output=getContentResolver().openOutputStream(data.getData())){
                    if(output==null)throw new Exception("Arquivo indisponível");
                    output.write(Base64.decode(pendingBackup,Base64.DEFAULT));
                    output.flush();
                    Toast.makeText(this,"Backup exportado com sucesso!",Toast.LENGTH_LONG).show();
                }catch(Exception e){Toast.makeText(this,"Falha ao salvar o backup.",Toast.LENGTH_LONG).show();}
            }
            pendingBackup=null;
        }
    }
    @Override public void onBackPressed(){
        if(game!=null){
            game.evaluateJavascript("window.EmpireNavigation ? window.EmpireNavigation.back() : false", result->{
                if(!"true".equals(result))closeOnBack();
            });
        }else closeOnBack();
    }
    private void closeOnBack(){if(game!=null&&game.canGoBack())game.goBack();else super.onBackPressed();}
    private void enterFullscreen() {
        try{applyFullscreen();}catch(RuntimeException | LinkageError error){Log.w(STARTUP_TAG,"FULLSCREEN_UNAVAILABLE");}
    }
    private void applyFullscreen() {
        Window window=getWindow();
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if(Build.VERSION.SDK_INT>=28){
            WindowManager.LayoutParams attributes=window.getAttributes();
            attributes.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            window.setAttributes(attributes);
        }
        if(Build.VERSION.SDK_INT>=30){
            window.setDecorFitsSystemWindows(false);
            WindowInsetsController controller=window.getInsetsController();
            if(controller!=null){
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                controller.hide(WindowInsets.Type.systemBars());
            }
        }else{
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }
    @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus)enterFullscreen();}
    @Override protected void onResume(){super.onResume();enterFullscreen();}
    @Override public void onConfigurationChanged(Configuration config){super.onConfigurationChanged(config);enterFullscreen();if(game!=null)game.requestApplyInsets();}
    @Override protected void onDestroy(){
        mainHandler.removeCallbacksAndMessages(null);
        if(filePicker!=null){filePicker.onReceiveValue(null);filePicker=null;}
        destroyGame();
        super.onDestroy();
    }
}
