package br.com.imperiodatv.indie;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.util.Base64;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;

/** Android WebView container for TV Empire. */
public class MainActivity extends Activity {
    private static final int REQUEST_IMPORT = 1001;
    private static final int REQUEST_EXPORT = 1002;
    private static final String GAME_URL = "https://appassets.androidplatform.net/assets/index.html";
    private WebView game;
    private ValueCallback<Uri[]> filePicker;
    private String pendingBackup;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(7, 11, 22));
        getWindow().setNavigationBarColor(Color.rgb(7, 11, 22));

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        game = new WebView(this);
        WebSettings settings = game.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // Required for user-approved backup import through Android file picker.
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        game.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl();
                if("appassets.androidplatform.net".equals(uri.getHost()) && "https".equals(uri.getScheme())) return false;
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (ActivityNotFoundException ignored) { }
                }
                return true;
            }
        });
        game.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> result, FileChooserParams params) {
                if(filePicker!=null)filePicker.onReceiveValue(null);
                filePicker=result;
                try { startActivityForResult(params.createIntent(),REQUEST_IMPORT);return true; }
                catch(Exception e) { filePicker=null;Toast.makeText(MainActivity.this,"Não foi possível abrir seus arquivos.",Toast.LENGTH_LONG).show();return false; }
            }
        });
        game.addJavascriptInterface(new BackupBridge(),"AndroidBridge");
        setContentView(game);
        game.loadUrl(GAME_URL);
    }

    public class BackupBridge {
        /** Launches system save-file picker; does not transmit backup content to a server. */
        @JavascriptInterface public void saveBackup(String base64, String filename) {
            if(base64==null || base64.length()>16_000_000)return;
            runOnUiThread(()->{
                pendingBackup=base64;
                String safeName=(filename==null?"imperio-tv-backup.json":filename.replaceAll("[^a-zA-Z0-9._-]","_"));
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE,safeName);
                try { startActivityForResult(intent,REQUEST_EXPORT); }
                catch(Exception e){ pendingBackup=null;Toast.makeText(MainActivity.this,"Não foi possível salvar o backup.",Toast.LENGTH_LONG).show(); }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQUEST_IMPORT){
            if(filePicker!=null){
                filePicker.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));
                filePicker=null;
            }
        }else if(requestCode==REQUEST_EXPORT){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&pendingBackup!=null){
                try(OutputStream output=getContentResolver().openOutputStream(data.getData())){
                    if(output==null)throw new Exception("Arquivo indisponível");
                    output.write(Base64.decode(pendingBackup,Base64.DEFAULT));
                    output.flush();
                    Toast.makeText(this,"Backup exportado com sucesso!",Toast.LENGTH_LONG).show();
                }catch(Exception e){Toast.makeText(this,"Falha ao salvar o backup.",Toast.LENGTH_LONG).show();}
            }
            pendingBackup=null;
        }
    }
    @Override public void onBackPressed(){
        if(game!=null&&game.canGoBack())game.goBack();
        else super.onBackPressed();
    }
    @Override public void onConfigurationChanged(Configuration config){super.onConfigurationChanged(config);}
    @Override protected void onDestroy(){
        if(filePicker!=null){filePicker.onReceiveValue(null);filePicker=null;}
        if(game!=null){game.destroy();game=null;}
        super.onDestroy();
    }
}
