"""Compile original fictional case studies and a lexical retrieval index for the offline game.

Run only when editing the reference library: Python 3 + NumPy. The APK build uses
the compiled assets and does not require NumPy or regeneration. No remote API,
downloaded text, trained language model, random padding or provider key is used.
"""
from pathlib import Path
from collections import Counter
from hashlib import sha256
import json, math, random, re, unicodedata
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
CATALOG = json.loads((ROOT / 'tools/analysis-catalog.json').read_text('utf-8'))
TARGET = 43 * 1024 * 1024
DIMENSIONS = 128
OUTPUT = ROOT / 'app/src/main/assets/analysis'
STOP = set(CATALOG['stopwords'])
SUFFIX = re.compile(r'(amentos|imentos|amento|imento|idades|idade|mente|acoes|acao|icoes|icao|ados|adas|ando|endo|indo|aram|eram|iram|ado|ada|ores|ora|oes|ais)$')

def words(text):
    normalized = ''.join(c for c in unicodedata.normalize('NFD', text.lower()) if not unicodedata.combining(c))
    result = []
    for word in re.findall(r'[a-z]{3,}', normalized):
        if word in STOP:
            continue
        stem = SUFFIX.sub('', word) if len(word) > 6 else word
        result.append(stem if len(stem) >= 3 else word)
    return result

def lexical_projection(word):
    seed = 2166136261
    for c in word:
        seed = ((seed ^ ord(c)) * 16777619) & 0xffffffff
    vector = []
    for i in range(DIMENSIONS):
        x = (seed ^ ((i + 1) * 2654435761)) & 0xffffffff
        x ^= x >> 16
        x = (x * 2246822507) & 0xffffffff
        x ^= x >> 13
        x = (x * 3266489909) & 0xffffffff
        x ^= x >> 16
        vector.append((x >> 8) / 8388608 - 1)
    return np.asarray(vector, dtype=np.float32)

def create_cases(genre, count):
    rng = random.Random(761904 + CATALOG['genres'].index(genre) * 104729)
    cases, seen = [], set()
    while len(cases) < count:
        role, place = rng.choice(CATALOG['roles']), rng.choice(CATALOG['places'])
        arc, obstacle, form = rng.choice(CATALOG['arcs']), rng.choice(CATALOG['obstacles']), rng.choice(CATALOG['forms'])
        symbol = rng.choice(CATALOG['symbols'])
        kind = rng.choice(['film', 'series'])
        identity = (role, place, arc['id'], obstacle['event'], form['name'], symbol, kind)
        if identity in seen:
            continue
        seen.add(identity)
        focus = rng.sample(CATALOG['dimensions'], 3)
        premise = f"{role[0].upper() + role[1:]} precisa {arc['goal']} {place}, enquanto {obstacle['event']}."
        cases.append({
            'id': f"{genre['slug']}-{len(cases)+1:05d}", 'kind': kind,
            'premise': premise,
            'motivation': f"A urgência nasce porque {arc['motive']}. O vínculo pode ser mostrado por {symbol}, sem depender de uma explicação sobre toda a vida da pessoa.",
            'conflict': f"{obstacle['event'][0].upper()+obstacle['event'][1:]}; {obstacle['pressure']}. A oposição deve aparecer numa tentativa que modifica as alternativas disponíveis.",
            'decision': f"A decisão central contrapõe {arc['choice']}. O custo proposto é {arc['cost']}; a pessoa precisa agir, não apenas receber uma solução de fora.",
            'payoff': f"{arc['change'][0].upper()+arc['change'][1:]}. A mudança pode ser percebida no novo uso de {symbol}, relacionando o desfecho ao gesto apresentado no começo.",
            'intention': f"Usar {form['name']} para {form['intent']}, explorando {arc['theme']}. A proposta de {genre['name']} trabalha {genre['lens']}, com espaço para escolhas fora de uma fórmula.",
            'mechanism': f"A primeira tentativa encontra uma oposição; a oposição exige uma decisão; o custo dessa decisão modifica o resultado. Uma pista possível é: {obstacle['clue']}.",
            'risk': f"Observe o risco específico do gênero: {genre['pitfall']}. Evite também que o custo de {arc['cost']} seja desfeito sem outra decisão que o texto tenha preparado.",
            'revision': f"Uma experiência de reescrita: {obstacle['revision']}. Em seguida, {genre['revision']}. Preserve a intenção de {arc['theme']} ao comparar as duas versões.",
            'checks': [obstacle['check'], genre['question'], form['test'],
                       'O que está sendo observado no argumento, e o que ainda é uma suposição do leitor?',
                       'A informação altera uma escolha ou apenas acrescenta explicação?',
                       'Uma escolha econômica de locação ou elenco preserva o conflito principal?',
                       'Qual expectativa o começo cria e qual parte dessa expectativa o resultado transforma?',
                       'A obra entrega uma pergunta resolvida nesta etapa e uma consequência que justifica continuar?' if kind == 'series' else 'O conflito central recebe um resultado legível mesmo quando o final permanece aberto?'],
            'tags': [arc['theme'], *arc['tags'], form['name'], *focus],
            'focus': focus
        })
    return cases

def encode(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode('utf-8')

def reference_text(case):
    return ' '.join([case['premise'], case['motivation'], case['conflict'], case['decision'], case['payoff'], case['intention'], *case['tags']])

def compile_module(genre, count):
    cases = create_cases(genre, count)
    tokenized = [Counter(words(reference_text(case))) for case in cases]
    frequency = Counter()
    for tokens in tokenized:
        frequency.update(tokens.keys())
    weights = {word: round(math.log((1+count)/(1+df))+1, 6) for word, df in frequency.items()}
    projections = {word: lexical_projection(word) for word in weights}
    vectors = np.zeros((count, DIMENSIONS), dtype='<i2')
    for row, tokens in enumerate(tokenized):
        vector = np.zeros(DIMENSIONS, dtype=np.float32)
        for word, occurrences in tokens.items():
            vector += projections[word] * weights[word] * (1+math.log(occurrences))
        magnitude = float(np.linalg.norm(vector)) or 1
        vectors[row] = np.rint(vector / magnitude * 32767).astype('<i2')
    module = encode({'version': 1, 'genre': genre['name'], 'dimensions': DIMENSIONS, 'weights': weights, 'cases': cases})
    vector_bytes = vectors.tobytes()
    directory = OUTPUT / genre['slug']
    directory.mkdir(parents=True, exist_ok=True)
    (directory / 'cases.json').write_bytes(module)
    (directory / 'vectors.i16').write_bytes(vector_bytes)
    return {'name':genre['name'], 'slug':genre['slug'], 'cases':count,
            'module':genre['slug']+'/cases.json', 'index':genre['slug']+'/vectors.i16',
            'moduleBytes':len(module), 'indexBytes':len(vector_bytes),
            'moduleSha256':sha256(module).hexdigest(), 'indexSha256':sha256(vector_bytes).hexdigest()}

def main():
    # Estimate from complete, useful studies; grow by adding studies if necessary.
    sample = sum(len(encode(case))+DIMENSIONS*2 for g in CATALOG['genres'] for case in create_cases(g, 32)) / (12*32)
    count = math.ceil(TARGET / (sample*len(CATALOG['genres'])) / 64) * 64
    while True:
        modules = [compile_module(genre, count) for genre in CATALOG['genres']]
        total = sum(m['moduleBytes']+m['indexBytes'] for m in modules)
        if total >= 40*1024*1024:
            break
        count += 64
    manifest = {'version':1, 'format':'original-fictional-reference-library', 'language':'pt-BR',
                'dimensions':DIMENSIONS, 'vectorEncoding':'normalized-int16-le',
                'totalCases':count*len(modules), 'totalBytes':total, 'modules':modules,
                'method':'Regras explicáveis e recuperação lexical por projeção determinística. Não é um modelo de linguagem.',
                'rights':'© V&D Digital. Todos os direitos reservados.'}
    (OUTPUT / 'manifest.json').write_bytes(encode(manifest))
    print(f"Local analysis: {manifest['totalCases']:,} original cases, {total/1024/1024:.2f} MiB, {len(modules)} genre modules.")

if __name__ == '__main__':
    main()
