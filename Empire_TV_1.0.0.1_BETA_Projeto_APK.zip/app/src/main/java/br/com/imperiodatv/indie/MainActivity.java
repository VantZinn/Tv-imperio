package br.com.imperiodatv.indie;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.util.Base64;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;

/** Immersive Android container for Empire TV; the package ID preserves existing saves. */
public class MainActivity extends Activity {
    private static final int REQUEST_IMPORT = 1001;
    private static final int REQUEST_EXPORT = 1002;
    private static final String GAME_URL = "https://appassets.androidplatform.net/assets/index.html";
    private WebView game;
    private ValueCallback<Uri[]> filePicker;
    private String pendingBackup;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        enterFullscreen();
        getWindow().setStatusBarColor(Color.rgb(7, 11, 22));
        getWindow().setNavigationBarColor(Color.rgb(7, 11, 22));

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        game = new WebView(this);
        WebSettings settings = game.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // Required for user-approved backup import through Android file picker.
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        game.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl();
                if("appassets.androidplatform.net".equals(uri.getHost()) && "https".equals(uri.getScheme())) return false;
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (ActivityNotFoundException ignored) { }
                }
                return true;
            }
        });
        game.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int progress) {
                view.evaluateJavascript("window.EmpireBoot && window.EmpireBoot.progress(" + Math.min(45, progress / 2) + ");", null);
                if(progress==100)view.requestApplyInsets();
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> result, FileChooserParams params) {
                if(filePicker!=null)filePicker.onReceiveValue(null);
                filePicker=result;
                try { startActivityForResult(params.createIntent(),REQUEST_IMPORT);return true; }
                catch(Exception e) { filePicker=null;Toast.makeText(MainActivity.this,"Não foi possível abrir seus arquivos.",Toast.LENGTH_LONG).show();return false; }
            }
        });
        game.addJavascriptInterface(new BackupBridge(),"AndroidBridge");
        setContentView(game);
        if (Build.VERSION.SDK_INT >= 28) {
            game.setOnApplyWindowInsetsListener((view, insets) -> {
                android.view.DisplayCutout cutout=insets.getDisplayCutout();
                float density=getResources().getDisplayMetrics().density;
                int left=cutout==null?0:(int)Math.ceil(cutout.getSafeInsetLeft()/density);
                int top=cutout==null?0:(int)Math.ceil(cutout.getSafeInsetTop()/density);
                int right=cutout==null?0:(int)Math.ceil(cutout.getSafeInsetRight()/density);
                int bottom=cutout==null?0:(int)Math.ceil(cutout.getSafeInsetBottom()/density);
                game.evaluateJavascript("(function(){var d=document.documentElement.style;d.setProperty('--native-left','"+left+"px');d.setProperty('--native-top','"+top+"px');d.setProperty('--native-right','"+right+"px');d.setProperty('--native-bottom','"+bottom+"px');})()",null);
                return insets;
            });
        }
        game.loadUrl(GAME_URL);
    }

    public class BackupBridge {
        /** Launches system save-file picker; does not transmit backup content to a server. */
        @JavascriptInterface public void saveBackup(String base64, String filename) {
            if(base64==null || base64.length()>16_000_000)return;
            runOnUiThread(()->{
                pendingBackup=base64;
                String safeName=(filename==null?"empire-tv-backup.json":filename.replaceAll("[^a-zA-Z0-9._-]","_"));
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE,safeName);
                try { startActivityForResult(intent,REQUEST_EXPORT); }
                catch(Exception e){ pendingBackup=null;Toast.makeText(MainActivity.this,"Não foi possível salvar o backup.",Toast.LENGTH_LONG).show(); }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQUEST_IMPORT){
            if(filePicker!=null){
                filePicker.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));
                filePicker=null;
            }
        }else if(requestCode==REQUEST_EXPORT){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&pendingBackup!=null){
                try(OutputStream output=getContentResolver().openOutputStream(data.getData())){
                    if(output==null)throw new Exception("Arquivo indisponível");
                    output.write(Base64.decode(pendingBackup,Base64.DEFAULT));
                    output.flush();
                    Toast.makeText(this,"Backup exportado com sucesso!",Toast.LENGTH_LONG).show();
                }catch(Exception e){Toast.makeText(this,"Falha ao salvar o backup.",Toast.LENGTH_LONG).show();}
            }
            pendingBackup=null;
        }
    }
    @Override public void onBackPressed(){
        if(game!=null){
            game.evaluateJavascript("window.EmpireNavigation ? window.EmpireNavigation.back() : false", result->{
                if(!"true".equals(result))closeOnBack();
            });
        }else closeOnBack();
    }
    private void closeOnBack(){if(game!=null&&game.canGoBack())game.goBack();else super.onBackPressed();}
    private void enterFullscreen() {
        Window window=getWindow();
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if(Build.VERSION.SDK_INT>=28){
            WindowManager.LayoutParams attributes=window.getAttributes();
            attributes.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            window.setAttributes(attributes);
        }
        if(Build.VERSION.SDK_INT>=30){
            window.setDecorFitsSystemWindows(false);
            WindowInsetsController controller=window.getInsetsController();
            if(controller!=null){
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                controller.hide(WindowInsets.Type.systemBars());
            }
        }else{
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }
    @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus)enterFullscreen();}
    @Override protected void onResume(){super.onResume();enterFullscreen();}
    @Override public void onConfigurationChanged(Configuration config){super.onConfigurationChanged(config);enterFullscreen();if(game!=null)game.requestApplyInsets();}
    @Override protected void onDestroy(){
        if(filePicker!=null){filePicker.onReceiveValue(null);filePicker=null;}
        if(game!=null){game.destroy();game=null;}
        super.onDestroy();
    }
}
